// app/bureaucracy/components/CafBooking.tsx
"use client";

import * as React from "react";
import { APPROVED_BY_UNI, CafLink } from "@/app/config/caf";

// Basit i18n – istersen bunu ayrı bir dosyaya alabilirsin
type Lang = "tr" | "en" | "ar";
const STRINGS: Record<Lang, Record<string, string>> = {
  tr: {
    openCaf: "CAF randevuları",
    open: "Aç",
    added: "Takvime hatırlatıcı eklendi",
    region: "Bölge",
    close: "Kapat",
  },
  en: {
    openCaf: "CAF appointments",
    open: "Open",
    added: "Reminder added to calendar",
    region: "Region",
    close: "Close",
  },
  ar: {
    openCaf: "مواعيد CAF",
    open: "افتح",
    added: "تمت إضافة تذكير إلى التقويم",
    region: "المنطقة",
    close: "إغلاق",
  },
};

function isRTL(lang: Lang) {
  return lang === "ar";
}

type Reminder = {
  title: string;
  dueISO: string; // ISO date string
  createdAt: string;
};

// LocalStorage güvenli push (SSR/CSR ayrımı)
function pushReminder(reminder: Reminder) {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem("reminders");
    const arr: Reminder[] = raw ? JSON.parse(raw) : [];
    arr.push(reminder);
    window.localStorage.setItem("reminders", JSON.stringify(arr));
  } catch {
    // yut – localStorage devre dışı ise sessiz geç
  }
}

function addDays(date: Date, days: number) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export default function CafBooking({
  universityKey,
  lang = "tr",
}: {
  universityKey: string;
  lang?: Lang;
}) {
  const t = STRINGS[lang] ?? STRINGS.tr;
  const [open, setOpen] = React.useState(false);
  const items: CafLink[] = APPROVED_BY_UNI[universityKey] ?? APPROVED_BY_UNI["polimi"];

  const handleClick = (c: CafLink) => {
    // a) yeni sekme
    if (typeof window !== "undefined") {
      window.open(c.url, "_blank", "noopener,noreferrer");
    }
    // b) localStorage "reminders"
    const due = addDays(new Date(), 3);
    pushReminder({
      title: `CAF: ${c.name}`,
      dueISO: due.toISOString(),
      createdAt: new Date().toISOString(),
    });
    // c) modal kapat + toast/alert
    setOpen(false);
    if (typeof window !== "undefined") {
      // Eğer projede kendi toast sistemin varsa onunla değiştir
      window.alert(t.added);
    }
  };

  return (
    <div dir={isRTL(lang) ? "rtl" : "ltr"} style={{ display: "inline-block" }}>
      <button
        type="button"
        onClick={() => setOpen(true)}
        style={{
          padding: "8px 12px",
          borderRadius: 8,
          border: "1px solid #ddd",
          cursor: "pointer",
        }}
      >
        {t.openCaf}
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "min(520px, 92vw)",
              background: "#fff",
              borderRadius: 12,
              boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
              overflow: "hidden",
            }}
          >
            <div style={{ padding: "14px 16px", borderBottom: "1px solid #eee", fontWeight: 600 }}>
              {t.openCaf}
            </div>

            <div>
              {items.map((c) => (
                <div
                  key={c.key}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 12,
                    padding: "12px 16px",
                    borderBottom: "1px solid #f2f2f2",
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 600 }}>{c.name}</div>
                    <div style={{ fontSize: 12, color: "#666" }}>
                      {c.region ? `${t.region}: ${c.region}` : "\u00A0"}
                    </div>
                    <div style={{ fontSize: 12, color: "#999", wordBreak: "break-all" }}>
                      {c.url}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleClick(c)}
                    style={{
                      padding: "8px 12px",
                      borderRadius: 8,
                      border: "1px solid #ddd",
                      cursor: "pointer",
                      flexShrink: 0,
                    }}
                  >
                    {t.open}
                  </button>
                </div>
              ))}
            </div>

            <div style={{ padding: "10px 16px", textAlign: isRTL(lang) ? "left" : "right" }}>
              <button
                type="button"
                onClick={() => setOpen(false)}
                style={{ padding: "6px 10px", borderRadius: 8, border: "1px solid #ddd", cursor: "pointer" }}
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}