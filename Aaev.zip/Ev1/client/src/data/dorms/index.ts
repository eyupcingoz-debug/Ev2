import { Dorm, CityNames } from './types';
import { milanDorms } from './milan';
import { romeDorms } from './rome';
import { bolognaDorms } from './bologna';
import { turinDorms } from './turin';
import { naplesDorms } from './naples';
import { genoaDorms } from './genoa';
import { paviaDorms } from './pavia';
import { piacenzaDorms } from './piacenza';

export const allDorms: Dorm[] = [
  ...milanDorms,
  ...romeDorms,
  ...bolognaDorms,
  ...turinDorms,
  ...naplesDorms,
  ...genoaDorms,
  ...paviaDorms,
  ...piacenzaDorms
];

export const cities = [
  'All',
  'Milan',
  'Rome',
  'Bologna',
  'Turin',
  'Naples',
  'Genoa',
  'Pavia',
  'Piacenza'
];

export const cityNames: Record<string, CityNames> = {
  'Milan': { en: 'Milan', it: 'Milano', tr: 'Milano', ar: 'ميلانو' },
  'Rome': { en: 'Rome', it: 'Roma', tr: 'Roma', ar: 'روما' },
  'Bologna': { en: 'Bologna', it: 'Bologna', tr: 'Bologna', ar: 'بولونيا' },
  'Turin': { en: 'Turin', it: 'Torino', tr: 'Torino', ar: 'تورينو' },
  'Naples': { en: 'Naples', it: 'Napoli', tr: 'Napoli', ar: 'نابولي' },
  'Genoa': { en: 'Genoa', it: 'Genova', tr: 'Cenova', ar: 'جنوة' },
  'Pavia': { en: 'Pavia', it: 'Pavia', tr: 'Pavia', ar: 'بافيا' },
  'Piacenza': { en: 'Piacenza', it: 'Piacenza', tr: 'Piacenza', ar: 'بياتشنزا' }
};

export type { Dorm, CityNames };

export {
  milanDorms,
  romeDorms,
  bolognaDorms,
  turinDorms,
  naplesDorms,
  genoaDorms,
  paviaDorms,
  piacenzaDorms
};
