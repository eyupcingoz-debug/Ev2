import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Calendar, ExternalLink } from 'lucide-react';
import { APPROVED_BY_UNI, CafLink } from '../../../config/caf';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

interface CafBookingProps {
  universityKey?: string;
}

export default function CafBooking({ universityKey = 'polimi' }: CafBookingProps) {
  const { language, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [open, setOpen] = useState(false);

  const cafList = APPROVED_BY_UNI[universityKey] || APPROVED_BY_UNI.polimi;

  const handleCafClick = (caf: CafLink, e: React.MouseEvent) => {
    e.stopPropagation();
    
    // Open CAF website
    window.open(caf.url, '_blank', 'noopener,noreferrer');

    // Close modal
    setOpen(false);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        data-testid="button-caf-appointments"
      >
        <Calendar className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
        {t('cafAppointments')}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md" dir={isRTL ? 'rtl' : 'ltr'} data-testid="dialog-caf-booking">
          <DialogHeader>
            <DialogTitle>{t('cafAppointments')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4">
            {cafList.map((caf) => (
              <div
                key={caf.key}
                className={`flex items-center gap-3 p-3 rounded-md border ${isRTL ? 'flex-row-reverse' : ''}`}
                data-testid={`caf-item-${caf.key}`}
              >
                <div className="flex-1">
                  <div className="font-medium text-foreground">{caf.name}</div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => handleCafClick(caf, e)}
                  data-testid={`button-open-${caf.key}`}
                  className="shrink-0"
                >
                  <ExternalLink className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('openCaf')}
                </Button>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-close-caf-dialog"
            >
              {t('close')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
