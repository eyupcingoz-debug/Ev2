import { Dorm } from './types';

export const tarantoDorms: Dorm[] = [
  {
    city: "Taranto",
    name: {
      en: "ADISU Taranto Residence",
      it: "ADISU Residenza Taranto",
      tr: "ADISU Taranto Yurdu",
      ar: "أديسو سكن تارانتو"
    },
    university: "Politecnico di Bari - Taranto",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 180,
    priceMax: 350,
    applicationLink: "https://www.adisupuglia.it/",
    mapLink: "https://maps.google.com/?q=ADISU+Taranto",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"],
    recommended: true
  },
  {
    city: "Taranto",
    name: {
      en: "ADISU Puglia Housing",
      it: "ADISU Puglia Alloggi",
      tr: "ADISU Puglia Konaklama",
      ar: "أديسو بوليا السكن"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 190,
    priceMax: 360,
    applicationLink: "https://www.adisupuglia.it/",
    mapLink: "https://maps.google.com/?q=ADISU+Puglia+Taranto",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"],
    recommended: true
  },
  {
    city: "Taranto",
    name: {
      en: "Politecnico di Bari Taranto Campus",
      it: "Politecnico di Bari Campus Taranto",
      tr: "Politecnico di Bari Taranto Kampüsü",
      ar: "بوليتكنيكو دي باري حرم تارانتو"
    },
    university: "Politecnico di Bari",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 200,
    priceMax: 380,
    applicationLink: "https://www.poliba.it/",
    mapLink: "https://maps.google.com/?q=Politecnico+Bari+Taranto",
    features: ["Wi-Fi", "Study rooms", "Cafeteria", "Library"]
  },
  {
    city: "Taranto",
    name: {
      en: "Municipal Student Rooms",
      it: "Camere Comunali",
      tr: "Belediye Odaları",
      ar: "غرف البلدية"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 150,
    priceMax: 300,
    applicationLink: "https://www.comune.taranto.it/",
    mapLink: "https://maps.google.com/?q=Student+Housing+Comune+Taranto",
    features: ["Wi-Fi", "Common kitchen", "Laundry", "Central location"]
  },
  {
    city: "Taranto",
    name: {
      en: "Foundation Guest Houses",
      it: "Case della Fondazione",
      tr: "Vakıf Konukevleri",
      ar: "بيوت المؤسسة"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double", "Triple"],
    priceMin: 170,
    priceMax: 340,
    applicationLink: "https://www.adisupuglia.it/",
    mapLink: "https://maps.google.com/?q=Foundation+Guest+Houses+Taranto",
    features: ["Wi-Fi", "Common areas", "Garden", "Cultural events"]
  },
  {
    city: "Taranto",
    name: {
      en: "Association Houses",
      it: "Case delle Associazioni",
      tr: "Dernek Evleri",
      ar: "منازل الجمعيات"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 160,
    priceMax: 330,
    applicationLink: "https://www.comune.taranto.it/",
    mapLink: "https://maps.google.com/?q=Association+Houses+Taranto",
    features: ["Wi-Fi", "Common kitchen", "Study areas", "Community events"]
  }
];
