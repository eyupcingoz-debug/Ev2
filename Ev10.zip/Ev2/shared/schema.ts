import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with full authentication fields
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  nationality: text("nationality"), // Optional field for filtering
  password: text("password").notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
  verificationToken: text("verification_token"),
  verificationTokenExpiry: timestamp("verification_token_expiry"),
  resetPasswordToken: text("reset_password_token"),
  resetPasswordExpiry: timestamp("reset_password_expiry"),
  gdprConsent: boolean("gdpr_consent").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Roommate search listings
export const roommateListings = pgTable("roommate_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  city: text("city").notNull(),
  district: text("district"),
  budgetMin: integer("budget_min"),
  budgetMax: integer("budget_max"),
  moveInDate: timestamp("move_in_date"),
  nationality: text("nationality"), // Optional filter
  preferences: jsonb("preferences").$type<{
    smoking?: boolean;
    pets?: boolean;
    gender?: string;
    cleanliness?: number;
    noiseTolerance?: number;
  }>(),
  description: text("description"),
  photos: jsonb("photos").$type<string[]>().default(sql`'[]'`), // Max 8 photos
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Room/House sharing listings
export const roomListings = pgTable("room_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  city: text("city").notNull(),
  district: text("district"),
  rent: integer("rent").notNull(),
  deposit: integer("deposit"),
  utilitiesIncluded: boolean("utilities_included").default(false),
  roomType: text("room_type").notNull(), // 'private' or 'shared'
  availableFrom: timestamp("available_from"),
  preferredNationality: text("preferred_nationality"), // Optional
  rules: jsonb("rules").$type<{
    smoking?: boolean;
    pets?: boolean;
    visitors?: boolean;
    other?: string;
  }>(),
  description: text("description"),
  photos: jsonb("photos").$type<string[]>().default(sql`'[]'`), // Max 12 photos
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Dormitories
export const dormitories = pgTable("dormitories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  city: text("city").notNull(),
  district: text("district"),
  priceMin: integer("price_min"),
  priceMax: integer("price_max"),
  roomTypes: jsonb("room_types").$type<string[]>().default(sql`'[]'`), // e.g., ['single', 'double', 'shared']
  amenities: jsonb("amenities").$type<string[]>().default(sql`'[]'`),
  description: text("description"),
  applicationLink: text("application_link"),
  photos: jsonb("photos").$type<string[]>().default(sql`'[]'`),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Messages for room listings
export const roomMessages = pgTable("room_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomListingId: varchar("room_listing_id").notNull().references(() => roomListings.id, { onDelete: "cascade" }),
  senderEmail: text("sender_email").notNull(),
  senderName: text("sender_name").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users, {
  email: z.string().email(),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  phone: z.string().min(10),
  city: z.string().min(1),
  password: z.string().min(8),
  nationality: z.string().optional(),
}).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  isVerified: true,
  verificationToken: true,
  verificationTokenExpiry: true,
  resetPasswordToken: true,
  resetPasswordExpiry: true,
});

export const insertRoommateListingSchema = createInsertSchema(roommateListings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRoomListingSchema = createInsertSchema(roomListings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDormitorySchema = createInsertSchema(dormitories).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRoomMessageSchema = createInsertSchema(roomMessages).omit({
  id: true,
  createdAt: true,
});

// TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type RoommateListing = typeof roommateListings.$inferSelect;
export type InsertRoommateListing = z.infer<typeof insertRoommateListingSchema>;
export type RoomListing = typeof roomListings.$inferSelect;
export type InsertRoomListing = z.infer<typeof insertRoomListingSchema>;
export type Dormitory = typeof dormitories.$inferSelect;
export type InsertDormitory = z.infer<typeof insertDormitorySchema>;
export type RoomMessage = typeof roomMessages.$inferSelect;
export type InsertRoomMessage = z.infer<typeof insertRoomMessageSchema>;
