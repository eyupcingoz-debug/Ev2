import { Dorm } from './types';

export const bolognaDorms: Dorm[] = [
  {
    city: "Bologna",
    name: {
      en: "ER.GO Cleto Tomba",
      it: "ER.GO Cleto Tomba",
      tr: "ER.GO Cleto Tomba",
      ar: "ER.GO كليتو تومبا"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Cleto+Tomba+Bologna",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"],
    recommended: true
  },
  {
    city: "Bologna",
    name: {
      en: "ER.GO Carducci",
      it: "ER.GO Carducci",
      tr: "ER.GO Carducci",
      ar: "ER.GO كاردوتشي"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 280,
    priceMax: 480,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Carducci+Bologna",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"],
    recommended: true
  },
  {
    city: "Bologna",
    name: {
      en: "ER.GO Barontini",
      it: "ER.GO Barontini",
      tr: "ER.GO Barontini",
      ar: "ER.GO بارونتيني"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 270,
    priceMax: 470,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Barontini+Bologna",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Garden"]
  },
  {
    city: "Bologna",
    name: {
      en: "ER.GO Carpentiere",
      it: "ER.GO Carpentiere",
      tr: "ER.GO Carpentiere",
      ar: "ER.GO كاربينتييري"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 260,
    priceMax: 460,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Carpentiere+Bologna",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Bologna",
    name: {
      en: "ER.GO Castellaccio",
      it: "ER.GO Castellaccio",
      tr: "ER.GO Castellaccio",
      ar: "ER.GO كاستيلاتشيو"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 290,
    priceMax: 490,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Castellaccio+Bologna",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Sports facilities"]
  },
  {
    city: "Bologna",
    name: {
      en: "ER.GO Baricentro",
      it: "ER.GO Baricentro",
      tr: "ER.GO Baricentro",
      ar: "ER.GO باريتشينترو"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 300,
    priceMax: 500,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Baricentro+Bologna",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Bologna",
    name: {
      en: "Camplus Zamboni",
      it: "Camplus Zamboni",
      tr: "Camplus Zamboni",
      ar: "كامبلوس زامبوني"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 600,
    priceMax: 850,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Zamboni+Bologna",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cafeteria"]
  },
  {
    city: "Bologna",
    name: {
      en: "Camplus Alma Mater",
      it: "Camplus Alma Mater",
      tr: "Camplus Alma Mater",
      ar: "كامبلوس ألما ماتر"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 620,
    priceMax: 880,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Alma+Mater+Bologna",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry"]
  },
  {
    city: "Bologna",
    name: {
      en: "Camplus San Donato",
      it: "Camplus San Donato",
      tr: "Camplus San Donato",
      ar: "كامبلوس سان دوناتو"
    },
    university: "Università di Bologna",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 580,
    priceMax: 820,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+San+Donato+Bologna",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Bologna",
    name: {
      en: "Torleone College RUI",
      it: "Collegio Torleone RUI",
      tr: "Torleone College RUI",
      ar: "كلية تورليوني RUI"
    },
    university: "Università di Bologna",
    gender: "Male",
    roomTypes: ["Single"],
    priceMin: 450,
    priceMax: 700,
    applicationLink: "https://www.fondazionerui.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Torleone+Bologna",
    features: ["Wi-Fi", "Chapel", "Study rooms", "Library", "Garden"]
  }
];
