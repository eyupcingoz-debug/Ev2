import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import type { CarouselApi } from '@/components/ui/carousel';

import welcomeImage from '@assets/stock_images/3d_colorful_abstract_0419912e.jpg';
import bureaucracyImage from '@assets/stock_images/bureaucracy_document_1cadb892.jpg';
import chatbotImage from '@assets/stock_images/ai_robot_chatbot_ass_5daeb3d7.jpg';
import roommatesImage from '@assets/stock_images/roommates_friends_ap_a9145b91.jpg';
import globeImage from '@assets/stock_images/globe_earth_world_in_387e1e8c.jpg';

interface OnboardingSlide {
  image: string;
  titleKey: string;
  descKey: string;
  isLast?: boolean;
}

const slides: OnboardingSlide[] = [
  {
    image: welcomeImage,
    titleKey: 'onboardingWelcomeTitle',
    descKey: 'onboardingWelcomeDesc',
  },
  {
    image: bureaucracyImage,
    titleKey: 'onboardingBureaucracyTitle',
    descKey: 'onboardingBureaucracyDesc',
  },
  {
    image: chatbotImage,
    titleKey: 'onboardingChatbotTitle',
    descKey: 'onboardingChatbotDesc',
  },
  {
    image: roommatesImage,
    titleKey: 'onboardingRoommatesTitle',
    descKey: 'onboardingRoommatesDesc',
  },
  {
    image: globeImage,
    titleKey: 'onboardingGetStartedTitle',
    descKey: 'onboardingGetStartedDesc',
    isLast: true,
  },
];

interface OnboardingProps {
  onComplete: () => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [, setLocation] = useLocation();
  const { language, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (!api) return;

    setCurrent(api.selectedScrollSnap());

    api.on('select', () => {
      setCurrent(api.selectedScrollSnap());
    });
  }, [api]);

  const handleSkip = () => {
    localStorage.setItem('onboardingSeen', 'true');
    onComplete();
    setLocation('/');
  };

  const handleNext = () => {
    api?.scrollNext();
  };

  const handleFinish = (destination: '/register' | '/login') => {
    localStorage.setItem('onboardingSeen', 'true');
    onComplete();
    setLocation(destination);
  };

  const progress = ((current + 1) / slides.length) * 100;
  const isLastSlide = current === slides.length - 1;

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-cyan-50 via-white to-teal-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
      <div className="flex h-full flex-col">
        {/* Header with Skip and Progress */}
        <div className="flex items-center justify-between p-4 md:p-6">
          <Button
            variant="ghost"
            onClick={handleSkip}
            className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
          >
            {t('onboardingSkip')}
          </Button>
          <div className="flex-1 max-w-xs mx-4">
            <Progress value={progress} className="h-1" />
          </div>
          <div className="w-16 text-sm text-gray-600 dark:text-gray-400 text-right">
            {current + 1}/{slides.length}
          </div>
        </div>

        {/* Carousel */}
        <div className="flex-1 flex items-center justify-center px-4 md:px-8 pb-8">
          <div className="w-full max-w-4xl">
            <Carousel
              setApi={setApi}
              opts={{
                align: 'center',
                loop: false,
                direction: isRTL ? 'rtl' : 'ltr',
              }}
              className="w-full"
            >
              <CarouselContent>
                {slides.map((slide, index) => (
                  <CarouselItem key={index}>
                    <div className="flex flex-col items-center text-center space-y-6 md:space-y-8 py-4 md:py-8">
                      {/* Image Container */}
                      <div className="relative w-full aspect-square max-w-md mx-auto overflow-hidden rounded-3xl shadow-2xl">
                        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 to-teal-500/20 z-10" />
                        <img
                          src={slide.image}
                          alt={t(slide.titleKey)}
                          className="w-full h-full object-cover transform transition-transform duration-700 hover:scale-105"
                        />
                      </div>

                      {/* Content */}
                      <div className="space-y-4 max-w-2xl">
                        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white leading-tight">
                          {t(slide.titleKey)}
                        </h1>
                        <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
                          {t(slide.descKey)}
                        </p>
                      </div>

                      {/* Action Buttons for Last Slide */}
                      {slide.isLast && (
                        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md mt-8">
                          <Button
                            size="lg"
                            onClick={() => handleFinish('/login')}
                            variant="outline"
                            className="flex-1 text-lg py-6 rounded-xl border-2 border-cyan-600 text-cyan-600 hover:bg-cyan-50 dark:border-cyan-400 dark:text-cyan-400 dark:hover:bg-cyan-950"
                          >
                            {t('login')}
                          </Button>
                          <Button
                            size="lg"
                            onClick={() => handleFinish('/register')}
                            className="flex-1 text-lg py-6 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-700 hover:to-teal-700 shadow-lg"
                          >
                            {t('register')}
                          </Button>
                        </div>
                      )}
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
          </div>
        </div>

        {/* Bottom Navigation - Only show Next button if not on last slide */}
        {!isLastSlide && (
          <div className="flex justify-center pb-8 md:pb-12">
            <Button
              size="lg"
              onClick={handleNext}
              className="px-12 py-6 text-lg rounded-full bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-700 hover:to-teal-700 shadow-lg"
            >
              {t('onboardingNext')}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
