# DocuBuddy+ - Student Documentation Assistant

## Overview
DocuBuddy+ is a full-stack web application designed to assist international students in Italy. Its primary purpose is to simplify bureaucratic tasks, facilitate roommate matching, and help track critical deadlines. The application features an AI-powered chatbot (DocuBot) for multilingual bureaucratic assistance, a comprehensive bureaucracy manager, a lifestyle-based roommate finder, and a personal calendar/reminder system. It supports Italian, English, Turkish, and Arabic (with RTL support) and aims to provide a modern, user-friendly experience.

## Recent Changes (November 12, 2025)
- **Professional Onboarding Carousel** (NEW - November 12, 2025):
  - Implemented Wise-style professional onboarding with smooth transitions and high-quality visuals
  - 5 feature slides introducing DocuBuddy+: Bureaucracy Manager, DocuBot AI Assistant, Roommate Finder, Dormitories Guide, Calendar & Reminders
  - Embla carousel with progress bar, slide counter (1/5, 2/5, etc.), and smooth animations
  - Skip button on all slides, Next button on slides 1-4, Login & Register buttons on final slide
  - First-visit detection using localStorage (`onboardingSeen` flag)
  - Gradient overlays on images for consistent cyan/teal branding
  - Full multilingual support (IT, EN, TR, AR) with RTL for Arabic
  - Mobile responsive design with proper callback pattern for dismissal (prevents user trapping)
  - Images sourced from Unsplash CDN for optimal performance
- **Fresh GitHub Import to Replit**: Successfully imported and configured the project from GitHub archive
  - Extracted project from zip archive (Ev11.zip) and moved all files to root directory
  - Installed Node.js 20 module and all npm dependencies (507 packages)
  - Connected to existing Replit PostgreSQL database and pushed schema with Drizzle ORM
  - Configured dev workflow on port 5000 (integrated frontend + backend Express server)
  - Database schema synced: users, roommate_listings, room_listings, dormitories, room_messages
  - Vite dev server pre-configured with `host: 0.0.0.0`, `port: 5000`, and `allowedHosts: true` for Replit proxy
  - Application verified running and serving at http://0.0.0.0:5000 with full-stack integration
  - **Deployment configured**: Autoscale deployment set up with `npm run build` and `npm start`
  - All project files organized in root directory with clean structure
  - Environment fully configured and tested - application ready for development and deployment
  - Cleaned up duplicate directories (Ev2) and zip files for clean workspace
- **Roommates Page Restructure**: Completely redesigned the Roommates page with 3 distinct sections:
  - **Find Roommate**: Browse available roommates looking to share their rooms
  - **Share My Room**: Create and manage your own room listings
  - **Looking for Room**: View all published room listings from users sharing their spaces
- **Enhanced UI/UX**:
  - Added description boxes at the top of each section explaining its purpose
  - Implemented filter-based search with "Bul" (Find) button instead of live search bars
  - Empty state appears only after searching with zero results (no initial empty state)
  - Added edit/delete functionality for user's own listings
  - Improved photo upload UI with support for up to 8 photos per listing
- **Interactive Map Feature**: Added Leaflet-based interactive map in "Looking for Room" section
  - Displays all room listings as city-based markers with detailed popups
  - Geolocation support with "Center on Me" button to find user's location
  - Markers show listing count badges and open popups with photos, title, city, rent, and description on click
  - Click-through functionality to view full listing details
  - No API key required (uses OpenStreetMap tiles)
- **"Looking for Room" UX Improvements** (November 9, 2025):
  - **Map Dialog**: Map now opens in a modal dialog via dedicated "Harita/Map/Mappa" button (not inline)
  - **Map Centering**: Default viewport centered on Milano, shows only Milano/Milan listings
  - **Collapsible Filters**: Search filters now default to collapsed state for cleaner UI
  - **Initial Listings Display**: Shows first 6 real room listings immediately without requiring search
  - **Map Button Translations**: Added "Harita" (TR), "Map" (EN), "Mappa" (IT), "خريطة" (AR)
- **Multilingual Support**: Added comprehensive translations for all new features in English, Italian, Turkish, and Arabic

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
**Framework Stack:** React 18 with TypeScript, Vite, Wouter for routing, Tailwind CSS (cyan/teal gradient theme, Material Design 3), shadcn/ui (Radix UI), lucide-react for icons, Inter font.
**Key Features:** Bureaucracy Manager (checklists, CAF appointments), Roommate Finder (lifestyle-based matching), Calendar/Reminders (deadline tracking), Internationalization (IT, EN, TR, AR with RTL), AI Chatbot (DocuBot using Google Gemini AI).

### Backend Architecture
**Technology Stack:** Node.js with Express.js, PostgreSQL database.
**Core Functionality:** User authentication (registration, login, verification, password reset), CRUD APIs for listings and dormitories, access restrictions based on user status.

### Application Structure
**Client-side routing:** `/`, `/bureaucracy`, `/roommates`, `/calendar`, `/settings`.
**Directory structure:** `components/`, `contexts/`, `hooks/`, `lib/`, `pages/`.

### Build and Deployment
**Development:** Vite dev server on port 5000 with Express backend proxy.
**Production:** `npm run build` (Vite for client, esbuild for server) and `npm start` for Autoscale deployment.

### Replit Environment Setup
**Status:** ✅ Fully configured and running
**Database:** PostgreSQL database connected (DATABASE_URL configured) with schema pushed via Drizzle
**Workflow:** Development server running on port 5000 (Express + Vite integration)
**Deployment:** ✅ Autoscale deployment configured with build and start scripts
**Host Configuration:** Vite configured with `host: 0.0.0.0`, `port: 5000`, and `allowedHosts: true` for Replit proxy compatibility
**Optional Configuration:** GEMINI_API_KEY (required for AI chatbot and document analysis features - app works without it)

### Optional Features
**AI Chatbot (DocuBot):** Requires `GEMINI_API_KEY` environment variable. The chatbot and document analysis features will show error messages if the key is not configured, but the rest of the app works without it.

## External Dependencies
- **UI Component Libraries:** `@radix-ui/`, `shadcn/ui`, `lucide-react`, `cmdk`, `embla-carousel-react`.
- **Form Management:** `react-hook-form`, `@hookform/resolvers`, `zod`.
- **Styling:** `tailwindcss`, `tailwind-merge`, `class-variance-authority`, `autoprefixer`.
- **Database:** `drizzle-orm`, `drizzle-kit`, `@neondatabase/serverless`, `drizzle-zod` (PostgreSQL).
- **Date Handling:** `date-fns`.
- **Maps:** `leaflet` (v1.9.4), `react-leaflet` (v4.2.1) - Interactive maps with OpenStreetMap.
- **AI:** Google's Gemini API.
- **Development Tools:** `Vite`, `TypeScript`, `@vitejs/plugin-react`, `tsx`, `esbuild`.
- **Replit Integration:** `@replit/vite-plugin-runtime-error-modal`, `@replit/vite-plugin-cartographer`, `@replit/vite-plugin-dev-banner`.
- **Session Management (Server-Side):** `express-session`, `connect-pg-simple`.