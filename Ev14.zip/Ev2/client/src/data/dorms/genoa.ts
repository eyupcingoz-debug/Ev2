import { Dorm } from './types';

export const genoaDorms: Dorm[] = [
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Asiago",
      it: "ALiSEO Asiago",
      tr: "ALiSEO Asiago",
      ar: "أليسيو أسياغو"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 420,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Asiago+Genova",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Canteen"],
    recommended: true
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Firenze-Zurigo",
      it: "ALiSEO Firenze-Zurigo",
      tr: "ALiSEO Firenze-Zurigo",
      ar: "أليسيو فيرينزي-زوريغو"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 260,
    priceMax: 440,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Firenze+Zurigo+Genova",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Mele",
      it: "ALiSEO Mele",
      tr: "ALiSEO Mele",
      ar: "أليسيو ميلي"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 240,
    priceMax: 410,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Mele+Genova",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Garden"]
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Savona",
      it: "ALiSEO Savona",
      tr: "ALiSEO Savona",
      ar: "أليسيو سافونا"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 230,
    priceMax: 400,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Savona",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Genoa",
    name: {
      en: "UniGe Cerco Alloggio",
      it: "UniGe Cerco Alloggio",
      tr: "UniGe Cerco Alloggio",
      ar: "يونيجي تشيركو ألوجيو"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 300,
    priceMax: 500,
    applicationLink: "https://www.studenti.unige.it/alloggi",
    mapLink: "https://maps.google.com/?q=Universita+Genova+Alloggi",
    features: ["Wi-Fi", "Study rooms", "Common areas"]
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Paid Accommodations",
      it: "ALiSEO Alloggi a Pagamento",
      tr: "ALiSEO Ücretli Konaklama",
      ar: "أليسيو السكن المدفوع"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 350,
    priceMax: 550,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Genova+Alloggi",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Gym"]
  },
  {
    city: "Genoa",
    name: {
      en: "UniGe Student House",
      it: "UniGe Student House",
      tr: "UniGe Öğrenci Evi",
      ar: "يونيجي بيت الطالب"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 320,
    priceMax: 520,
    applicationLink: "https://www.unige.it/",
    mapLink: "https://maps.google.com/?q=UniGe+Student+House+Genova",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Darsena",
      it: "ALiSEO Darsena",
      tr: "ALiSEO Darsena",
      ar: "أليسيو دارسينا"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 280,
    priceMax: 470,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Darsena+Genova",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Harbor view"]
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Gastaldi",
      it: "ALiSEO Gastaldi",
      tr: "ALiSEO Gastaldi",
      ar: "أليسيو غاستالدي"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 270,
    priceMax: 450,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Gastaldi+Genova",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Garden"]
  },
  {
    city: "Genoa",
    name: {
      en: "ALiSEO Via Balbi",
      it: "ALiSEO Via Balbi",
      tr: "ALiSEO Via Balbi",
      ar: "أليسيو فيا بالبي"
    },
    university: "Università di Genova",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 290,
    priceMax: 480,
    applicationLink: "https://www.aliseo.liguria.it/",
    mapLink: "https://maps.google.com/?q=ALiSEO+Via+Balbi+Genova",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Central location"]
  }
];
