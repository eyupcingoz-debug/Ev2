import { Dorm } from './types';

export const piacenzaDorms: Dorm[] = [
  {
    city: "Piacenza",
    name: {
      en: "Polimi Vicinato Solidale",
      it: "Polimi Vicinato Solidale",
      tr: "Polimi Vicinato Solidale",
      ar: "بوليمي فيتشيناتو سوليدالي"
    },
    university: "Politecnico di Milano - Piacenza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 200,
    priceMax: 350,
    applicationLink: "https://www.polimi.it/",
    mapLink: "https://maps.google.com/?q=Polimi+Piacenza+Residenze",
    features: ["Wi-Fi", "Study rooms", "Common areas", "Bike parking"],
    recommended: true
  },
  {
    city: "Piacenza",
    name: {
      en: "Collegio Morigi-De Cesaris",
      it: "Collegio Morigi-De Cesaris",
      tr: "Collegio Morigi-De Cesaris",
      ar: "كلية موريجي-دي تشيزاريس"
    },
    university: "Politecnico di Milano - Piacenza",
    gender: "Mixed",
    roomTypes: ["Single"],
    priceMin: 250,
    priceMax: 400,
    applicationLink: "https://www.collegiomorigi.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Morigi+Piacenza",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Chapel", "Library"],
    recommended: true
  },
  {
    city: "Piacenza",
    name: {
      en: "Collegio San Vincenzo",
      it: "Collegio San Vincenzo",
      tr: "Collegio San Vincenzo",
      ar: "كلية سان فينتشنزو"
    },
    university: "Università Cattolica",
    gender: "Male",
    roomTypes: ["Single"],
    priceMin: 280,
    priceMax: 450,
    applicationLink: "https://piacenza.unicatt.it/",
    mapLink: "https://maps.google.com/?q=Collegio+San+Vincenzo+Piacenza",
    features: ["Wi-Fi", "Study rooms", "Chapel", "Library"]
  },
  {
    city: "Piacenza",
    name: {
      en: "Cattolica Student Residences",
      it: "Residenze Cattolica",
      tr: "Cattolica Yurtları",
      ar: "مساكن كاتوليكا"
    },
    university: "Università Cattolica",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 300,
    priceMax: 480,
    applicationLink: "https://piacenza.unicatt.it/residenze",
    mapLink: "https://maps.google.com/?q=Cattolica+Residenze+Piacenza",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Piacenza",
    name: {
      en: "Comune Piacenza Student Housing",
      it: "Comune Piacenza Alloggi Studenti",
      tr: "Piacenza Belediyesi Öğrenci Konutları",
      ar: "سكن الطلاب بلدية بياتشنزا"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 220,
    priceMax: 380,
    applicationLink: "https://www.comune.piacenza.it/",
    mapLink: "https://maps.google.com/?q=Comune+Piacenza+Alloggi",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Piacenza",
    name: {
      en: "Private Student Houses",
      it: "Case dello Studente Private",
      tr: "Özel Öğrenci Evleri",
      ar: "منازل الطلاب الخاصة"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 420,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=Student+Houses+Piacenza",
    features: ["Wi-Fi", "Common kitchen", "Laundry", "Garden"]
  }
];
