export interface CodiceFiscaleOffice {
  key: string;
  name: string;
  url: string;
}

export const CODICE_FISCALE_OFFICES: CodiceFiscaleOffice[] = [
  {
    key: 'milano',
    name: 'Milano 1 – Agenzia delle Entrate',
    url: 'https://www.agenziaentrate.gov.it/portale/web/guest/contatta-l-agenzia/sedi/regione-lombardia/direzione-regionale-lombardia/milano-1',
  },
  {
    key: 'pavia',
    name: 'Pavia – Agenzia delle Entrate',
    url: 'https://www.agenziaentrate.gov.it/portale/web/guest/contatta-l-agenzia/sedi/regione-lombardia/direzione-regionale-lombardia/pavia',
  },
  {
    key: 'monza',
    name: 'Monza – Agenzia delle Entrate',
    url: 'https://www.agenziaentrate.gov.it/portale/web/guest/contatta-l-agenzia/sedi/regione-lombardia/direzione-regionale-lombardia/monza',
  },
  {
    key: 'bologna',
    name: 'Bologna – Agenzia delle Entrate',
    url: 'https://www.agenziaentrate.gov.it/portale/web/guest/contatta-l-agenzia/sedi/regione-emilia-romagna/direzione-regionale-emilia-romagna/bologna',
  },
  {
    key: 'torino',
    name: 'Torino – Agenzia delle Entrate',
    url: 'https://www.agenziaentrate.gov.it/portale/web/guest/contatta-l-agenzia/sedi/regione-piemonte/direzione-regionale-piemonte/torino',
  },
  {
    key: 'roma',
    name: 'Roma 1 – Agenzia delle Entrate',
    url: 'https://www.agenziaentrate.gov.it/portale/web/guest/contatta-l-agenzia/sedi/regione-lazio/direzione-regionale-lazio/roma-1',
  },
];
