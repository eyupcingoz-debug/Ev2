import { useState } from 'react';
import { useLocation } from 'wouter';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import LanguageSwitcher from '@/components/LanguageSwitcher';

interface OnboardingSlide {
  titleKey: string;
  subtitleKey?: string;
}

const slides: OnboardingSlide[] = [
  {
    titleKey: 'onboardingSlide1Title',
  },
  {
    titleKey: 'onboardingSlide2Title',
  },
  {
    titleKey: 'onboardingSlide3Title',
    subtitleKey: 'onboardingSlide3Subtitle',
  },
  {
    titleKey: 'onboardingSlide4Title',
    subtitleKey: 'onboardingSlide4Subtitle',
  },
  {
    titleKey: 'onboardingSlide5Title',
  },
];

interface OnboardingProps {
  onComplete: () => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [, setLocation] = useLocation();
  const { language, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showAuthButtons, setShowAuthButtons] = useState(false);

  const isLastSlide = currentSlide === slides.length - 1;

  const handleSkip = () => {
    localStorage.setItem('onboardingSeen', 'true');
    onComplete();
    setLocation('/');
  };

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
      setShowAuthButtons(false);
    }
  };

  const handleGetStarted = () => {
    setShowAuthButtons(true);
  };

  const handleAuth = (destination: '/register' | '/login') => {
    localStorage.setItem('onboardingSeen', 'true');
    onComplete();
    setLocation(destination);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black overflow-hidden">
      {/* Language Switcher - Top Left */}
      <div className="absolute top-4 left-4 z-50">
        <LanguageSwitcher minimal />
      </div>

      {/* Skip Button - Top Right (Only on last slide when auth buttons shown) */}
      {isLastSlide && showAuthButtons && (
        <button
          onClick={handleSkip}
          className="absolute top-4 right-4 z-50 p-2 text-white/70 hover:text-white transition-colors"
          aria-label={t('onboardingSkip')}
        >
          <X className="h-5 w-5" />
        </button>
      )}

      {/* Animated Gradient Background */}
      <div className="absolute inset-0">
        {/* Background Gradients for each slide */}
        <div className={`absolute inset-0 transition-opacity duration-700 ${currentSlide === 0 ? 'opacity-100' : 'opacity-0'}`}>
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-black animate-gradient-slow" />
        </div>
        <div className={`absolute inset-0 transition-opacity duration-700 ${currentSlide === 1 ? 'opacity-100' : 'opacity-0'}`}>
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-900 via-teal-900 to-black animate-gradient-slow" />
        </div>
        <div className={`absolute inset-0 transition-opacity duration-700 ${currentSlide === 2 ? 'opacity-100' : 'opacity-0'}`}>
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-black animate-gradient-slow" />
        </div>
        <div className={`absolute inset-0 transition-opacity duration-700 ${currentSlide === 3 ? 'opacity-100' : 'opacity-0'}`}>
          <div className="absolute inset-0 bg-gradient-to-br from-pink-900 via-rose-900 to-black animate-gradient-slow" />
        </div>
        <div className={`absolute inset-0 transition-opacity duration-700 ${currentSlide === 4 ? 'opacity-100' : 'opacity-0'}`}>
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-cyan-900 to-black animate-gradient-slow" />
        </div>
        
        {/* Floating particles effect */}
        <div className="absolute inset-0 overflow-hidden opacity-30">
          <div className="absolute w-96 h-96 bg-cyan-500 rounded-full filter blur-3xl animate-float -top-48 -left-48" />
          <div className="absolute w-96 h-96 bg-purple-500 rounded-full filter blur-3xl animate-float-delayed top-1/2 -right-48" />
          <div className="absolute w-96 h-96 bg-pink-500 rounded-full filter blur-3xl animate-float-slow bottom-0 left-1/2" />
        </div>
        
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60" />
      </div>

      {/* Content */}
      <div className={`relative h-full flex flex-col justify-end pb-safe ${isRTL ? 'rtl' : 'ltr'}`}>
        <div className="px-6 pb-8 space-y-6">
          {/* Text Content */}
          <div className="space-y-2 text-center">
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white leading-tight tracking-wide">
              {t(slides[currentSlide].titleKey)}
            </h1>
            {slides[currentSlide].subtitleKey && (
              <p className="text-base md:text-lg text-white/90">
                {t(slides[currentSlide].subtitleKey)}
              </p>
            )}
          </div>

          {/* Progress Indicator */}
          <div className="flex justify-center gap-2">
            {slides.map((_, index) => (
              <div
                key={index}
                className={`h-1 rounded-full transition-all duration-300 ${
                  index === currentSlide ? 'w-8 bg-white' : 'w-1 bg-white/30'
                }`}
              />
            ))}
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            {!isLastSlide ? (
              // Continue button for slides 1-4
              <Button
                onClick={handleNext}
                size="lg"
                className="w-full py-6 text-lg font-semibold bg-white text-black hover:bg-white/90 rounded-2xl shadow-2xl"
              >
                {t('onboardingContinue')}
              </Button>
            ) : !showAuthButtons ? (
              // "Get Started" button on last slide
              <Button
                onClick={handleGetStarted}
                size="lg"
                className="w-full py-6 text-lg font-semibold bg-white text-black hover:bg-white/90 rounded-2xl shadow-2xl"
              >
                {t('onboardingStart')}
              </Button>
            ) : (
              // Login/Register buttons after clicking "Get Started"
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  onClick={() => handleAuth('/login')}
                  size="lg"
                  variant="outline"
                  className="flex-1 py-6 text-lg font-semibold bg-transparent border-2 border-white text-white hover:bg-white/10 rounded-2xl"
                >
                  {t('login')}
                </Button>
                <Button
                  onClick={() => handleAuth('/register')}
                  size="lg"
                  className="flex-1 py-6 text-lg font-semibold bg-white text-black hover:bg-white/90 rounded-2xl shadow-2xl"
                >
                  {t('register')}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
