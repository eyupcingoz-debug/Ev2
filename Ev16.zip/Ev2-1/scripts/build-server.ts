import { build } from "esbuild";
import { fileURLToPath } from "url";
import { dirname, resolve } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

await build({
  entryPoints: [resolve(__dirname, "../server/index.ts")],
  outfile: resolve(__dirname, "../dist/index.js"),
  bundle: true,
  platform: "node",
  target: "node20",
  format: "esm",
  external: ["express", "drizzle-orm", "@neondatabase/serverless"],
  banner: {
    js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);",
  },
});

console.log("Server build complete!");
