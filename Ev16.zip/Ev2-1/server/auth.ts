import bcrypt from "bcrypt";
import { randomUUID } from "crypto";
import { storage } from "./storage";
import type { InsertUser } from "@shared/schema";
import { Resend } from "resend";

const SALT_ROUNDS = 10;
const resend = new Resend(process.env.RESEND_API_KEY);

export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

export function generateVerificationToken(): { token: string; expiry: Date } {
  const token = randomUUID();
  const expiry = new Date();
  expiry.setHours(expiry.getHours() + 24); // 24 hour expiry
  return { token, expiry };
}

export async function sendVerificationEmail(email: string, token: string, firstName: string, language: string = 'it') {
  // Get the app URL from environment or construct it
  const appUrl = process.env.REPL_SLUG 
    ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
    : `http://localhost:5000`;
  
  const verificationLink = `${appUrl}/verify-email?token=${token}`;
  
  // Multilingual email content
  const emailContent = {
    it: {
      subject: "Verifica il tuo account - Solvia",
      greeting: `Ciao ${firstName},`,
      message: "Grazie per esserti registrato! Per attivare il tuo account, clicca sul pulsante qui sotto:",
      button: "Verifica Account",
      expires: "Questo link è valido per 24 ore.",
      ignore: "Se non hai creato questo account, ignora questa email."
    },
    en: {
      subject: "Verify your account - Solvia",
      greeting: `Hello ${firstName},`,
      message: "Thank you for signing up! To activate your account, click the button below:",
      button: "Verify Account",
      expires: "This link is valid for 24 hours.",
      ignore: "If you didn't create this account, please ignore this email."
    },
    tr: {
      subject: "Hesabını doğrula - Solvia",
      greeting: `Merhaba ${firstName},`,
      message: "Kayıt olduğunuz için teşekkürler! Hesabınızı aktifleştirmek için aşağıdaki butona tıklayın:",
      button: "Hesabımı Doğrula",
      expires: "Bu link 24 saat geçerlidir.",
      ignore: "Bu hesabı siz oluşturmadıysanız, bu e-postayı görmezden gelin."
    },
    ar: {
      subject: "تحقق من حسابك - Solvia",
      greeting: `مرحبا ${firstName}،`,
      message: "شكرا لتسجيلك! لتفعيل حسابك، انقر على الزر أدناه:",
      button: "تحقق من الحساب",
      expires: "هذا الرابط صالح لمدة 24 ساعة.",
      ignore: "إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذا البريد الإلكتروني."
    }
  };

  const lang = emailContent[language as keyof typeof emailContent] || emailContent.it;

  try {
    // Send email via Resend
    const { data, error } = await resend.emails.send({
      from: 'Solvia <onboarding@resend.dev>',
      to: [email],
      subject: lang.subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #0ea5e9;">${lang.greeting}</h2>
          <p style="font-size: 16px; line-height: 1.6;">${lang.message}</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationLink}" 
               style="background-color: #0ea5e9; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              ${lang.button}
            </a>
          </div>
          <p style="font-size: 14px; color: #666; margin-top: 30px;">${lang.expires}</p>
          <p style="font-size: 14px; color: #666;">${lang.ignore}</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          <p style="font-size: 12px; color: #999;">Link: ${verificationLink}</p>
        </div>
      `,
    });

    if (error) {
      console.error('Resend email error:', error);
      return { success: false, message: error.message };
    }

    console.log(`✅ Verification email sent to ${email} (ID: ${data?.id})`);
    return { success: true, message: "Verification email sent successfully", emailId: data?.id };
  } catch (error) {
    console.error('Failed to send verification email:', error);
    return { success: false, message: "Failed to send email" };
  }
}

export async function sendPasswordResetEmail(email: string, token: string, firstName: string, language: string = 'it') {
  const appUrl = process.env.REPL_SLUG 
    ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
    : `http://localhost:5000`;
  
  const resetLink = `${appUrl}/reset-password?token=${token}`;
  
  const emailContent = {
    it: {
      subject: "Reimposta la tua password - Solvia",
      greeting: `Ciao ${firstName},`,
      message: "Abbiamo ricevuto una richiesta per reimpostare la tua password. Clicca sul pulsante qui sotto:",
      button: "Reimposta Password",
      expires: "Questo link è valido per 1 ora.",
      ignore: "Se non hai richiesto questa reimpostazione, ignora questa email."
    },
    en: {
      subject: "Reset your password - Solvia",
      greeting: `Hello ${firstName},`,
      message: "We received a request to reset your password. Click the button below:",
      button: "Reset Password",
      expires: "This link is valid for 1 hour.",
      ignore: "If you didn't request this reset, please ignore this email."
    },
    tr: {
      subject: "Şifreni sıfırla - Solvia",
      greeting: `Merhaba ${firstName},`,
      message: "Şifrenizi sıfırlama talebi aldık. Aşağıdaki butona tıklayın:",
      button: "Şifreyi Sıfırla",
      expires: "Bu link 1 saat geçerlidir.",
      ignore: "Bu sıfırlama talebini siz yapmadıysanız, bu e-postayı görmezden gelin."
    },
    ar: {
      subject: "إعادة تعيين كلمة المرور - Solvia",
      greeting: `مرحبا ${firstName}،`,
      message: "تلقينا طلبًا لإعادة تعيين كلمة المرور الخاصة بك. انقر على الزر أدناه:",
      button: "إعادة تعيين كلمة المرور",
      expires: "هذا الرابط صالح لمدة ساعة واحدة.",
      ignore: "إذا لم تطلب هذه الإعادة، يرجى تجاهل هذا البريد الإلكتروني."
    }
  };

  const lang = emailContent[language as keyof typeof emailContent] || emailContent.it;

  try {
    // Send email via Resend
    const { data, error } = await resend.emails.send({
      from: 'Solvia <onboarding@resend.dev>',
      to: [email],
      subject: lang.subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #0ea5e9;">${lang.greeting}</h2>
          <p style="font-size: 16px; line-height: 1.6;">${lang.message}</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetLink}" 
               style="background-color: #0ea5e9; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              ${lang.button}
            </a>
          </div>
          <p style="font-size: 14px; color: #666; margin-top: 30px;">${lang.expires}</p>
          <p style="font-size: 14px; color: #666;">${lang.ignore}</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          <p style="font-size: 12px; color: #999;">Link: ${resetLink}</p>
        </div>
      `,
    });

    if (error) {
      console.error('Resend email error:', error);
      return { success: false, message: error.message };
    }

    console.log(`✅ Password reset email sent to ${email} (ID: ${data?.id})`);
    return { success: true, message: "Password reset email sent successfully", emailId: data?.id };
  } catch (error) {
    console.error('Failed to send password reset email:', error);
    return { success: false, message: "Failed to send email" };
  }
}
