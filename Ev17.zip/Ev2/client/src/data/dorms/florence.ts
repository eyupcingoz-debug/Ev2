import { Dorm } from './types';

export const florenceDorms: Dorm[] = [
  {
    city: "Florence",
    name: {
      en: "DSU Calamandrei",
      it: "DSU Calamandrei",
      tr: "DSU Calamandrei",
      ar: "DSU كالاماندريي"
    },
    university: "Università di Firenze",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.dsu.toscana.it/",
    mapLink: "https://maps.google.com/?q=DSU+Calamandrei+Firenze",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"],
    recommended: true
  },
  {
    city: "Florence",
    name: {
      en: "DSU Caponnetto",
      it: "DSU Caponnetto",
      tr: "DSU Caponnetto",
      ar: "DSU كابونيتو"
    },
    university: "Università di Firenze",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 260,
    priceMax: 460,
    applicationLink: "https://www.dsu.toscana.it/",
    mapLink: "https://maps.google.com/?q=DSU+Caponnetto+Firenze",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Garden"],
    recommended: true
  },
  {
    city: "Florence",
    name: {
      en: "DSU Salvemini",
      it: "DSU Salvemini",
      tr: "DSU Salvemini",
      ar: "DSU سالفيميني"
    },
    university: "Università di Firenze",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 270,
    priceMax: 470,
    applicationLink: "https://www.dsu.toscana.it/",
    mapLink: "https://maps.google.com/?q=DSU+Salvemini+Firenze",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Sports facilities"]
  },
  {
    city: "Florence",
    name: {
      en: "DSU Toscana General List",
      it: "DSU Toscana Lista Generale",
      tr: "DSU Toscana Genel Liste",
      ar: "DSU توسكانا القائمة العامة"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 240,
    priceMax: 480,
    applicationLink: "https://www.dsu.toscana.it/",
    mapLink: "https://maps.google.com/?q=DSU+Toscana+Firenze",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Florence",
    name: {
      en: "Camplus Rifredi",
      it: "Camplus Rifredi",
      tr: "Camplus Rifredi",
      ar: "كامبلوس ريفريدي"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 600,
    priceMax: 850,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Rifredi+Firenze",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cafeteria"]
  },
  {
    city: "Florence",
    name: {
      en: "CX Firenze",
      it: "CX Firenze",
      tr: "CX Firenze",
      ar: "سي إكس فلورنسا"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 650,
    priceMax: 900,
    applicationLink: "https://www.cxliving.com/",
    mapLink: "https://maps.google.com/?q=CX+Firenze",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cinema room"]
  },
  {
    city: "Florence",
    name: {
      en: "UniFi Partner Residences",
      it: "UniFi Residenze Convenzionate",
      tr: "UniFi Anlaşmalı Yurtlar",
      ar: "مساكن UniFi الشريكة"
    },
    university: "Università di Firenze",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 350,
    priceMax: 550,
    applicationLink: "https://www.unifi.it/",
    mapLink: "https://maps.google.com/?q=UniFi+Residenze+Firenze",
    features: ["Wi-Fi", "Study rooms", "Common areas", "Laundry"]
  }
];
