import { useState } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail, Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';

export default function ForgotPassword() {
  const [, setLocation] = useLocation();
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();
  
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, language }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to send reset code');
      }

      setSent(true);
      toast({
        title: t('success') || 'Başarılı',
        description: t('resetCodeSent') || 'Şifre sıfırlama kodu e-posta adresinize gönderildi.',
      });

      // Redirect to reset password page with email
      setTimeout(() => {
        setLocation(`/reset-password?email=${encodeURIComponent(email)}`);
      }, 2000);
    } catch (error: any) {
      toast({
        title: t('error') || 'Hata',
        description: error.message || t('sendFailed') || 'Kod gönderilemedi',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container max-w-md mx-auto py-12 px-4">
      <Card className="shadow-xl border-2 border-cyan-200">
        <CardHeader className="text-center">
          <Mail className="h-16 w-16 mx-auto text-cyan-500 mb-4" />
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-500 bg-clip-text text-transparent">
            {t('forgotPassword') || 'Şifremi Unuttum'}
          </CardTitle>
          <CardDescription className="text-base mt-2">
            {t('forgotPasswordDescription') || 'E-posta adresinizi girin, size şifre sıfırlama kodu gönderelim.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-lg">
                {t('email') || 'E-posta'}
              </Label>
              <Input
                id="email"
                type="email"
                placeholder={t('emailPlaceholder') || 'ornek@email.com'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="border-cyan-300 focus:border-cyan-500"
              />
            </div>

            <Button
              type="submit"
              disabled={loading || sent}
              className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-lg py-6"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('sending') || 'Gönderiliyor...'}
                </>
              ) : sent ? (
                t('codeSent') || 'Kod Gönderildi'
              ) : (
                t('sendCode') || 'Kod Gönder'
              )}
            </Button>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600">
                {t('rememberPassword') || 'Şifrenizi hatırladınız mı?'}
              </p>
              <Button
                type="button"
                variant="link"
                onClick={() => setLocation('/login')}
                className="text-cyan-600 hover:text-cyan-700"
              >
                {t('backToLogin') || 'Giriş Yap'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
