import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const { language } = useLanguage();
  const t = useTranslation(language);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await login(email, password);
      toast({
        title: t('loginSuccess') || 'Giriş başarılı',
        description: t('welcomeBack') || 'Hoş geldiniz!',
      });
      setLocation('/');
    } catch (error: any) {
      toast({
        title: t('loginError') || 'Giriş hatası',
        description: error.message || t('invalidCredentials') || 'E-posta veya şifre hatalı',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container max-w-md mx-auto py-12 px-4">
      <Card className="shadow-xl border-2 border-cyan-200">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-500 bg-clip-text text-transparent">
            {t('login') || 'Giriş Yap'}
          </CardTitle>
          <CardDescription>
            {t('loginDescription') || 'Hesabınıza giriş yapın'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">{t('email') || 'E-posta'}</Label>
              <Input
                id="email"
                type="email"
                placeholder={t('emailPlaceholder') || 'ornek@email.com'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="border-cyan-200 focus:border-cyan-500"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">{t('password') || 'Şifre'}</Label>
                <Button
                  type="button"
                  variant="link"
                  onClick={() => setLocation('/forgot-password')}
                  className="text-xs text-cyan-600 hover:text-cyan-700 p-0 h-auto"
                >
                  {t('forgotPassword') || 'Şifremi unuttum'}
                </Button>
              </div>
              <Input
                id="password"
                type="password"
                placeholder={t('passwordPlaceholder') || '••••••••'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
                className="border-cyan-200 focus:border-cyan-500"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 shadow-lg"
              disabled={loading}
            >
              {loading ? (t('loading') || 'Yükleniyor...') : (t('login') || 'Giriş Yap')}
            </Button>

            <div className="text-center space-y-2">
              <Button
                type="button"
                variant="link"
                onClick={() => setLocation('/register')}
                className="text-cyan-600"
              >
                {t('dontHaveAccount') || 'Hesabınız yok mu? Kayıt olun'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
