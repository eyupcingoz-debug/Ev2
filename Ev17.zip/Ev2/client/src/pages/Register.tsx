import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export default function Register() {
  const [, setLocation] = useLocation();
  const { register } = useAuth();
  const { toast } = useToast();
  const { language } = useLanguage();
  const t = useTranslation(language);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    city: '',
    nationality: '',
    password: '',
    confirmPassword: '',
    gdprConsent: false,
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: t('error') || 'Hata',
        description: t('passwordMismatch') || 'Şifreler eşleşmiyor',
        variant: 'destructive',
      });
      return;
    }

    if (!formData.gdprConsent) {
      toast({
        title: t('error') || 'Hata',
        description: t('gdprRequired') || 'KVKK onayı gereklidir',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      await register({
        ...formData,
        language,
      });
      
      toast({
        title: t('registerSuccess') || 'Kayıt başarılı!',
        description: t('verifyEmailSent') || 'E-posta adresinize doğrulama kodu gönderildi.',
      });
      
      // Redirect to verification page with email parameter
      setLocation(`/verify-email?email=${encodeURIComponent(formData.email)}`);
    } catch (error: any) {
      toast({
        title: t('registerError') || 'Kayıt hatası',
        description: error.message || t('registrationFailed') || 'Kayıt oluşturulamadı',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="container max-w-2xl mx-auto py-12 px-4">
      <Card className="shadow-xl border-2 border-cyan-200">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-500 bg-clip-text text-transparent">
            {t('register') || 'Kayıt Ol'}
          </CardTitle>
          <CardDescription>
            {t('registerDescription') || 'Yeni hesap oluşturun'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">{t('firstName') || 'Ad'} *</Label>
                <Input
                  id="firstName"
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => handleChange('firstName', e.target.value)}
                  required
                  className="border-cyan-200 focus:border-cyan-500"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="lastName">{t('lastName') || 'Soyad'} *</Label>
                <Input
                  id="lastName"
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => handleChange('lastName', e.target.value)}
                  required
                  className="border-cyan-200 focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">{t('email') || 'E-posta'} *</Label>
              <Input
                id="email"
                type="email"
                placeholder={t('emailPlaceholder') || 'ornek@email.com'}
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                required
                className="border-cyan-200 focus:border-cyan-500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">{t('phone') || 'Telefon'} *</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+39 123 456 7890"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                required
                className="border-cyan-200 focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">{t('city') || 'Şehir'} *</Label>
                <Input
                  id="city"
                  type="text"
                  placeholder="Milano"
                  value={formData.city}
                  onChange={(e) => handleChange('city', e.target.value)}
                  required
                  className="border-cyan-200 focus:border-cyan-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="nationality">{t('nationality') || 'Uyruk'} ({t('optional') || 'İsteğe bağlı'})</Label>
                <Input
                  id="nationality"
                  type="text"
                  placeholder="Türkiye"
                  value={formData.nationality}
                  onChange={(e) => handleChange('nationality', e.target.value)}
                  className="border-cyan-200 focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="password">{t('password') || 'Şifre'} *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => handleChange('password', e.target.value)}
                  required
                  minLength={8}
                  className="border-cyan-200 focus:border-cyan-500"
                />
                <p className="text-xs text-gray-500">{t('minPasswordLength') || 'En az 8 karakter'}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">{t('confirmPassword') || 'Şifre Tekrar'} *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={(e) => handleChange('confirmPassword', e.target.value)}
                  required
                  minLength={8}
                  className="border-cyan-200 focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="flex items-start space-x-2 py-2">
              <Checkbox
                id="gdpr"
                checked={formData.gdprConsent}
                onCheckedChange={(checked) => handleChange('gdprConsent', checked as boolean)}
                required
              />
              <Label htmlFor="gdpr" className="text-sm leading-relaxed cursor-pointer">
                {t('gdprConsent') || 'KVKK / GDPR kurallarını kabul ediyorum. Kişisel verilerimin işlenmesine izin veriyorum.'} *
              </Label>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 shadow-lg"
              disabled={loading}
            >
              {loading ? (t('loading') || 'Yükleniyor...') : (t('register') || 'Kayıt Ol')}
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                onClick={() => setLocation('/login')}
                className="text-cyan-600"
              >
                {t('alreadyHaveAccount') || 'Zaten hesabınız var mı? Giriş yapın'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
