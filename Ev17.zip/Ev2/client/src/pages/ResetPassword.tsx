import { useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, KeyRound, Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';

export default function ResetPassword() {
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();
  
  // Get email from URL parameter
  const params = new URLSearchParams(searchParams);
  const email = params.get('email') || '';
  
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [reset, setReset] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (code.length !== 6) {
      toast({
        title: t('error') || 'Hata',
        description: t('codeLength') || 'Doğrulama kodu 6 haneli olmalıdır',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({
        title: t('error') || 'Hata',
        description: t('passwordMismatch') || 'Şifreler eşleşmiyor',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword.length < 8) {
      toast({
        title: t('error') || 'Hata',
        description: t('passwordMinLength') || 'Şifre en az 8 karakter olmalıdır',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: code, newPassword }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to reset password');
      }

      setReset(true);
      toast({
        title: t('success') || 'Başarılı',
        description: t('passwordReset') || 'Şifreniz başarıyla sıfırlandı!',
      });
      
      // Redirect to login after 2 seconds
      setTimeout(() => {
        setLocation('/login');
      }, 2000);
    } catch (error: any) {
      toast({
        title: t('resetError') || 'Sıfırlama hatası',
        description: error.message || t('resetFailed') || 'Kod hatalı veya süresi dolmuş',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (reset) {
    return (
      <div className="container max-w-md mx-auto py-12 px-4">
        <Card className="shadow-xl border-2 border-green-200">
          <CardContent className="text-center space-y-4 pt-8">
            <CheckCircle2 className="h-24 w-24 mx-auto text-green-500" />
            <h2 className="text-2xl font-bold text-green-700">
              {t('passwordResetSuccess') || 'Şifre Sıfırlandı!'}
            </h2>
            <p className="text-gray-600">
              {t('redirectingToLogin') || 'Giriş sayfasına yönlendiriliyorsunuz...'}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-md mx-auto py-12 px-4">
      <Card className="shadow-xl border-2 border-cyan-200">
        <CardHeader className="text-center">
          <KeyRound className="h-16 w-16 mx-auto text-cyan-500 mb-4" />
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-500 bg-clip-text text-transparent">
            {t('resetPassword') || 'Şifre Sıfırla'}
          </CardTitle>
          <CardDescription className="text-base mt-2">
            {email 
              ? `${t('codeSentTo') || 'Kod gönderildi:'} ${email}`
              : t('enterCodeAndNewPassword') || '6 haneli kodu ve yeni şifrenizi girin'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="code" className="text-lg">
                {t('verificationCode') || 'Doğrulama Kodu'}
              </Label>
              <Input
                id="code"
                type="text"
                inputMode="numeric"
                placeholder="000000"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                maxLength={6}
                required
                className="text-center text-2xl font-mono tracking-widest border-cyan-300 focus:border-cyan-500"
              />
              <p className="text-sm text-gray-500 text-center">
                {t('codeExpiresIn') || '1 saat içinde geçerli'}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="newPassword">
                {t('newPassword') || 'Yeni Şifre'}
              </Label>
              <Input
                id="newPassword"
                type="password"
                placeholder={t('passwordPlaceholder') || '••••••••'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={8}
                className="border-cyan-300 focus:border-cyan-500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">
                {t('confirmPassword') || 'Şifre Tekrar'}
              </Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder={t('passwordPlaceholder') || '••••••••'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={8}
                className="border-cyan-300 focus:border-cyan-500"
              />
            </div>

            <Button
              type="submit"
              disabled={loading || code.length !== 6}
              className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-lg py-6"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('resetting') || 'Sıfırlanıyor...'}
                </>
              ) : (
                t('resetPassword') || 'Şifre Sıfırla'
              )}
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                onClick={() => setLocation('/login')}
                className="text-cyan-600 hover:text-cyan-700"
              >
                {t('backToLogin') || 'Giriş Yap'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
