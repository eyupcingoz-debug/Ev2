import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation, type Language } from '@/lib/i18n';
import { Check } from 'lucide-react';

const languageOptions: { code: Language; name: string; nativeName: string; flag: string }[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦' },
];

export default function Settings() {
  const { language, setLanguage } = useLanguage();
  const t = useTranslation(language);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('settings')}</h1>
        <p className="text-muted-foreground">{t('customizeExperience')}</p>
      </div>

      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>{t('language')}</CardTitle>
            <CardDescription>{t('selectPreferredLanguage')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {languageOptions.map(({ code, name, nativeName, flag }) => (
                <Button
                  key={code}
                  variant={language === code ? 'default' : 'outline'}
                  className="justify-start gap-3 h-auto py-4"
                  onClick={() => setLanguage(code)}
                  data-testid={`button-lang-${code}`}
                >
                  <span className="text-2xl">{flag}</span>
                  <div className="flex-1 text-left">
                    <div className="font-semibold">{nativeName}</div>
                    <div className="text-xs opacity-80">{name}</div>
                  </div>
                  {language === code && <Check className="h-5 w-5" />}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
