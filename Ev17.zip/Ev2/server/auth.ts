import bcrypt from "bcrypt";
import { randomUUID } from "crypto";
import { storage } from "./storage";
import type { InsertUser } from "@shared/schema";
import { Resend } from "resend";

const SALT_ROUNDS = 10;

function getResendClient() {
  if (!process.env.RESEND_API_KEY) {
    throw new Error("RESEND_API_KEY is not configured");
  }
  return new Resend(process.env.RESEND_API_KEY);
}

export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

export function generateVerificationToken(): { token: string; expiry: Date } {
  // Generate 6-digit verification code
  const token = Math.floor(100000 + Math.random() * 900000).toString();
  const expiry = new Date();
  expiry.setHours(expiry.getHours() + 24); // 24 hour expiry
  return { token, expiry };
}

export async function sendVerificationEmail(email: string, token: string, firstName: string, language: string = 'it') {
  // Multilingual email content
  const emailContent = {
    it: {
      subject: "Il tuo codice di verifica - Solvia",
      greeting: `Ciao ${firstName},`,
      message: "Grazie per esserti registrato! Ecco il tuo codice di verifica a 6 cifre:",
      codeLabel: "Codice di verifica:",
      instruction: "Inserisci questo codice nella pagina di verifica per attivare il tuo account.",
      expires: "Questo codice è valido per 24 ore.",
      ignore: "Se non hai creato questo account, ignora questa email."
    },
    en: {
      subject: "Your verification code - Solvia",
      greeting: `Hello ${firstName},`,
      message: "Thank you for signing up! Here is your 6-digit verification code:",
      codeLabel: "Verification Code:",
      instruction: "Enter this code on the verification page to activate your account.",
      expires: "This code is valid for 24 hours.",
      ignore: "If you didn't create this account, please ignore this email."
    },
    tr: {
      subject: "Doğrulama kodunuz - Solvia",
      greeting: `Merhaba ${firstName},`,
      message: "Kayıt olduğunuz için teşekkürler! İşte 6 haneli doğrulama kodunuz:",
      codeLabel: "Doğrulama Kodu:",
      instruction: "Hesabınızı aktifleştirmek için bu kodu doğrulama sayfasına girin.",
      expires: "Bu kod 24 saat geçerlidir.",
      ignore: "Bu hesabı siz oluşturmadıysanız, bu e-postayı görmezden gelin."
    },
    ar: {
      subject: "رمز التحقق الخاص بك - Solvia",
      greeting: `مرحبا ${firstName}،`,
      message: "شكرا لتسجيلك! إليك رمز التحقق المكون من 6 أرقام:",
      codeLabel: "رمز التحقق:",
      instruction: "أدخل هذا الرمز في صفحة التحقق لتفعيل حسابك.",
      expires: "هذا الرمز صالح لمدة 24 ساعة.",
      ignore: "إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذا البريد الإلكتروني."
    }
  };

  const lang = emailContent[language as keyof typeof emailContent] || emailContent.it;

  // Log verification code in development mode
  if (process.env.NODE_ENV !== 'production') {
    console.log('🔑 VERIFICATION CODE for', email, ':', token);
    console.log('⏰ Expires:', new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleString());
  }

  try {
    const resend = getResendClient();
    // Send email via Resend
    const { data, error } = await resend.emails.send({
      from: 'Solvia <onboarding@resend.dev>',
      to: [email],
      subject: lang.subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #0ea5e9;">${lang.greeting}</h2>
          <p style="font-size: 16px; line-height: 1.6;">${lang.message}</p>
          <div style="text-align: center; margin: 30px 0; background-color: #f0f9ff; padding: 30px; border-radius: 10px;">
            <p style="font-size: 14px; color: #0369a1; margin: 0 0 10px 0; font-weight: 600;">${lang.codeLabel}</p>
            <div style="font-size: 36px; font-weight: bold; color: #0ea5e9; letter-spacing: 8px; font-family: 'Courier New', monospace;">
              ${token}
            </div>
          </div>
          <p style="font-size: 15px; line-height: 1.6; color: #374151;">${lang.instruction}</p>
          <p style="font-size: 14px; color: #666; margin-top: 30px;">${lang.expires}</p>
          <p style="font-size: 14px; color: #666;">${lang.ignore}</p>
        </div>
      `,
    });

    if (error) {
      console.error('Resend email error:', error);
      // In development, still return success so user can use the code from console
      if (process.env.NODE_ENV !== 'production') {
        console.log('⚠️ Email failed but code is available in console above');
        return { success: true, message: "Code generated (check console in dev mode)" };
      }
      return { success: false, message: error.message };
    }

    console.log(`✅ Verification email sent to ${email} (ID: ${data?.id})`);
    return { success: true, message: "Verification email sent successfully", emailId: data?.id };
  } catch (error) {
    console.error('Failed to send verification email:', error);
    // In development, still return success so user can use the code from console
    if (process.env.NODE_ENV !== 'production') {
      console.log('⚠️ Email failed but code is available in console above');
      return { success: true, message: "Code generated (check console in dev mode)" };
    }
    return { success: false, message: "Failed to send email" };
  }
}

export async function sendPasswordResetEmail(email: string, token: string, firstName: string, language: string = 'it') {
  const emailContent = {
    it: {
      subject: "Codice reset password - Solvia",
      greeting: `Ciao ${firstName},`,
      message: "Abbiamo ricevuto una richiesta per reimpostare la tua password. Ecco il tuo codice a 6 cifre:",
      codeLabel: "Codice reset:",
      instruction: "Inserisci questo codice nella pagina di reset per impostare una nuova password.",
      expires: "Questo codice è valido per 1 ora.",
      ignore: "Se non hai richiesto questa reimpostazione, ignora questa email."
    },
    en: {
      subject: "Password reset code - Solvia",
      greeting: `Hello ${firstName},`,
      message: "We received a request to reset your password. Here is your 6-digit code:",
      codeLabel: "Reset Code:",
      instruction: "Enter this code on the reset page to set a new password.",
      expires: "This code is valid for 1 hour.",
      ignore: "If you didn't request this reset, please ignore this email."
    },
    tr: {
      subject: "Şifre sıfırlama kodu - Solvia",
      greeting: `Merhaba ${firstName},`,
      message: "Şifrenizi sıfırlama talebi aldık. İşte 6 haneli kodunuz:",
      codeLabel: "Sıfırlama Kodu:",
      instruction: "Yeni şifre belirlemek için bu kodu sıfırlama sayfasına girin.",
      expires: "Bu kod 1 saat geçerlidir.",
      ignore: "Bu sıfırlama talebini siz yapmadıysanız, bu e-postayı görmezden gelin."
    },
    ar: {
      subject: "رمز إعادة تعيين كلمة المرور - Solvia",
      greeting: `مرحبا ${firstName}،`,
      message: "تلقينا طلبًا لإعادة تعيين كلمة المرور الخاصة بك. إليك الرمز المكون من 6 أرقام:",
      codeLabel: "رمز إعادة التعيين:",
      instruction: "أدخل هذا الرمز في صفحة إعادة التعيين لتحديد كلمة مرور جديدة.",
      expires: "هذا الرمز صالح لمدة ساعة واحدة.",
      ignore: "إذا لم تطلب هذه الإعادة، يرجى تجاهل هذا البريد الإلكتروني."
    }
  };

  const lang = emailContent[language as keyof typeof emailContent] || emailContent.it;

  // Log reset code in development mode
  if (process.env.NODE_ENV !== 'production') {
    console.log('🔑 PASSWORD RESET CODE for', email, ':', token);
    console.log('⏰ Expires:', new Date(Date.now() + 60 * 60 * 1000).toLocaleString());
  }

  try {
    const resend = getResendClient();
    // Send email via Resend
    const { data, error } = await resend.emails.send({
      from: 'Solvia <onboarding@resend.dev>',
      to: [email],
      subject: lang.subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #0ea5e9;">${lang.greeting}</h2>
          <p style="font-size: 16px; line-height: 1.6;">${lang.message}</p>
          <div style="text-align: center; margin: 30px 0; background-color: #f0f9ff; padding: 30px; border-radius: 10px;">
            <p style="font-size: 14px; color: #0369a1; margin: 0 0 10px 0; font-weight: 600;">${lang.codeLabel}</p>
            <div style="font-size: 36px; font-weight: bold; color: #0ea5e9; letter-spacing: 8px; font-family: 'Courier New', monospace;">
              ${token}
            </div>
          </div>
          <p style="font-size: 15px; line-height: 1.6; color: #374151;">${lang.instruction}</p>
          <p style="font-size: 14px; color: #666; margin-top: 30px;">${lang.expires}</p>
          <p style="font-size: 14px; color: #666;">${lang.ignore}</p>
        </div>
      `,
    });

    if (error) {
      console.error('Resend email error:', error);
      // In development, still return success so user can use the code from console
      if (process.env.NODE_ENV !== 'production') {
        console.log('⚠️ Email failed but code is available in console above');
        return { success: true, message: "Code generated (check console in dev mode)" };
      }
      return { success: false, message: error.message };
    }

    console.log(`✅ Password reset email sent to ${email} (ID: ${data?.id})`);
    return { success: true, message: "Password reset email sent successfully", emailId: data?.id };
  } catch (error) {
    console.error('Failed to send password reset email:', error);
    // In development, still return success so user can use the code from console
    if (process.env.NODE_ENV !== 'production') {
      console.log('⚠️ Email failed but code is available in console above');
      return { success: true, message: "Code generated (check console in dev mode)" };
    }
    return { success: false, message: "Failed to send email" };
  }
}
