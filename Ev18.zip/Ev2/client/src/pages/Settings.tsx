import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useTranslation, type Language } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';

const languageOptions: { code: Language; name: string; nativeName: string; flag: string }[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦' },
];

export default function Settings() {
  const { language, setLanguage } = useLanguage();
  const { user, refreshUser } = useAuth();
  const t = useTranslation(language);
  const { toast } = useToast();
  
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    city: user?.city || '',
  });

  const handleSave = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/users/update', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      await refreshUser();
      setIsEditing(false);
      toast({
        title: t('profileSavedSuccessfully') || 'Profil kaydedildi',
        description: t('profileUpdated') || 'Bilgileriniz başarıyla güncellendi',
      });
    } catch (error) {
      toast({
        title: t('error') || 'Hata',
        description: t('updateFailed') || 'Güncelleme başarısız oldu',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('settings')}</h1>
        <p className="text-muted-foreground">{t('customizeExperience')}</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Account Information Card */}
        {user && (
          <Card>
            <Collapsible open={isAccountOpen} onOpenChange={setIsAccountOpen}>
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{t('myAccountInfo') || 'Hesap Bilgilerim'}</CardTitle>
                      <CardDescription>{t('editAccountInfo') || 'Hesap bilgilerinizi düzenleyin'}</CardDescription>
                    </div>
                    {isAccountOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">{t('firstName')}</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">{t('lastName')}</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">{t('email')}</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      disabled
                      className="bg-gray-100 dark:bg-gray-800"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">{t('phone')}</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">{t('city')}</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="flex gap-2 pt-4">
                    {!isEditing ? (
                      <Button onClick={() => setIsEditing(true)} className="w-full">
                        {t('editProfile') || 'Profili Düzenle'}
                      </Button>
                    ) : (
                      <>
                        <Button onClick={handleSave} disabled={loading} className="flex-1">
                          {loading ? t('loading') : t('save')}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsEditing(false);
                            setFormData({
                              firstName: user?.firstName || '',
                              lastName: user?.lastName || '',
                              email: user?.email || '',
                              phone: user?.phone || '',
                              city: user?.city || '',
                            });
                          }}
                          disabled={loading}
                        >
                          {t('cancel') || 'İptal'}
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        )}

        {/* Language Settings Card */}
        <Card>
          <CardHeader>
            <CardTitle>{t('language')}</CardTitle>
            <CardDescription>{t('selectPreferredLanguage')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {languageOptions.map(({ code, name, nativeName, flag }) => (
                <Button
                  key={code}
                  variant={language === code ? 'default' : 'outline'}
                  className="justify-start gap-3 h-auto py-4"
                  onClick={() => setLanguage(code)}
                  data-testid={`button-lang-${code}`}
                >
                  <span className="text-2xl">{flag}</span>
                  <div className="flex-1 text-left">
                    <div className="font-semibold">{nativeName}</div>
                    <div className="text-xs opacity-80">{name}</div>
                  </div>
                  {language === code && <Check className="h-5 w-5" />}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
