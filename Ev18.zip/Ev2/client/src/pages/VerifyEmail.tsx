import { useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, Mail, Loader2 } from 'lucide-react';
import { authAPI } from '@/lib/api';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';

export default function VerifyEmail() {
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();
  
  // Get email from URL parameter
  const params = new URLSearchParams(searchParams);
  const email = params.get('email') || '';
  
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [verified, setVerified] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (code.length !== 6) {
      toast({
        title: t('error') || 'Hata',
        description: t('codeLength') || 'Doğrulama kodu 6 haneli olmalıdır',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      await authAPI.verifyEmail(code);
      setVerified(true);
      toast({
        title: t('success') || 'Başarılı',
        description: t('emailVerified') || 'E-posta adresiniz başarıyla doğrulandı!',
      });
      
      // Redirect to login after 2 seconds
      setTimeout(() => {
        setLocation('/login');
      }, 2000);
    } catch (error: any) {
      toast({
        title: t('verificationError') || 'Doğrulama hatası',
        description: error.message || t('verificationFailed') || 'Kod hatalı veya süresi dolmuş',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (!email) {
      toast({
        title: t('error') || 'Hata',
        description: t('emailRequired') || 'E-posta adresi bulunamadı',
        variant: 'destructive',
      });
      return;
    }

    try {
      await authAPI.resendVerification(email);
      toast({
        title: t('success') || 'Başarılı',
        description: t('codeSent') || 'Yeni doğrulama kodu gönderildi',
      });
    } catch (error: any) {
      toast({
        title: t('error') || 'Hata',
        description: error.message || t('resendFailed') || 'Kod gönderilemedi',
        variant: 'destructive',
      });
    }
  };

  if (verified) {
    return (
      <div className="container max-w-md mx-auto py-12 px-4">
        <Card className="shadow-xl border-2 border-green-200">
          <CardContent className="text-center space-y-4 pt-8">
            <CheckCircle2 className="h-24 w-24 mx-auto text-green-500" />
            <h2 className="text-2xl font-bold text-green-700">
              {t('accountActivated') || 'Hesap Aktifleştirildi!'}
            </h2>
            <p className="text-gray-600">
              {t('redirectingToLogin') || 'Giriş sayfasına yönlendiriliyorsunuz...'}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-md mx-auto py-12 px-4">
      <Card className="shadow-xl border-2 border-cyan-200">
        <CardHeader className="text-center">
          <Mail className="h-16 w-16 mx-auto text-cyan-500 mb-4" />
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-500 bg-clip-text text-transparent">
            {t('verifyEmail') || 'E-posta Doğrulama'}
          </CardTitle>
          <CardDescription className="text-base mt-2">
            {email 
              ? `${t('codeSentTo') || 'Doğrulama kodu gönderildi:'} ${email}`
              : t('enterVerificationCode') || 'E-postanıza gönderilen 6 haneli kodu girin'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="code" className="text-lg">
                {t('verificationCode') || 'Doğrulama Kodu'}
              </Label>
              <Input
                id="code"
                type="text"
                inputMode="numeric"
                placeholder="000000"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                maxLength={6}
                required
                className="text-center text-2xl font-mono tracking-widest border-cyan-300 focus:border-cyan-500"
              />
              <p className="text-sm text-gray-500 text-center">
                {t('codeExpiresIn') || '24 saat içinde geçerli'}
              </p>
            </div>

            <Button
              type="submit"
              disabled={loading || code.length !== 6}
              className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-lg py-6"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('verifying') || 'Doğrulanıyor...'}
                </>
              ) : (
                t('verifyAccount') || 'Hesabı Doğrula'
              )}
            </Button>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600">
                {t('didntReceiveCode') || 'Kod gelmedi mi?'}
              </p>
              <Button
                type="button"
                variant="link"
                onClick={handleResend}
                className="text-cyan-600 hover:text-cyan-700"
              >
                {t('resendCode') || 'Yeni Kod Gönder'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
