import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { hashPassword, verifyPassword, generateVerificationToken, sendVerificationEmail, sendPasswordResetEmail } from "./auth";
import { askChatbot } from "./chatbot";
import { analyzeDocument } from "./documentAnalysis";
import { insertUserSchema, insertRoommateListingSchema, insertRoomListingSchema, insertRoomMessageSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

// Extend session data
declare module 'express-session' {
  interface SessionData {
    userId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || 'your-secret-key-change-this-in-production',
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
      },
    })
  );

  // Auth middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    next();
  };

  const requireVerified = async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isVerified) {
      return res.status(403).json({ error: "Email verification required" });
    }
    
    next();
  };

  // ============ AUTH ROUTES ============
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }

      // Hash password
      const hashedPassword = await hashPassword(validatedData.password);
      
      // Generate verification token
      const { token, expiry } = generateVerificationToken();

      // Create user
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
        verificationToken: token,
        verificationTokenExpiry: expiry,
      });

      // Send verification email
      await sendVerificationEmail(user.email, token, user.firstName, req.body.language || 'it');

      res.json({ 
        message: "Registration successful. Please check your email to verify your account.",
        userId: user.id 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Registration error:", error);
      res.status(500).json({ error: "Registration failed" });
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const isValidPassword = await verifyPassword(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Check if email is verified
      if (!user.isVerified) {
        return res.status(403).json({ 
          error: "Email not verified",
          message: "Please verify your email before logging in. Check your inbox for the verification email.",
          requiresVerification: true,
          email: user.email
        });
      }

      // Set session
      req.session.userId = user.id;

      // Don't send password in response
      const { password: _, ...userWithoutPassword } = user;
      
      res.json({ 
        message: "Login successful",
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  // Get current user
  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const { password: _, ...userWithoutPassword } = user;
    res.json({ user: userWithoutPassword });
  });

  // Update user profile
  app.put("/api/users/update", requireAuth, async (req, res) => {
    try {
      const { firstName, lastName, phone, city } = req.body;
      const userId = req.session.userId!;

      const updates: Partial<typeof req.body> = {};
      if (firstName) updates.firstName = firstName;
      if (lastName) updates.lastName = lastName;
      if (phone) updates.phone = phone;
      if (city) updates.city = city;

      const updatedUser = await storage.updateUser(userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }

      const { password: _, ...userWithoutPassword } = updatedUser;
      res.json({ user: userWithoutPassword, message: "Profile updated successfully" });
    } catch (error) {
      console.error("Update profile error:", error);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Verify email
  app.post("/api/auth/verify-email", async (req, res) => {
    try {
      const { token } = req.body;

      if (!token) {
        return res.status(400).json({ error: "Verification token required" });
      }

      const user = await storage.verifyUserEmail(token);
      if (!user) {
        return res.status(400).json({ error: "Invalid or expired verification token" });
      }

      res.json({ message: "Email verified successfully" });
    } catch (error) {
      console.error("Email verification error:", error);
      res.status(500).json({ error: "Verification failed" });
    }
  });

  // Resend verification email
  app.post("/api/auth/resend-verification", async (req, res) => {
    try {
      const { email, language } = req.body;

      if (!email) {
        return res.status(400).json({ error: "Email required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      if (user.isVerified) {
        return res.status(400).json({ error: "Email already verified" });
      }

      // Generate new verification token
      const { token, expiry } = generateVerificationToken();
      await storage.updateUser(user.id, {
        verificationToken: token,
        verificationTokenExpiry: expiry,
      });

      // Send verification email
      await sendVerificationEmail(user.email, token, user.firstName, language || 'it');

      res.json({ message: "Verification email sent" });
    } catch (error) {
      console.error("Resend verification error:", error);
      res.status(500).json({ error: "Failed to resend verification email" });
    }
  });

  // Request password reset
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email, language } = req.body;

      if (!email) {
        return res.status(400).json({ error: "Email required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if user exists
        return res.json({ message: "If the email exists, a reset link has been sent" });
      }

      // Generate reset token (1 hour expiry)
      const { token, expiry } = generateVerificationToken();
      const resetExpiry = new Date();
      resetExpiry.setHours(resetExpiry.getHours() + 1);

      await storage.updateUser(user.id, {
        resetPasswordToken: token,
        resetPasswordExpiry: resetExpiry,
      });

      // Send password reset email
      await sendPasswordResetEmail(user.email, token, user.firstName, language || 'it');

      res.json({ message: "If the email exists, a reset link has been sent" });
    } catch (error) {
      console.error("Forgot password error:", error);
      res.status(500).json({ error: "Failed to process password reset" });
    }
  });

  // Reset password
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;

      if (!token || !newPassword) {
        return res.status(400).json({ error: "Token and new password required" });
      }

      if (newPassword.length < 8) {
        return res.status(400).json({ error: "Password must be at least 8 characters" });
      }

      // Find user by reset token
      const user = await storage.getUserByResetToken(token);
      if (!user) {
        return res.status(400).json({ error: "Invalid or expired reset token" });
      }

      // Hash new password and update user
      const hashedPassword = await hashPassword(newPassword);
      await storage.updateUser(user.id, {
        password: hashedPassword,
        resetPasswordToken: null,
        resetPasswordExpiry: null,
      });

      res.json({ message: "Password reset successfully" });
    } catch (error) {
      console.error("Reset password error:", error);
      res.status(500).json({ error: "Failed to reset password" });
    }
  });

  // ============ ROOMMATE LISTING ROUTES ============

  // Create roommate listing (requires verified email)
  app.post("/api/roommate-listings", requireVerified, async (req, res) => {
    try {
      const validatedData = insertRoommateListingSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });

      const listing = await storage.createRoommateListing(validatedData);
      res.json({ listing });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Create roommate listing error:", error);
      res.status(500).json({ error: "Failed to create listing" });
    }
  });

  // Get roommate listings
  app.get("/api/roommate-listings", async (req, res) => {
    try {
      const filters = {
        city: req.query.city as string,
        nationality: req.query.nationality as string,
        budgetMax: req.query.budgetMax ? parseInt(req.query.budgetMax as string) : undefined,
      };

      const listings = await storage.getRoommateListings(filters);
      res.json({ listings });
    } catch (error) {
      console.error("Get roommate listings error:", error);
      res.status(500).json({ error: "Failed to get listings" });
    }
  });

  // Get user's roommate listings
  app.get("/api/roommate-listings/my-listings", requireAuth, async (req, res) => {
    try {
      const listings = await storage.getRoommateListingsByUser(req.session.userId!);
      res.json({ listings });
    } catch (error) {
      console.error("Get user roommate listings error:", error);
      res.status(500).json({ error: "Failed to get listings" });
    }
  });

  // Delete roommate listing
  app.delete("/api/roommate-listings/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteRoommateListing(req.params.id, req.session.userId!);
      if (!success) {
        return res.status(404).json({ error: "Listing not found or unauthorized" });
      }
      res.json({ message: "Listing deleted successfully" });
    } catch (error) {
      console.error("Delete roommate listing error:", error);
      res.status(500).json({ error: "Failed to delete listing" });
    }
  });

  // ============ ROOM LISTING ROUTES ============

  // Create room listing (requires verified email)
  app.post("/api/room-listings", requireVerified, async (req, res) => {
    try {
      const validatedData = insertRoomListingSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });

      const listing = await storage.createRoomListing(validatedData);
      res.json({ listing });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Create room listing error:", error);
      res.status(500).json({ error: "Failed to create listing" });
    }
  });

  // Get room listings
  app.get("/api/room-listings", async (req, res) => {
    try {
      const filters = {
        city: req.query.city as string,
        roomType: req.query.roomType as string,
        maxRent: req.query.maxRent ? parseInt(req.query.maxRent as string) : undefined,
        preferredNationality: req.query.nationality as string,
      };

      const listings = await storage.getRoomListings(filters);
      res.json({ listings });
    } catch (error) {
      console.error("Get room listings error:", error);
      res.status(500).json({ error: "Failed to get listings" });
    }
  });

  // ============ ROOM MESSAGES ROUTES ============

  // Send room message
  app.post("/api/room-messages", async (req, res) => {
    try {
      const validatedData = insertRoomMessageSchema.parse(req.body);
      
      const message = await storage.createRoomMessage(validatedData);
      res.json({ message, success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Create room message error:", error);
      res.status(500).json({ error: "Failed to send message" });
    }
  });

  // ============ DORMITORY ROUTES ============

  // Get dormitories
  app.get("/api/dormitories", async (req, res) => {
    try {
      const city = req.query.city as string | undefined;
      const dormitories = await storage.getDormitories(city);
      res.json({ dormitories });
    } catch (error) {
      console.error("Get dormitories error:", error);
      res.status(500).json({ error: "Failed to get dormitories" });
    }
  });

  // Create dormitory (admin only - for now open for testing)
  app.post("/api/dormitories", async (req, res) => {
    try {
      const dormitory = await storage.createDormitory(req.body);
      res.json({ dormitory });
    } catch (error) {
      console.error("Create dormitory error:", error);
      res.status(500).json({ error: "Failed to create dormitory" });
    }
  });

  // ============ EXISTING ROUTES ============

  // Chatbot endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, language } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      const chatResponse = await askChatbot(message, language || 'en');
      res.json({ 
        response: chatResponse.text,
        actions: chatResponse.actions 
      });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Document analysis endpoint
  app.post("/api/analyze-document", async (req, res) => {
    try {
      const { imageBase64, language } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ error: "Image data is required" });
      }

      const result = await analyzeDocument(imageBase64, language || 'it');
      res.json(result);
    } catch (error) {
      console.error("Document analysis error:", error);
      res.status(500).json({ error: "Failed to analyze document" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
