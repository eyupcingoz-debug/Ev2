import { Link, useLocation } from 'wouter';
import { Moon, Sun, FileText, Home as HomeIcon, MessageSquare, Settings as SettingsIcon, Briefcase, CalendarCheck, LogOut, User, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useTranslation, type Language } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Alert, AlertDescription } from '@/components/ui/alert';

const languageFlags: Record<Language, string> = {
  en: '🇬🇧',
  it: '🇮🇹',
  tr: '🇹🇷',
  ar: '🇸🇦',
};

const languageNames: Record<Language, string> = {
  en: 'English',
  it: 'Italiano',
  tr: 'Türkçe',
  ar: 'العربية',
};

export default function Navbar() {
  const [location, setLocation] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage } = useLanguage();
  const { user, logout, loading } = useAuth();
  const t = useTranslation(language);
  const { toast } = useToast();

  const handleOnlineCAF = () => {
    toast({
      title: t('onlineCaf'),
      description: t('onlineCafComingSoon'),
    });
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: t('logoutSuccess') || 'Çıkış yapıldı',
        description: t('logoutMessage') || 'Başarıyla çıkış yaptınız',
      });
      setLocation('/');
    } catch (error) {
      toast({
        title: t('error') || 'Hata',
        description: t('logoutError') || 'Çıkış yapılırken bir hata oluştu',
        variant: 'destructive',
      });
    }
  };

  const navItems = [
    { path: '/', label: t('home'), icon: null, type: 'link', ariaLabel: 'Home page' },
    { path: '/bureaucracy', label: t('bureaucracy'), icon: FileText, type: 'link', ariaLabel: 'Bureaucracy documents' },
    { path: '/roommates', label: t('roommates'), icon: HomeIcon, type: 'link', ariaLabel: 'Find roommates' },
    { path: '/dorms', label: t('dorms'), icon: Building2, type: 'link', ariaLabel: 'University dormitories' },
    { path: '/community', label: t('communityBoard'), icon: MessageSquare, type: 'link', ariaLabel: 'Community help board' },
    { path: '/chat', label: t('chat'), icon: MessageSquare, type: 'link', ariaLabel: 'Chat with AI assistant' },
    { path: '', label: t('onlineCaf'), icon: Briefcase, type: 'button', onClick: handleOnlineCAF, ariaLabel: 'CAF online appointments' },
    { path: '/calendar', label: t('reminders'), icon: CalendarCheck, type: 'link', ariaLabel: 'Calendar and reminders' },
    { path: '/settings', label: t('settings'), icon: SettingsIcon, type: 'link', ariaLabel: 'Application settings' },
  ];

  return (
    <>
      {user && !user.isVerified && (
        <Alert className="rounded-none border-l-0 border-r-0 border-t-0 border-b-4 border-yellow-500 bg-yellow-50">
          <AlertDescription className="text-center">
            {t('verifyEmailWarning') || 'E-posta adresinizi doğrulayın! İlan vermek ve fotoğraf yüklemek için e-postanızı doğrulamanız gerekiyor.'}
          </AlertDescription>
        </Alert>
      )}
      
      <nav className="sticky top-0 z-50 w-full border-b-2 border-cyan-200 dark:border-cyan-800 bg-gradient-to-r from-cyan-50 via-white to-cyan-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 backdrop-blur-lg supports-[backdrop-filter]:bg-white/90 dark:supports-[backdrop-filter]:bg-gray-900/90 shadow-lg">
        <div className="container mx-auto px-2 sm:px-4 h-20 flex items-center justify-between gap-2">
          <Link href="/" className="flex items-center gap-2 sm:gap-3 px-2 sm:px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 active:scale-95 hover:bg-cyan-50 dark:hover:bg-gray-800" data-testid="link-home">
            <div className="relative p-2 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-500 shadow-lg">
              <FileText className="h-6 w-6 sm:h-7 sm:w-7 text-white" />
            </div>
            <span className="text-xl sm:text-2xl font-extrabold bg-gradient-to-r from-cyan-600 via-teal-500 to-cyan-500 dark:from-cyan-400 dark:via-teal-400 dark:to-cyan-400 bg-clip-text text-transparent drop-shadow-sm">{t('appName')}</span>
          </Link>

          <div className="hidden md:flex items-center gap-2">
            {navItems.map(({ path, label, icon: Icon, type, onClick, ariaLabel }) => (
              type === 'button' ? (
                <Button
                  key={label}
                  variant="outline"
                  size="default"
                  className="gap-2 border-2 border-cyan-300 hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 transition-all duration-300 hover:scale-110 active:scale-95 hover:shadow-lg px-4"
                  onClick={onClick}
                  aria-label={ariaLabel}
                  data-testid="button-online-caf"
                >
                  {Icon && <Icon className="h-5 w-5" aria-hidden="true" />}
                  <span className="font-medium">{label}</span>
                </Button>
              ) : (
                <Link key={path} href={path} data-testid={`link-${path.slice(1) || 'home'}`}>
                  <Button
                    variant={location === path ? 'default' : 'outline'}
                    size="default"
                    aria-label={ariaLabel}
                    className={`gap-2 border-2 transition-all duration-300 hover:scale-110 active:scale-95 shadow-sm px-4 ${
                      location === path 
                        ? 'bg-gradient-to-r from-cyan-500 to-teal-500 border-cyan-400 shadow-lg shadow-cyan-500/30' 
                        : 'border-cyan-300 hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 hover:shadow-lg'
                    }`}
                  >
                    {Icon && <Icon className="h-5 w-5" aria-hidden="true" />}
                    <span className="font-medium">{label}</span>
                  </Button>
                </Link>
              )
            ))}
          </div>

          <div className="flex items-center gap-1 sm:gap-2">
            {/* Auth Buttons */}
            {!loading && (
              <>
                {!user ? (
                  <>
                    <Link href="/login">
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1 sm:gap-2 border-2 border-cyan-500 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-gray-800 dark:border-cyan-600 px-2 sm:px-4"
                        data-testid="button-login"
                      >
                        <span className="text-xs sm:text-sm">{t('login') || 'Giriş Yap'}</span>
                      </Button>
                    </Link>
                    <Link href="/register">
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 shadow-lg px-2 sm:px-4"
                        data-testid="button-register"
                      >
                        <span className="text-xs sm:text-sm">{t('register') || 'Kayıt Ol'}</span>
                      </Button>
                    </Link>
                  </>
                ) : (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" className="gap-1 sm:gap-2 border-2 border-cyan-500 dark:border-cyan-600 dark:text-cyan-400 px-2 sm:px-3" data-testid="button-user-menu">
                        <User className="h-4 w-4 sm:h-5 sm:w-5" />
                        <span className="hidden sm:inline text-sm">{user.firstName}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="dark:bg-gray-800 dark:border-gray-700">
                      <DropdownMenuItem disabled className="font-medium dark:text-gray-200">
                        {user.email}
                      </DropdownMenuItem>
                      {!user.isVerified && (
                        <DropdownMenuItem disabled className="text-yellow-600 dark:text-yellow-400 text-xs">
                          {t('emailNotVerified') || 'E-posta doğrulanmadı'}
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator className="dark:bg-gray-700" />
                      <DropdownMenuItem onClick={handleLogout} className="gap-2 text-red-600 dark:text-red-400">
                        <LogOut className="h-4 w-4" />
                        {t('logout') || 'Çıkış Yap'}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 sm:h-10 sm:w-auto sm:px-3 dark:hover:bg-gray-800" data-testid="button-language">
                  <span className="text-lg sm:text-base">{languageFlags[language]}</span>
                  <span className="hidden lg:inline ml-2 text-sm dark:text-gray-200">{languageNames[language]}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="dark:bg-gray-800 dark:border-gray-700">
                {(Object.keys(languageFlags) as Language[]).map((lang) => (
                  <DropdownMenuItem
                    key={lang}
                    onClick={() => setLanguage(lang)}
                    className="gap-2 dark:text-gray-200 dark:hover:bg-gray-700"
                    data-testid={`button-language-${lang}`}
                  >
                    <span>{languageFlags[lang]}</span>
                    <span>{languageNames[lang]}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="h-8 w-8 sm:h-10 sm:w-10 dark:hover:bg-gray-800 dark:text-gray-200"
              data-testid="button-theme-toggle"
            >
              {theme === 'light' ? (
                <Moon className="h-4 w-4 sm:h-5 sm:w-5" />
              ) : (
                <Sun className="h-4 w-4 sm:h-5 sm:w-5" />
              )}
            </Button>
          </div>
        </div>

        <div className="md:hidden border-t-2 border-cyan-200 dark:border-cyan-800 bg-gradient-to-r from-cyan-50 via-white to-cyan-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md">
          <div className="container mx-auto px-4 py-3 flex gap-2 overflow-x-auto">
            {navItems.map(({ path, label, icon: Icon, type, onClick, ariaLabel }) => (
              type === 'button' ? (
                <Button
                  key={label}
                  variant="outline"
                  size="default"
                  className="gap-2 whitespace-nowrap border-2 border-cyan-300 dark:border-cyan-700 dark:text-cyan-400 hover:border-cyan-500 dark:hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 dark:hover:from-gray-800 dark:hover:to-gray-700 transition-all duration-300 hover:shadow-lg px-4"
                  onClick={onClick}
                  aria-label={ariaLabel}
                  data-testid="button-mobile-online-caf"
                >
                  {Icon && <Icon className="h-5 w-5" aria-hidden="true" />}
                  <span className="font-medium">{label}</span>
                </Button>
              ) : (
                <Link key={path} href={path} data-testid={`link-mobile-${path.slice(1) || 'home'}`}>
                  <Button
                    variant={location === path ? 'default' : 'outline'}
                    size="default"
                    aria-label={ariaLabel}
                    className={`gap-2 whitespace-nowrap border-2 transition-all duration-300 shadow-sm px-4 ${
                      location === path 
                        ? 'bg-gradient-to-r from-cyan-500 to-teal-500 border-cyan-400 shadow-lg shadow-cyan-500/30' 
                        : 'border-cyan-300 dark:border-cyan-700 dark:text-cyan-400 hover:border-cyan-500 dark:hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 dark:hover:from-gray-800 dark:hover:to-gray-700 hover:shadow-lg'
                    }`}
                  >
                    {Icon && <Icon className="h-5 w-5" aria-hidden="true" />}
                    <span className="font-medium">{label}</span>
                  </Button>
                </Link>
              )
            ))}
          </div>
        </div>
      </nav>
    </>
  );
}
