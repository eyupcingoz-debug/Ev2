import { Dorm } from './types';

export const parmaDorms: Dorm[] = [
  {
    city: "Parma",
    name: {
      en: "ER.GO Volturno",
      it: "ER.GO Volturno",
      tr: "ER.GO Volturno",
      ar: "ER.GO فولتورنو"
    },
    university: "Università di Parma",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 240,
    priceMax: 430,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Volturno+Parma",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"],
    recommended: true
  },
  {
    city: "Parma",
    name: {
      en: "ER.GO Montebello",
      it: "ER.GO Montebello",
      tr: "ER.GO Montebello",
      ar: "ER.GO مونتيبيلو"
    },
    university: "Università di Parma",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 440,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Montebello+Parma",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"],
    recommended: true
  },
  {
    city: "Parma",
    name: {
      en: "ER.GO Cavestro",
      it: "ER.GO Cavestro",
      tr: "ER.GO Cavestro",
      ar: "ER.GO كافيسترو"
    },
    university: "Università di Parma",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 230,
    priceMax: 420,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Cavestro+Parma",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Garden"]
  },
  {
    city: "Parma",
    name: {
      en: "ER.GO Cocconi",
      it: "ER.GO Cocconi",
      tr: "ER.GO Cocconi",
      ar: "ER.GO كوكوني"
    },
    university: "Università di Parma",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 260,
    priceMax: 450,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Cocconi+Parma",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Parma",
    name: {
      en: "ER.GO Parma General List",
      it: "ER.GO Parma Lista Generale",
      tr: "ER.GO Parma Genel Liste",
      ar: "ER.GO بارما القائمة العامة"
    },
    university: "Università di Parma",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 220,
    priceMax: 460,
    applicationLink: "https://www.er-go.it/",
    mapLink: "https://maps.google.com/?q=ER.GO+Parma",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Sports facilities"]
  },
  {
    city: "Parma",
    name: {
      en: "Private Guest Houses",
      it: "Pansiyonlar Özel",
      tr: "Özel Pansiyonlar",
      ar: "بيوت الضيافة الخاصة"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 280,
    priceMax: 480,
    applicationLink: "https://www.unipr.it/",
    mapLink: "https://maps.google.com/?q=Student+Housing+Parma",
    features: ["Wi-Fi", "Common kitchen", "Laundry", "Garden"]
  }
];
