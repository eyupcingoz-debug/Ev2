import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2, Users, Bed, Euro, ExternalLink, Filter, X, MapPin, Globe } from 'lucide-react';
import { allDorms, cities, type Dorm, cityNames } from '@/data/dorms';
import { useTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';
import { useLocation } from 'wouter';

export default function Dorms() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const [, setLocation] = useLocation();
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedGender, setSelectedGender] = useState('All');
  const [selectedRoomCapacity, setSelectedRoomCapacity] = useState('All');
  const [priceRange, setPriceRange] = useState<number[]>([0, 1200]);

  const filteredDorms = useMemo(() => {
    return allDorms.filter((dorm: Dorm) => {
      const cityMatch = selectedCity === 'All' || dorm.city === selectedCity;
      const genderMatch = selectedGender === 'All' || dorm.gender === selectedGender;
      const roomMatch = selectedRoomCapacity === 'All' || dorm.roomTypes.includes(selectedRoomCapacity as 'Single' | 'Double' | 'Triple');
      const priceMatch = dorm.priceMin <= priceRange[1] && dorm.priceMax >= priceRange[0];

      return cityMatch && genderMatch && roomMatch && priceMatch;
    });
  }, [selectedCity, selectedGender, selectedRoomCapacity, priceRange]);

  const dormStats = useMemo(() => {
    return cities.slice(1).map((city: string) => ({
      city,
      count: allDorms.filter((d: Dorm) => d.city === city).length
    }));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-cyan-50 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
              <Building2 className="h-10 w-10 text-cyan-600" />
              {t('universityDormitories')}
            </h1>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/')}
              className="h-10 w-10"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            {t('findOfficialHousing')}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {dormStats.map(({ city, count }) => {
              const cityName = cityNames[city] ? cityNames[city][language as keyof typeof cityNames[typeof city]] : city;
              return (
                <span
                  key={city}
                  className="px-3 py-1 bg-white dark:bg-gray-800 rounded-full text-sm text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700"
                >
                  {cityName}: {count}
                </span>
              );
            })}
          </div>
        </div>

        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Filter className="h-5 w-5" />
              {t('filters')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <Label htmlFor="city-filter" className="mb-2 block">
                  {t('city')}
                </Label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger id="city-filter">
                    <SelectValue placeholder={t('selectCity')} />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map((city: string) => {
                      const localizedCityName = city === 'All' 
                        ? t('all') 
                        : (cityNames[city] ? cityNames[city][language as keyof typeof cityNames[typeof city]] : city);
                      return (
                        <SelectItem key={city} value={city}>
                          {localizedCityName}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="gender-filter" className="mb-2 block">
                  {t('gender')}
                </Label>
                <Select value={selectedGender} onValueChange={setSelectedGender}>
                  <SelectTrigger id="gender-filter">
                    <SelectValue placeholder={t('gender')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">{t('all')}</SelectItem>
                    <SelectItem value="Mixed">{t('mixed')}</SelectItem>
                    <SelectItem value="Male">{t('male')}</SelectItem>
                    <SelectItem value="Female">{t('female')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="room-filter" className="mb-2 block">
                  {t('roomType')}
                </Label>
                <Select value={selectedRoomCapacity} onValueChange={setSelectedRoomCapacity}>
                  <SelectTrigger id="room-filter">
                    <SelectValue placeholder={t('roomType')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">{t('all')}</SelectItem>
                    <SelectItem value="Single">{t('single')}</SelectItem>
                    <SelectItem value="Double">{t('double')}</SelectItem>
                    <SelectItem value="Triple">{t('triple')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="price-filter" className="mb-2 block">
                  {t('priceRange')}: €{priceRange[0]} - €{priceRange[1]}
                </Label>
                <Slider
                  id="price-filter"
                  min={0}
                  max={1200}
                  step={50}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mb-4 text-gray-600 dark:text-gray-400">
          {t('showing')} <strong>{filteredDorms.length}</strong> {t('of')} <strong>{allDorms.length}</strong> {t('dormitories')}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDorms.map((dorm: Dorm) => {
            const dormName = typeof dorm.name === 'string' 
              ? dorm.name 
              : dorm.name[language as keyof typeof dorm.name] || dorm.name.en;
            const cityName = cityNames[dorm.city] ? cityNames[dorm.city][language as keyof typeof cityNames[typeof dorm.city]] : dorm.city;
            const dormDescription = dorm.description ? dorm.description[language as keyof typeof dorm.description] || dorm.description.en : null;
            
            return (
            <Card key={`${dorm.city}-${dormName}`} className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">{dormName}</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">{cityName}</p>
              </CardHeader>
              <CardContent>
                {dormDescription && (
                  <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-700 dark:text-gray-300">{dormDescription}</p>
                  </div>
                )}

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">{dorm.university}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">
                      {dorm.gender === 'Mixed' ? t('mixed') : dorm.gender === 'Male' ? t('male') : t('female')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bed className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">
                      {dorm.roomTypes.map(type => type === 'Single' ? t('single') : type === 'Double' ? t('double') : t('triple')).join(', ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Euro className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">
                      €{dorm.priceMin} - €{dorm.priceMax}/{t('month')}
                    </span>
                  </div>
                </div>

                {dorm.features && dorm.features.length > 0 && (
                  <div className="mt-4">
                    <div className="flex flex-wrap gap-1">
                      {dorm.features.slice(0, 4).map((feature: string, idx: number) => (
                        <span
                          key={idx}
                          className="px-2 py-1 bg-cyan-50 dark:bg-cyan-900/30 text-cyan-700 dark:text-cyan-300 rounded text-xs"
                        >
                          {feature}
                        </span>
                      ))}
                      {dorm.features.length > 4 && (
                        <span className="px-2 py-1 text-gray-500 text-xs">
                          +{dorm.features.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 mt-4">
                  {dorm.mapLink && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-cyan-600 text-cyan-600 hover:bg-cyan-50 dark:hover:bg-cyan-900/20"
                      onClick={() => window.open(dorm.mapLink, '_blank')}
                    >
                      <MapPin className="h-4 w-4 mr-1" />
                      {t('viewMap')}
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-cyan-600 text-cyan-600 hover:bg-cyan-50 dark:hover:bg-cyan-900/20"
                    onClick={() => window.open(dorm.applicationLink, '_blank')}
                  >
                    <Globe className="h-4 w-4 mr-1" />
                    {t('viewWebsite')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
          })}
        </div>

        {filteredDorms.length === 0 && (
          <Card className="p-12 text-center">
            <p className="text-gray-600 dark:text-gray-400 text-lg">
              {t('noDormitoriesMatch')}
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
