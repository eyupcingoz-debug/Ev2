import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Upload, X, ChevronDown } from 'lucide-react';
import RoommateCard, { type RoommateProfile } from '@/components/RoommateCard';
import RoomListingCard, { type RoomListing } from '@/components/RoomListingCard';
import MapModal from '@/components/MapModal';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function Roommates() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();

  const [profile, setProfile] = useState<Partial<RoommateProfile>>({
    city: '',
    university: '',
    budgetMin: 300,
    budgetMax: 600,
    pets: false,
    smoker: false,
    cleanliness: 3,
    noiseTolerance: 3,
  });

  const [roommateFilters, setRoommateFilters] = useState({
    city: '',
    district: '',
    minBudget: '',
    maxBudget: '',
    roomType: 'all' as 'all' | 'private' | 'shared',
    genderPreference: 'all' as 'all' | 'female' | 'male' | 'none',
    furnished: 'all' as 'all' | 'yes' | 'no',
    smoking: 'all' as 'all' | 'allowed' | 'notAllowed',
    pets: 'all' as 'all' | 'allowed' | 'notAllowed',
    billsIncluded: 'all' as 'all' | 'yes' | 'no',
    moveInDate: '',
  });

  const [matches, setMatches] = useState<RoommateProfile[]>([]);
  const [hasSearchedRoommate, setHasSearchedRoommate] = useState(false);

  // Collapsible states
  const [isFiltersOpen, setIsFiltersOpen] = useState(true);
  const [isProfileFormOpen, setIsProfileFormOpen] = useState(true);
  const [isRoomFiltersOpen, setIsRoomFiltersOpen] = useState(true);

  // User profile for "Find Roommate" tab
  const [userProfile, setUserProfile] = useState<{
    city: string;
    district: string;
    university: string;
    age: string;
    smoking: boolean;
    pets: boolean;
    description: string;
  } | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const saved = localStorage.getItem('userRoommateProfile');
      return saved ? JSON.parse(saved) : null;
    } catch (error) {
      console.error('Failed to load user profile:', error);
      return null;
    }
  });

  const [profileFormData, setProfileFormData] = useState({
    city: userProfile?.city || '',
    district: userProfile?.district || '',
    university: userProfile?.university || '',
    age: userProfile?.age || '',
    smoking: userProfile?.smoking || false,
    pets: userProfile?.pets || false,
    description: userProfile?.description || '',
  });

  const [listings, setListings] = useState<RoomListing[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem('roomListings');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Failed to load room listings:', error);
      return [];
    }
  });
  
  const [newListing, setNewListing] = useState<Partial<RoomListing>>({
    title: '',
    description: '',
    city: '',
    district: '',
    rentPrice: 0,
    roomType: 'private',
    locationUrl: '',
    ownerName: '',
    photos: [],
    smoking: 'notAllowed',
    pets: 'notAllowed',
    furnished: 'yes',
    genderPreference: 'none',
    deposit: 0,
    billsIncluded: false,
  });

  const [editingListingId, setEditingListingId] = useState<string | null>(null);
  const [selectedListing, setSelectedListing] = useState<RoomListing | null>(null);
  const [showMapModal, setShowMapModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const [roomSearchFilters, setRoomSearchFilters] = useState({
    city: '',
    district: '',
    minRent: '',
    maxRent: '',
    roomType: 'all' as 'all' | 'private' | 'shared',
    genderPreference: 'all' as 'all' | 'female' | 'male' | 'none',
    furnished: 'all' as 'all' | 'yes' | 'no',
    smoking: 'all' as 'all' | 'allowed' | 'notAllowed',
    pets: 'all' as 'all' | 'allowed' | 'notAllowed',
    billsIncluded: 'all' as 'all' | 'yes' | 'no',
    moveInDate: '',
  });
  
  const [hasSearchedRooms, setHasSearchedRooms] = useState(false);

  const handleFindRoommates = () => {
    setHasSearchedRoommate(true);
  };

  const handleSaveProfile = () => {
    if (!profileFormData.city || !profileFormData.university || !profileFormData.age) {
      toast({
        title: t('profileIncomplete'),
        description: t('fillAllRequiredFields'),
        variant: 'destructive',
      });
      return;
    }

    const newProfile = {
      ...profileFormData,
    };

    setUserProfile(newProfile);
    
    try {
      localStorage.setItem('userRoommateProfile', JSON.stringify(newProfile));
      toast({
        title: t('profileSaved'),
        description: t('profileSaved'),
      });
    } catch (error) {
      console.error('Failed to save profile:', error);
      toast({
        title: t('error'),
        description: 'Failed to save profile. Storage may be full or unavailable.',
        variant: 'destructive',
      });
    }
  };

  const handleEditProfile = () => {
    setIsProfileFormOpen(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteProfile = () => {
    setUserProfile(null);
    setProfileFormData({
      city: '',
      district: '',
      university: '',
      age: '',
      smoking: false,
      pets: false,
      description: '',
    });
    
    try {
      localStorage.removeItem('userRoommateProfile');
      toast({
        title: t('profileDeleted'),
        description: t('profileDeleted'),
      });
    } catch (error) {
      console.error('Failed to delete profile from storage:', error);
      toast({
        title: t('profileDeleted'),
        description: t('profileDeleted'),
      });
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const currentPhotos = newListing.photos || [];
    const remainingSlots = 8 - currentPhotos.length;
    
    if (remainingSlots <= 0) {
      toast({
        title: t('uploadPhotos'),
        description: t('maxPhotosAllowed'),
        variant: 'destructive',
      });
      return;
    }

    const fileArray = Array.from(files).slice(0, remainingSlots);
    const photoPromises = fileArray.map(file => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
    });

    Promise.all(photoPromises).then(photos => {
      setNewListing({ ...newListing, photos: [...currentPhotos, ...photos] });
    });
  };

  const handleSaveListing = () => {
    if (!newListing.title || !newListing.city || !newListing.rentPrice || !newListing.ownerName) {
      toast({
        title: t('listingIncomplete'),
        description: t('fillAllRequiredFields'),
        variant: 'destructive',
      });
      return;
    }

    if (!newListing.photos || newListing.photos.length === 0) {
      toast({
        title: t('uploadPhotos'),
        description: t('atLeastOnePhoto'),
        variant: 'destructive',
      });
      return;
    }

    if (editingListingId) {
      const updatedListings = listings.map(listing => 
        listing.id === editingListingId
          ? {
              ...listing,
              title: newListing.title!,
              description: newListing.description || '',
              city: newListing.city!,
              district: newListing.district || undefined,
              rentPrice: newListing.rentPrice!,
              roomType: newListing.roomType || 'private',
              locationUrl: newListing.locationUrl,
              ownerName: newListing.ownerName!,
              photos: newListing.photos || [],
              smoking: newListing.smoking || 'notAllowed',
              pets: newListing.pets || 'notAllowed',
              furnished: newListing.furnished || 'yes',
              genderPreference: newListing.genderPreference || 'none',
              deposit: newListing.deposit || 0,
              billsIncluded: newListing.billsIncluded || false,
            }
          : listing
      );
      setListings(updatedListings);
      setEditingListingId(null);
      
      try {
        localStorage.setItem('roomListings', JSON.stringify(updatedListings));
        toast({
          title: t('updateListing'),
          description: t('listingUpdated'),
        });
      } catch (error) {
        console.error('Failed to save listings after update:', error);
        toast({
          title: t('error'),
          description: 'Failed to save listing. Storage may be full or unavailable.',
          variant: 'destructive',
        });
      }
    } else {
      const listing: RoomListing = {
        id: Date.now().toString(),
        title: newListing.title!,
        description: newListing.description || '',
        city: newListing.city!,
        district: newListing.district || undefined,
        rentPrice: newListing.rentPrice!,
        roomType: newListing.roomType || 'private',
        locationUrl: newListing.locationUrl,
        ownerName: newListing.ownerName!,
        photos: newListing.photos || [],
        smoking: newListing.smoking || 'notAllowed',
        pets: newListing.pets || 'notAllowed',
        furnished: newListing.furnished || 'yes',
        genderPreference: newListing.genderPreference || 'none',
        deposit: newListing.deposit || 0,
        billsIncluded: newListing.billsIncluded || false,
      };

      const updatedListings = [...listings, listing];
      setListings(updatedListings);

      try {
        localStorage.setItem('roomListings', JSON.stringify(updatedListings));
        toast({
          title: t('saveListing'),
          description: t('listingSaved'),
        });
      } catch (error) {
        console.error('Failed to save new listing:', error);
        toast({
          title: t('error'),
          description: 'Failed to save listing. Storage may be full or unavailable.',
          variant: 'destructive',
        });
      }
    }

    setNewListing({
      title: '',
      description: '',
      city: '',
      district: '',
      rentPrice: 0,
      roomType: 'private',
      locationUrl: '',
      ownerName: '',
      photos: [],
      smoking: 'notAllowed',
      pets: 'notAllowed',
      furnished: 'yes',
      genderPreference: 'none',
      deposit: 0,
      billsIncluded: false,
    });
  };

  const handleEditListing = (listing: RoomListing) => {
    setNewListing({
      title: listing.title,
      description: listing.description,
      city: listing.city,
      district: listing.district,
      rentPrice: listing.rentPrice,
      roomType: listing.roomType,
      locationUrl: listing.locationUrl,
      ownerName: listing.ownerName,
      photos: listing.photos,
      smoking: listing.smoking,
      pets: listing.pets,
      furnished: listing.furnished,
      genderPreference: listing.genderPreference,
      deposit: listing.deposit,
      billsIncluded: listing.billsIncluded,
    });
    setEditingListingId(listing.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteListing = (listingId: string) => {
    const updatedListings = listings.filter(l => l.id !== listingId);
    setListings(updatedListings);
    
    try {
      localStorage.setItem('roomListings', JSON.stringify(updatedListings));
      toast({
        title: t('deleteListing'),
        description: t('listingDeleted'),
      });
    } catch (error) {
      console.error('Failed to save listings after delete:', error);
      toast({
        title: t('deleteListing'),
        description: t('listingDeleted'),
      });
    }
  };

  const handleViewDetails = (listing: RoomListing) => {
    setSelectedListing(listing);
    setShowDetailsModal(true);
  };

  const handleShowLocation = () => {
    if (selectedListing?.locationUrl) {
      setShowDetailsModal(false);
      setShowMapModal(true);
    }
  };

  const handleSearchRooms = () => {
    setHasSearchedRooms(true);
  };

  const filteredRoomListings = !hasSearchedRooms ? [] : listings.filter(listing => {
    if (roomSearchFilters.city && !listing.city.toLowerCase().includes(roomSearchFilters.city.toLowerCase())) {
      return false;
    }
    
    if (roomSearchFilters.district) {
      if (!listing.district || !listing.district.toLowerCase().includes(roomSearchFilters.district.toLowerCase())) {
        return false;
      }
    }
    
    if (roomSearchFilters.minRent && listing.rentPrice < parseInt(roomSearchFilters.minRent)) {
      return false;
    }
    
    if (roomSearchFilters.maxRent && listing.rentPrice > parseInt(roomSearchFilters.maxRent)) {
      return false;
    }

    if (roomSearchFilters.roomType !== 'all' && listing.roomType !== roomSearchFilters.roomType) {
      return false;
    }

    if (roomSearchFilters.genderPreference !== 'all' && listing.genderPreference !== roomSearchFilters.genderPreference) {
      return false;
    }

    if (roomSearchFilters.furnished !== 'all' && listing.furnished !== roomSearchFilters.furnished) {
      return false;
    }

    if (roomSearchFilters.smoking !== 'all' && listing.smoking !== roomSearchFilters.smoking) {
      return false;
    }

    if (roomSearchFilters.pets !== 'all' && listing.pets !== roomSearchFilters.pets) {
      return false;
    }

    if (roomSearchFilters.billsIncluded !== 'all') {
      const filterWantsBillsIncluded = roomSearchFilters.billsIncluded === 'yes';
      if (listing.billsIncluded !== filterWantsBillsIncluded) {
        return false;
      }
    }

    return true;
  });

  const filteredRoommateMatches = !hasSearchedRoommate ? [] : matches;

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50/30 via-blue-50/20 to-teal-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <div className="relative overflow-hidden bg-gradient-to-r from-cyan-500 via-teal-500 to-blue-500 py-6 md:py-10 lg:py-12">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container relative mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 sm:gap-3 mb-2 sm:mb-3">
            <span className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl drop-shadow-2xl">🏡</span>
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white drop-shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-700 leading-tight max-w-[90%] sm:max-w-none">
              {t('roommates')}
            </h1>
          </div>
          <p className="text-sm sm:text-base md:text-lg text-white/95 max-w-3xl mx-auto leading-relaxed drop-shadow-lg animate-in fade-in slide-in-from-bottom-4 duration-700 delay-150 px-2">
            {t('roommatesPageTitle')}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-4 sm:mt-0 sm:-mt-6">
        <Tabs defaultValue="find" className="w-full">
          <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-1 sm:grid-cols-3 mb-8 bg-gradient-to-r from-slate-100 to-slate-200 dark:bg-slate-800/95 backdrop-blur-sm shadow-2xl h-auto p-2 sm:p-3 rounded-2xl gap-2 sm:gap-3 border-2 border-slate-300" data-testid="tabs-roommates">
            <TabsTrigger 
              value="find" 
              data-testid="tab-find-roommates"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:via-blue-500 data-[state=active]:to-cyan-500 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:text-slate-700 font-bold rounded-xl transition-all duration-300 data-[state=active]:shadow-2xl data-[state=active]:shadow-blue-500/50 hover:scale-105 min-h-[56px] py-3 sm:py-5 px-3 sm:px-4 flex flex-col items-center justify-center gap-1 sm:gap-2 border-2 data-[state=active]:border-blue-400 data-[state=inactive]:border-slate-300"
            >
              <div className="flex items-center gap-2">
                <span className="text-2xl sm:text-3xl flex-shrink-0">🔍</span>
                <span className="text-sm sm:text-base md:text-lg text-center leading-tight break-words">{t('findRoommateButton')}</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="share" 
              data-testid="tab-share-room"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-600 data-[state=active]:via-green-500 data-[state=active]:to-teal-500 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:text-slate-700 font-bold rounded-xl transition-all duration-300 data-[state=active]:shadow-2xl data-[state=active]:shadow-green-500/50 hover:scale-105 min-h-[56px] py-3 sm:py-5 px-3 sm:px-4 flex flex-col items-center justify-center gap-1 sm:gap-2 border-2 data-[state=active]:border-green-400 data-[state=inactive]:border-slate-300"
            >
              <div className="flex items-center gap-2">
                <span className="text-2xl sm:text-3xl flex-shrink-0">🏠</span>
                <span className="text-sm sm:text-base md:text-lg text-center leading-tight break-words">{t('shareRoomButton')}</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="looking" 
              data-testid="tab-looking-room"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:via-pink-500 data-[state=active]:to-fuchsia-500 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:text-slate-700 font-bold rounded-xl transition-all duration-300 data-[state=active]:shadow-2xl data-[state=active]:shadow-purple-500/50 hover:scale-105 min-h-[56px] py-3 sm:py-5 px-3 sm:px-4 flex flex-col items-center justify-center gap-1 sm:gap-2 border-2 data-[state=active]:border-purple-400 data-[state=inactive]:border-slate-300"
            >
              <div className="flex items-center gap-2">
                <span className="text-2xl sm:text-3xl flex-shrink-0">🔎</span>
                <span className="text-sm sm:text-base md:text-lg text-center leading-tight break-words">{t('lookingForRoom')}</span>
              </div>
            </TabsTrigger>
          </TabsList>

          {/* TAB 1: EV ARKADAŞI BUL (FIND ROOMMATE) */}
          <TabsContent value="find" className="mt-0 animate-in fade-in duration-500">
            <div className="space-y-6 py-6">
              <div className="bg-white/60 dark:from-orange-950/5 dark:to-amber-950/5 border-2 border-orange-200/30 dark:border-orange-800/20 rounded-2xl p-6 shadow-sm backdrop-blur-md">
                <h2 className="text-3xl font-bold text-orange-700 dark:text-orange-300 flex items-center gap-3 mb-3">
                  <span className="text-4xl">🔍</span>
                  {t('findRoommateButton')}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  {t('findRoommateTabDesc')}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {t('profileWillBeVisible')}
                </p>
              </div>

              <Collapsible open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
                <Card className="shadow-2xl border-2 border-blue-100/50">
                  <CardHeader className="bg-gradient-to-br from-blue-50 via-cyan-50 to-blue-50 border-b">
                    <CollapsibleTrigger className="w-full">
                      <CardTitle className="flex items-center justify-between gap-2 text-xl font-bold text-blue-700">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">🔍</span>
                          {t('filters')}
                        </div>
                        <ChevronDown className={`w-5 h-5 transition-transform ${isFiltersOpen ? 'rotate-180' : ''}`} />
                      </CardTitle>
                    </CollapsibleTrigger>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="space-y-4 pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="roommate-city">{t('city')}</Label>
                      <Input
                        id="roommate-city"
                        value={roommateFilters.city}
                        onChange={(e) => setRoommateFilters({ ...roommateFilters, city: e.target.value })}
                        placeholder={t('cityPlaceholder')}
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="roommate-district">{t('district')}</Label>
                      <Input
                        id="roommate-district"
                        value={roommateFilters.district}
                        onChange={(e) => setRoommateFilters({ ...roommateFilters, district: e.target.value })}
                        placeholder={t('districtPlaceholder')}
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="roommate-min-budget">{t('budgetMin')}</Label>
                      <Input
                        id="roommate-min-budget"
                        type="number"
                        value={roommateFilters.minBudget}
                        onChange={(e) => setRoommateFilters({ ...roommateFilters, minBudget: e.target.value })}
                        placeholder="300"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="roommate-max-budget">{t('budgetMax')}</Label>
                      <Input
                        id="roommate-max-budget"
                        type="number"
                        value={roommateFilters.maxBudget}
                        onChange={(e) => setRoommateFilters({ ...roommateFilters, maxBudget: e.target.value })}
                        placeholder="600"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>{t('roomType')}</Label>
                      <Select
                        value={roommateFilters.roomType}
                        onValueChange={(value: 'all' | 'private' | 'shared') => setRoommateFilters({ ...roommateFilters, roomType: value })}
                      >
                        <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="private">{t('privateRoom')}</SelectItem>
                          <SelectItem value="shared">{t('sharedRoom')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('genderPreference')}</Label>
                      <Select
                        value={roommateFilters.genderPreference}
                        onValueChange={(value: 'all' | 'female' | 'male' | 'none') => setRoommateFilters({ ...roommateFilters, genderPreference: value })}
                      >
                        <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="none">{t('noPreference')}</SelectItem>
                          <SelectItem value="female">{t('femaleOnly')}</SelectItem>
                          <SelectItem value="male">{t('maleOnly')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('furnished')}</Label>
                      <Select
                        value={roommateFilters.furnished}
                        onValueChange={(value: 'all' | 'yes' | 'no') => setRoommateFilters({ ...roommateFilters, furnished: value })}
                      >
                        <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="yes">{t('furnished')}</SelectItem>
                          <SelectItem value="no">{t('unfurnished')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('smoking')}</Label>
                      <Select
                        value={roommateFilters.smoking}
                        onValueChange={(value: 'all' | 'allowed' | 'notAllowed') => setRoommateFilters({ ...roommateFilters, smoking: value })}
                      >
                        <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="allowed">{t('smokingAllowed')}</SelectItem>
                          <SelectItem value="notAllowed">{t('noSmoking')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('pets')}</Label>
                      <Select
                        value={roommateFilters.pets}
                        onValueChange={(value: 'all' | 'allowed' | 'notAllowed') => setRoommateFilters({ ...roommateFilters, pets: value })}
                      >
                        <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="allowed">{t('petFriendly')}</SelectItem>
                          <SelectItem value="notAllowed">{t('noPets')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('billsIncluded')}</Label>
                      <Select
                        value={roommateFilters.billsIncluded}
                        onValueChange={(value: 'all' | 'yes' | 'no') => setRoommateFilters({ ...roommateFilters, billsIncluded: value })}
                      >
                        <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="yes">{t('yes')}</SelectItem>
                          <SelectItem value="no">{t('no')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button 
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 font-bold text-lg py-6"
                    onClick={handleFindRoommates}
                    data-testid="button-find-roommates"
                  >
                    🔍 {t('findButton')}
                  </Button>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Alert banner for no results */}
              {hasSearchedRoommate && filteredRoommateMatches.length === 0 && (
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertDescription className="text-yellow-800">
                    {t('noResultsFoundTryFilter')}
                  </AlertDescription>
                </Alert>
              )}

              {/* Profile Creation Section */}
              <Collapsible open={isProfileFormOpen} onOpenChange={setIsProfileFormOpen}>
                <Card className="shadow-2xl border-2 border-green-100/50">
                  <CardHeader className="bg-gradient-to-br from-green-50 via-emerald-50 to-green-50 border-b">
                    <CollapsibleTrigger className="w-full">
                      <CardTitle className="flex items-center justify-between gap-2 text-xl font-bold text-green-700">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">👤</span>
                          {t('createProfile')}
                        </div>
                        <ChevronDown className={`w-5 h-5 transition-transform ${isProfileFormOpen ? 'rotate-180' : ''}`} />
                      </CardTitle>
                    </CollapsibleTrigger>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="space-y-4 pt-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="profile-city">{t('whereDoYouLive')}</Label>
                          <Input
                            id="profile-city"
                            value={profileFormData.city}
                            onChange={(e) => setProfileFormData({ ...profileFormData, city: e.target.value })}
                            placeholder={t('cityPlaceholder')}
                            className="border-green-200 focus:border-green-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="profile-district">{t('district')}</Label>
                          <Input
                            id="profile-district"
                            value={profileFormData.district}
                            onChange={(e) => setProfileFormData({ ...profileFormData, district: e.target.value })}
                            placeholder={t('districtPlaceholder')}
                            className="border-green-200 focus:border-green-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="profile-university">{t('whereDoYouStudy')}</Label>
                          <Input
                            id="profile-university"
                            value={profileFormData.university}
                            onChange={(e) => setProfileFormData({ ...profileFormData, university: e.target.value })}
                            placeholder={t('universityDepartmentPlaceholder')}
                            className="border-green-200 focus:border-green-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="profile-age">{t('age')}</Label>
                          <Input
                            id="profile-age"
                            type="number"
                            value={profileFormData.age}
                            onChange={(e) => setProfileFormData({ ...profileFormData, age: e.target.value })}
                            placeholder={t('agePlaceholder')}
                            className="border-green-200 focus:border-green-500"
                          />
                        </div>

                        <div className="space-y-2 flex items-center gap-3">
                          <Label htmlFor="profile-smoking">{t('smoking')}</Label>
                          <Switch
                            id="profile-smoking"
                            checked={profileFormData.smoking}
                            onCheckedChange={(checked) => setProfileFormData({ ...profileFormData, smoking: checked })}
                          />
                        </div>

                        <div className="space-y-2 flex items-center gap-3">
                          <Label htmlFor="profile-pets">{t('pets')}</Label>
                          <Switch
                            id="profile-pets"
                            checked={profileFormData.pets}
                            onCheckedChange={(checked) => setProfileFormData({ ...profileFormData, pets: checked })}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="profile-description">{t('profileDescription')}</Label>
                        <Textarea
                          id="profile-description"
                          value={profileFormData.description}
                          onChange={(e) => setProfileFormData({ ...profileFormData, description: e.target.value })}
                          placeholder={t('profileDescriptionPlaceholder')}
                          rows={4}
                          className="border-green-200 focus:border-green-500"
                        />
                      </div>

                      <Button 
                        className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 font-bold text-lg py-6"
                        onClick={handleSaveProfile}
                      >
                        💾 {t('saveProfileButton')}
                      </Button>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* My Profile Card */}
              {userProfile && (
                <Card className="shadow-2xl border-2 border-purple-100/50 bg-gradient-to-br from-purple-50 via-pink-50 to-purple-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-xl font-bold text-purple-700">
                      <span className="text-2xl">✨</span>
                      {t('myProfile')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div><strong>{t('city')}:</strong> {userProfile.city}</div>
                    {userProfile.district && <div><strong>{t('district')}:</strong> {userProfile.district}</div>}
                    <div><strong>{t('university')}:</strong> {userProfile.university}</div>
                    <div><strong>{t('age')}:</strong> {userProfile.age}</div>
                    <div><strong>{t('smoking')}:</strong> {userProfile.smoking ? t('yes') : t('no')}</div>
                    <div><strong>{t('pets')}:</strong> {userProfile.pets ? t('yes') : t('no')}</div>
                    {userProfile.description && (
                      <div><strong>{t('description')}:</strong> {userProfile.description}</div>
                    )}
                    <div className="flex gap-2 mt-4">
                      <Button 
                        variant="outline"
                        className="flex-1"
                        onClick={handleEditProfile}
                      >
                        {t('editProfile')}
                      </Button>
                      <Button 
                        variant="destructive"
                        className="flex-1"
                        onClick={handleDeleteProfile}
                      >
                        {t('deleteProfile')}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {hasSearchedRoommate && filteredRoommateMatches.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredRoommateMatches.map((match) => (
                    <div key={match.id} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                      <RoommateCard profile={match} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* TAB 2: ODAMI PAYLAŞIYORUM (I'M SHARING MY ROOM) */}
          <TabsContent value="share" className="mt-0 animate-in fade-in duration-500">
            <div className="space-y-6 py-6">
              <div className="bg-white/60 dark:from-blue-950/5 dark:to-indigo-950/5 border-2 border-blue-200/30 dark:border-blue-800/20 rounded-2xl p-6 shadow-sm backdrop-blur-md">
                <h2 className="text-3xl font-bold text-blue-700 dark:text-blue-300 flex items-center gap-3 mb-3">
                  <span className="text-4xl">🏠</span>
                  {t('shareRoomButton')}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {t('shareRoomTabDesc')}
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                  <Card className="shadow-2xl border-2 border-green-100/50">
                    <CardHeader className="bg-gradient-to-br from-green-50 via-emerald-50 to-green-50 border-b">
                      <CardTitle className="flex items-center gap-2 text-xl font-bold text-green-700">
                        <span className="text-2xl">{editingListingId ? '✏️' : '➕'}</span>
                        {editingListingId ? t('updateListing') : t('newListing')}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 pt-6">
                      <div className="space-y-2">
                        <Label htmlFor="listing-title">{t('title')}</Label>
                        <Input
                          id="listing-title"
                          value={newListing.title}
                          onChange={(e) => setNewListing({ ...newListing, title: e.target.value })}
                          placeholder={t('listingTitlePlaceholder')}
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-description">{t('description')}</Label>
                        <Textarea
                          id="listing-description"
                          value={newListing.description}
                          onChange={(e) => setNewListing({ ...newListing, description: e.target.value })}
                          placeholder={t('descriptionPlaceholder')}
                          rows={3}
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-city">{t('city')}</Label>
                        <Input
                          id="listing-city"
                          value={newListing.city}
                          onChange={(e) => setNewListing({ ...newListing, city: e.target.value })}
                          placeholder={t('cityPlaceholder')}
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-district">{t('district')}</Label>
                        <Input
                          id="listing-district"
                          value={newListing.district || ''}
                          onChange={(e) => setNewListing({ ...newListing, district: e.target.value })}
                          placeholder={t('districtPlaceholder')}
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>{t('roomType')}</Label>
                        <Select
                          value={newListing.roomType}
                          onValueChange={(value: 'private' | 'shared') => setNewListing({ ...newListing, roomType: value })}
                        >
                          <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="private">{t('privateRoom')}</SelectItem>
                            <SelectItem value="shared">{t('sharedRoom')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="listing-rent">{t('rentPrice')}</Label>
                          <Input
                            id="listing-rent"
                            type="number"
                            value={newListing.rentPrice || ''}
                            onChange={(e) => setNewListing({ ...newListing, rentPrice: Number(e.target.value) })}
                            placeholder="450"
                            className="border-cyan-200 focus:border-cyan-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="listing-deposit">{t('deposit')}</Label>
                          <Input
                            id="listing-deposit"
                            type="number"
                            value={newListing.deposit || ''}
                            onChange={(e) => setNewListing({ ...newListing, deposit: Number(e.target.value) })}
                            placeholder="450"
                            className="border-cyan-200 focus:border-cyan-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-owner">{t('ownerName')}</Label>
                        <Input
                          id="listing-owner"
                          value={newListing.ownerName}
                          onChange={(e) => setNewListing({ ...newListing, ownerName: e.target.value })}
                          placeholder={t('ownerNamePlaceholder')}
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-location">{t('locationLink')}</Label>
                        <Input
                          id="listing-location"
                          value={newListing.locationUrl}
                          onChange={(e) => setNewListing({ ...newListing, locationUrl: e.target.value })}
                          placeholder={t('locationLinkPlaceholder')}
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>{t('genderPreference')}</Label>
                        <Select
                          value={newListing.genderPreference}
                          onValueChange={(value: 'female' | 'male' | 'none') => setNewListing({ ...newListing, genderPreference: value })}
                        >
                          <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">{t('noPreference')}</SelectItem>
                            <SelectItem value="female">{t('femaleOnly')}</SelectItem>
                            <SelectItem value="male">{t('maleOnly')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>{t('furnished')}</Label>
                        <Select
                          value={newListing.furnished}
                          onValueChange={(value: 'yes' | 'no') => setNewListing({ ...newListing, furnished: value })}
                        >
                          <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">{t('furnished')}</SelectItem>
                            <SelectItem value="no">{t('unfurnished')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>{t('smoking')}</Label>
                        <Select
                          value={newListing.smoking}
                          onValueChange={(value: 'allowed' | 'notAllowed') => setNewListing({ ...newListing, smoking: value })}
                        >
                          <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="allowed">{t('smokingAllowed')}</SelectItem>
                            <SelectItem value="notAllowed">{t('noSmoking')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>{t('pets')}</Label>
                        <Select
                          value={newListing.pets}
                          onValueChange={(value: 'allowed' | 'notAllowed') => setNewListing({ ...newListing, pets: value })}
                        >
                          <SelectTrigger className="border-cyan-200 focus:border-cyan-500">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="allowed">{t('petFriendly')}</SelectItem>
                            <SelectItem value="notAllowed">{t('noPets')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-cyan-50/50 to-teal-50/50 dark:from-cyan-950/20 dark:to-teal-950/20 rounded-lg">
                        <Label htmlFor="bills-included">{t('billsIncluded')}</Label>
                        <Switch
                          id="bills-included"
                          checked={newListing.billsIncluded}
                          onCheckedChange={(checked) => setNewListing({ ...newListing, billsIncluded: checked })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>{t('uploadPhotos')} ({(newListing.photos || []).length}/12)</Label>
                        <div className="relative">
                          <Button
                            variant="outline"
                            className="w-full border-2 border-dashed border-cyan-300 hover:border-cyan-500"
                            onClick={() => document.getElementById('photo-upload')?.click()}
                            type="button"
                          >
                            <Upload className="mr-2 h-4 w-4" />
                            {t('uploadPhotos')}
                          </Button>
                          <input
                            id="photo-upload"
                            type="file"
                            className="hidden"
                            onChange={handlePhotoUpload}
                            accept="image/*"
                            multiple
                          />
                          {newListing.photos && newListing.photos.length > 0 && (
                            <div className="grid grid-cols-4 gap-2 mt-2">
                              {newListing.photos.map((photo, idx) => (
                                <div key={idx} className="relative aspect-square group">
                                  <img src={photo} alt={`Photo ${idx + 1}`} className="w-full h-full object-cover rounded-md ring-2 ring-cyan-200" />
                                  <Button
                                    variant="destructive"
                                    size="icon"
                                    className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => {
                                      const photos = [...(newListing.photos || [])];
                                      photos.splice(idx, 1);
                                      setNewListing({ ...newListing, photos });
                                    }}
                                    type="button"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        {editingListingId && (
                          <Button 
                            variant="outline"
                            className="flex-1"
                            onClick={() => {
                              setEditingListingId(null);
                              setNewListing({
                                title: '',
                                description: '',
                                city: '',
                                district: '',
                                rentPrice: 0,
                                roomType: 'private',
                                locationUrl: '',
                                ownerName: '',
                                photos: [],
                                smoking: 'notAllowed',
                                pets: 'notAllowed',
                                furnished: 'yes',
                                genderPreference: 'none',
                                deposit: 0,
                                billsIncluded: false,
                              });
                            }}
                          >
                            {t('cancel')}
                          </Button>
                        )}
                        <Button 
                          className={`${editingListingId ? 'flex-1' : 'w-full'} bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg hover:shadow-xl transition-all duration-300`}
                          onClick={handleSaveListing}
                        >
                          {editingListingId ? '✅ ' + t('updateListing') : '✅ ' + t('saveListing')}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="lg:col-span-2 space-y-6">
                  <Card className="shadow-lg">
                    <CardHeader className="bg-gradient-to-br from-green-50 to-emerald-50 border-b">
                      <CardTitle className="flex items-center gap-2 text-xl font-bold text-green-700">
                        <span className="text-2xl">📋</span>
                        {t('myListings')}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                      {listings.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {listings.map((listing) => (
                            <div key={listing.id} className="relative group">
                              <RoomListingCard 
                                listing={listing}
                                onViewDetails={handleViewDetails}
                              />
                              <div className="flex gap-2 mt-3">
                                <Button
                                  variant="outline"
                                  className="flex-1 border-blue-300 text-blue-700 hover:bg-blue-50"
                                  onClick={() => handleEditListing(listing)}
                                >
                                  ✏️ {t('edit')}
                                </Button>
                                <Button
                                  variant="outline"
                                  className="flex-1 border-red-300 text-red-700 hover:bg-red-50"
                                  onClick={() => handleDeleteListing(listing.id)}
                                >
                                  🗑️ {t('delete')}
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <p className="text-lg text-gray-500">{t('noListingsYet')}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* TAB 3: ODA ARIYORUM (LOOKING FOR A ROOM) */}
          <TabsContent value="looking" className="mt-0 animate-in fade-in duration-500">
            <div className="space-y-6 py-6">
              <div className="bg-white/60 dark:from-purple-950/5 dark:to-pink-950/5 border-2 border-purple-200/30 dark:border-purple-800/20 rounded-2xl p-6 shadow-sm backdrop-blur-md">
                <h2 className="text-3xl font-bold text-purple-700 dark:text-purple-300 flex items-center gap-3 mb-3">
                  <span className="text-4xl">🔎</span>
                  {t('lookingForRoom')}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {t('lookingForRoomDesc')}
                </p>
              </div>

              <Collapsible open={isRoomFiltersOpen} onOpenChange={setIsRoomFiltersOpen}>
                <Card className="shadow-2xl border-2 border-purple-100/50">
                  <CardHeader className="bg-gradient-to-br from-purple-50 via-pink-50 to-purple-50 border-b">
                    <CollapsibleTrigger className="w-full">
                      <CardTitle className="flex items-center justify-between gap-2 text-xl font-bold text-purple-700">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">🔍</span>
                          {t('filters')}
                        </div>
                        <ChevronDown className={`w-5 h-5 transition-transform ${isRoomFiltersOpen ? 'rotate-180' : ''}`} />
                      </CardTitle>
                    </CollapsibleTrigger>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="space-y-4 pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="room-search-city">{t('city')}</Label>
                      <Input
                        id="room-search-city"
                        value={roomSearchFilters.city}
                        onChange={(e) => setRoomSearchFilters({ ...roomSearchFilters, city: e.target.value })}
                        placeholder={t('cityPlaceholder')}
                        className="border-purple-200 focus:border-purple-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="room-search-district">{t('district')}</Label>
                      <Input
                        id="room-search-district"
                        value={roomSearchFilters.district}
                        onChange={(e) => setRoomSearchFilters({ ...roomSearchFilters, district: e.target.value })}
                        placeholder={t('districtPlaceholder')}
                        className="border-purple-200 focus:border-purple-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="room-search-min-rent">{t('minRent')}</Label>
                      <Input
                        id="room-search-min-rent"
                        type="number"
                        value={roomSearchFilters.minRent}
                        onChange={(e) => setRoomSearchFilters({ ...roomSearchFilters, minRent: e.target.value })}
                        placeholder="300"
                        className="border-purple-200 focus:border-purple-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="room-search-max-rent">{t('maxRent')}</Label>
                      <Input
                        id="room-search-max-rent"
                        type="number"
                        value={roomSearchFilters.maxRent}
                        onChange={(e) => setRoomSearchFilters({ ...roomSearchFilters, maxRent: e.target.value })}
                        placeholder="600"
                        className="border-purple-200 focus:border-purple-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>{t('roomType')}</Label>
                      <Select
                        value={roomSearchFilters.roomType}
                        onValueChange={(value: 'all' | 'private' | 'shared') => setRoomSearchFilters({ ...roomSearchFilters, roomType: value })}
                      >
                        <SelectTrigger className="border-purple-200 focus:border-purple-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="private">{t('privateRoom')}</SelectItem>
                          <SelectItem value="shared">{t('sharedRoom')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('genderPreference')}</Label>
                      <Select
                        value={roomSearchFilters.genderPreference}
                        onValueChange={(value: 'all' | 'female' | 'male' | 'none') => setRoomSearchFilters({ ...roomSearchFilters, genderPreference: value })}
                      >
                        <SelectTrigger className="border-purple-200 focus:border-purple-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="none">{t('noPreference')}</SelectItem>
                          <SelectItem value="female">{t('femaleOnly')}</SelectItem>
                          <SelectItem value="male">{t('maleOnly')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('furnished')}</Label>
                      <Select
                        value={roomSearchFilters.furnished}
                        onValueChange={(value: 'all' | 'yes' | 'no') => setRoomSearchFilters({ ...roomSearchFilters, furnished: value })}
                      >
                        <SelectTrigger className="border-purple-200 focus:border-purple-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="yes">{t('furnished')}</SelectItem>
                          <SelectItem value="no">{t('unfurnished')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('smoking')}</Label>
                      <Select
                        value={roomSearchFilters.smoking}
                        onValueChange={(value: 'all' | 'allowed' | 'notAllowed') => setRoomSearchFilters({ ...roomSearchFilters, smoking: value })}
                      >
                        <SelectTrigger className="border-purple-200 focus:border-purple-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="allowed">{t('smokingAllowed')}</SelectItem>
                          <SelectItem value="notAllowed">{t('noSmoking')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('pets')}</Label>
                      <Select
                        value={roomSearchFilters.pets}
                        onValueChange={(value: 'all' | 'allowed' | 'notAllowed') => setRoomSearchFilters({ ...roomSearchFilters, pets: value })}
                      >
                        <SelectTrigger className="border-purple-200 focus:border-purple-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="allowed">{t('petFriendly')}</SelectItem>
                          <SelectItem value="notAllowed">{t('noPets')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>{t('billsIncluded')}</Label>
                      <Select
                        value={roomSearchFilters.billsIncluded}
                        onValueChange={(value: 'all' | 'yes' | 'no') => setRoomSearchFilters({ ...roomSearchFilters, billsIncluded: value })}
                      >
                        <SelectTrigger className="border-purple-200 focus:border-purple-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('all')}</SelectItem>
                          <SelectItem value="yes">{t('yes')}</SelectItem>
                          <SelectItem value="no">{t('no')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button 
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 font-bold text-lg py-6"
                    onClick={handleSearchRooms}
                  >
                    🔍 {t('findButton')}
                  </Button>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Alert banner for no results */}
              {hasSearchedRooms && filteredRoomListings.length === 0 && (
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertDescription className="text-yellow-800">
                    {t('noResultsFoundTryFilter')}
                  </AlertDescription>
                </Alert>
              )}

              {hasSearchedRooms && filteredRoomListings.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredRoomListings.map((listing) => (
                    <div key={listing.id} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                      <RoomListingCard 
                        listing={listing}
                        onViewDetails={handleViewDetails}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {selectedListing && (
        <>
          <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                  {selectedListing.title}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                {selectedListing.photos && selectedListing.photos.length > 0 && (
                  <div className="grid grid-cols-2 gap-2">
                    {selectedListing.photos.map((photo, idx) => (
                      <img
                        key={idx}
                        src={photo}
                        alt={`Photo ${idx + 1}`}
                        className="w-full aspect-video object-cover rounded-lg"
                      />
                    ))}
                  </div>
                )}
                <div className="space-y-2">
                  <p className="text-sm"><strong>{t('city')}:</strong> {selectedListing.city}</p>
                  {selectedListing.district && <p className="text-sm"><strong>{t('district')}:</strong> {selectedListing.district}</p>}
                  <p className="text-sm"><strong>{t('rentPrice')}:</strong> €{selectedListing.rentPrice}/month</p>
                  {selectedListing.deposit && selectedListing.deposit > 0 && (
                    <p className="text-sm"><strong>{t('deposit')}:</strong> €{selectedListing.deposit}</p>
                  )}
                  <p className="text-sm"><strong>{t('roomType')}:</strong> {selectedListing.roomType === 'private' ? t('privateRoom') : t('sharedRoom')}</p>
                  <p className="text-sm"><strong>{t('description')}:</strong> {selectedListing.description}</p>
                  <p className="text-sm"><strong>{t('ownerName')}:</strong> {selectedListing.ownerName}</p>
                </div>
                {selectedListing.locationUrl && (
                  <Button
                    className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white"
                    onClick={handleShowLocation}
                  >
                    📍 {t('showLocation')}
                  </Button>
                )}
              </div>
            </DialogContent>
          </Dialog>

          <MapModal
            open={showMapModal}
            onOpenChange={setShowMapModal}
            locationUrl={selectedListing.locationUrl || ''}
            title={selectedListing.title}
          />
        </>
      )}
    </div>
  );
}
