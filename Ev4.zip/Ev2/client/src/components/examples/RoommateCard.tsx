import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import RoommateCard from '../RoommateCard';

const mockProfiles = [
  {
    id: '1',
    name: 'Maria Rossi',
    city: 'Milan',
    university: 'Politecnico di Milano',
    budgetMin: 400,
    budgetMax: 600,
    pets: false,
    smoker: false,
    cleanliness: 5,
    noiseTolerance: 3,
    matchPercentage: 85,
  },
  {
    id: '2',
    name: 'Ahmed Hassan',
    city: 'Rome',
    university: 'Sapienza University',
    budgetMin: 350,
    budgetMax: 500,
    pets: true,
    smoker: false,
    cleanliness: 4,
    noiseTolerance: 4,
    matchPercentage: 62,
  },
];

export default function RoommateCardExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          {mockProfiles.map(profile => (
            <RoommateCard key={profile.id} profile={profile} />
          ))}
        </div>
      </LanguageProvider>
    </ThemeProvider>
  );
}
