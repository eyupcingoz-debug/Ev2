import { Dorm } from './types';

export const paviaDorms: Dorm[] = [
  {
    city: "Pavia",
    name: {
      en: "EDiSU Colleges",
      it: "Collegi EDiSU",
      tr: "EDiSU Kolejleri",
      ar: "كليات EDiSU"
    },
    university: "Università di Pavia",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 180,
    priceMax: 380,
    applicationLink: "https://www.edisu.pv.it/",
    mapLink: "https://maps.google.com/?q=EDiSU+Pavia+Collegi",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Library"],
    recommended: true
  },
  {
    city: "Pavia",
    name: {
      en: "Castiglioni-Brugnatelli College",
      it: "Collegio Castiglioni-Brugnatelli",
      tr: "Castiglioni-Brugnatelli Koleji",
      ar: "كلية كاستيليوني-بروغناتيلي"
    },
    university: "Università di Pavia",
    gender: "Mixed",
    roomTypes: ["Single"],
    priceMin: 200,
    priceMax: 400,
    applicationLink: "https://www.collegicasbrugn.unipv.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Castiglioni+Brugnatelli+Pavia",
    features: ["Wi-Fi", "Library", "Study rooms", "Cultural events"],
    recommended: true
  },
  {
    city: "Pavia",
    name: {
      en: "Plinio Fraccaro College",
      it: "Collegio Plinio Fraccaro",
      tr: "Plinio Fraccaro Koleji",
      ar: "كلية بلينيو فراكارو"
    },
    university: "Università di Pavia",
    gender: "Mixed",
    roomTypes: ["Single"],
    priceMin: 190,
    priceMax: 390,
    applicationLink: "https://www.collegiofraccaro.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Plinio+Fraccaro+Pavia",
    features: ["Wi-Fi", "Library", "Study rooms", "Canteen"]
  },
  {
    city: "Pavia",
    name: {
      en: "Cairoli College",
      it: "Collegio Cairoli",
      tr: "Cairoli Koleji",
      ar: "كلية كايرولي"
    },
    university: "Università di Pavia",
    gender: "Mixed",
    roomTypes: ["Single"],
    priceMin: 210,
    priceMax: 410,
    applicationLink: "https://www.collegiocairoli.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Cairoli+Pavia",
    features: ["Wi-Fi", "Study rooms", "Library", "Sports facilities"]
  },
  {
    city: "Pavia",
    name: {
      en: "Ghislieri College",
      it: "Collegio Ghislieri",
      tr: "Ghislieri Koleji",
      ar: "كلية غيسليري"
    },
    university: "Università di Pavia",
    gender: "Mixed",
    roomTypes: ["Single"],
    priceMin: 200,
    priceMax: 400,
    applicationLink: "https://www.ghislieri.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Ghislieri+Pavia",
    features: ["Wi-Fi", "Library", "Study rooms", "Canteen", "Cultural activities"]
  },
  {
    city: "Pavia",
    name: {
      en: "Borromeo College",
      it: "Collegio Borromeo",
      tr: "Borromeo Koleji",
      ar: "كلية بوروميو"
    },
    university: "Università di Pavia",
    gender: "Male",
    roomTypes: ["Single"],
    priceMin: 180,
    priceMax: 380,
    applicationLink: "https://www.collegioborromeo.it/",
    mapLink: "https://maps.google.com/?q=Collegio+Borromeo+Pavia",
    features: ["Wi-Fi", "Library", "Chapel", "Study rooms", "Historic building"]
  },
  {
    city: "Pavia",
    name: {
      en: "Pavia Student Residences",
      it: "Residenze Universitarie Pavia",
      tr: "Pavia Öğrenci Yurtları",
      ar: "مساكن بافيا الطلابية"
    },
    university: "Università di Pavia",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.edisu.pv.it/",
    mapLink: "https://maps.google.com/?q=Residenze+Universitarie+Pavia",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  }
];
