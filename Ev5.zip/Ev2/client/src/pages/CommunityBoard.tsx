import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { MessageSquare, Search, AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';

interface Comment {
  id: string;
  text: string;
  timestamp: string;
}

interface Topic {
  id: string;
  title: string;
  category: string;
  description: string;
  comments: Comment[];
  timestamp: string;
}

const CATEGORIES = [
  'cat_permesso',
  'cat_codiceFiscale',
  'cat_health',
  'cat_anagrafe',
  'cat_university',
  'cat_dsu',
  'cat_patente',
  'cat_housing',
  'cat_transportation',
];

export default function CommunityBoard() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();

  const [topics, setTopics] = useState<Topic[]>(() => {
    const saved = localStorage.getItem('community.threads');
    return saved ? JSON.parse(saved) : [];
  });

  const [newTopic, setNewTopic] = useState({
    title: '',
    category: '',
    description: '',
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'newest' | 'mostCommented'>('newest');
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [newComment, setNewComment] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  useEffect(() => {
    localStorage.setItem('community.threads', JSON.stringify(topics));
  }, [topics]);

  const handleCreateTopic = () => {
    if (!newTopic.title || !newTopic.category || !newTopic.description) {
      toast({
        title: t('createTopic'),
        description: 'Please fill in all fields',
        variant: 'destructive',
      });
      return;
    }

    const topic: Topic = {
      id: Date.now().toString(),
      title: newTopic.title,
      category: newTopic.category,
      description: newTopic.description,
      comments: [],
      timestamp: new Date().toISOString(),
    };

    setTopics([topic, ...topics]);
    setNewTopic({ title: '', category: '', description: '' });
    setShowCreateDialog(false);

    toast({
      title: t('createTopic'),
      description: t('topicCreated'),
    });
  };

  const handleAddComment = () => {
    if (!selectedTopic || !newComment.trim()) return;

    const comment: Comment = {
      id: Date.now().toString(),
      text: newComment,
      timestamp: new Date().toISOString(),
    };

    setTopics(topics.map(topic =>
      topic.id === selectedTopic.id
        ? { ...topic, comments: [...topic.comments, comment] }
        : topic
    ));

    setNewComment('');

    toast({
      title: t('addComment'),
      description: t('commentAdded'),
    });
  };

  const filteredTopics = topics
    .filter(topic => {
      const matchesSearch = topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          topic.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === 'all' || topic.category === filterCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      } else {
        return b.comments.length - a.comments.length;
      }
    });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('communityBoard')}</h1>
        <p className="text-muted-foreground">{t('communityBoardDesc')}</p>
      </div>

      <div className="mb-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
        <p className="text-sm text-foreground">
          <AlertTriangle className="h-4 w-4 inline mr-2" />
          {t('moderationNote')}
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('searchTopics')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-topics"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-[200px]" data-testid="select-filter-category">
            <SelectValue placeholder={t('filterByCategory')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('allCategories')}</SelectItem>
            {CATEGORIES.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {t(cat)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as 'newest' | 'mostCommented')}>
          <SelectTrigger className="w-full sm:w-[180px]" data-testid="select-sort-by">
            <SelectValue placeholder={t('sortBy')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">{t('newest')}</SelectItem>
            <SelectItem value="mostCommented">{t('mostCommented')}</SelectItem>
          </SelectContent>
        </Select>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-topic">{t('createTopic')}</Button>
          </DialogTrigger>
          <DialogContent data-testid="dialog-create-topic">
            <DialogHeader>
              <DialogTitle>{t('createTopic')}</DialogTitle>
              <DialogDescription>{t('communityBoardDesc')}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="topic-category">{t('category')}</Label>
                <Select value={newTopic.category} onValueChange={(v) => setNewTopic({ ...newTopic, category: v })}>
                  <SelectTrigger id="topic-category" data-testid="select-topic-category">
                    <SelectValue placeholder={t('selectCategory')} />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {t(cat)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="topic-title">{t('title')}</Label>
                <Input
                  id="topic-title"
                  value={newTopic.title}
                  onChange={(e) => setNewTopic({ ...newTopic, title: e.target.value })}
                  placeholder={t('title')}
                  data-testid="input-topic-title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="topic-description">{t('description')}</Label>
                <Textarea
                  id="topic-description"
                  value={newTopic.description}
                  onChange={(e) => setNewTopic({ ...newTopic, description: e.target.value })}
                  placeholder={t('description')}
                  rows={4}
                  data-testid="textarea-topic-description"
                />
              </div>
              <Button onClick={handleCreateTopic} className="w-full" data-testid="button-submit-topic">
                {t('createTopic')}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {filteredTopics.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-lg text-muted-foreground">{t('noTopicsYet')}</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredTopics.map((topic) => (
            <Card
              key={topic.id}
              className="hover-elevate cursor-pointer"
              onClick={() => setSelectedTopic(topic)}
              data-testid={`card-topic-${topic.id}`}
            >
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <CardTitle className="text-base">{topic.title}</CardTitle>
                    <CardDescription className="mt-1">{topic.description}</CardDescription>
                  </div>
                  <Badge variant="secondary" data-testid={`badge-category-${topic.id}`}>
                    {t(topic.category)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MessageSquare className="h-4 w-4" />
                    <span>{topic.comments.length} {t('comments')}</span>
                  </div>
                  <span>{new Date(topic.timestamp).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {selectedTopic && (
        <Dialog open={!!selectedTopic} onOpenChange={() => setSelectedTopic(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" data-testid="dialog-topic-details">
            <DialogHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <DialogTitle>{selectedTopic.title}</DialogTitle>
                  <Badge variant="secondary" className="mt-2">
                    {t(selectedTopic.category)}
                  </Badge>
                </div>
              </div>
              <DialogDescription className="text-left">
                {selectedTopic.description}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MessageSquare className="h-4 w-4" />
                <span>{selectedTopic.comments.length} {t('comments')}</span>
                <span>•</span>
                <span>{new Date(selectedTopic.timestamp).toLocaleDateString()}</span>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-4">{t('comments')}</h3>
                <div className="space-y-3 mb-4">
                  {selectedTopic.comments.map((comment) => (
                    <Card key={comment.id} data-testid={`comment-${comment.id}`}>
                      <CardContent className="pt-4">
                        <p className="text-sm">{comment.text}</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(comment.timestamp).toLocaleDateString()} {new Date(comment.timestamp).toLocaleTimeString()}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="space-y-2">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={t('writeComment')}
                    rows={3}
                    data-testid="textarea-new-comment"
                  />
                  <Button onClick={handleAddComment} className="w-full" data-testid="button-post-comment">
                    {t('postComment')}
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
