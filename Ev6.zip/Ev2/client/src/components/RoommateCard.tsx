import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Home, Euro, Dog, Cigarette, Sparkles, Volume2, Trophy } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export interface RoommateProfile {
  id: string;
  name: string;
  city: string;
  university: string;
  budgetMin: number;
  budgetMax: number;
  pets: boolean;
  smoker: boolean;
  cleanliness: number;
  noiseTolerance: number;
  matchPercentage?: number;
}

interface RoommateCardProps {
  profile: RoommateProfile;
}

export default function RoommateCard({ profile }: RoommateCardProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);

  const getColorClass = (percentage: number) => {
    if (percentage >= 75) return 'from-green-500 to-emerald-600';
    if (percentage >= 50) return 'from-yellow-500 to-orange-500';
    return 'from-red-500 to-pink-600';
  };

  const getMatchBadgeColor = (percentage: number) => {
    if (percentage >= 75) return 'bg-gradient-to-r from-green-500 to-emerald-600';
    if (percentage >= 50) return 'bg-gradient-to-r from-yellow-500 to-orange-500';
    return 'bg-gradient-to-r from-red-500 to-pink-600';
  };

  const initials = profile.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="group relative overflow-hidden hover:shadow-2xl hover:shadow-cyan-500/20 transition-all duration-500 transform hover:-translate-y-2 border-2 border-transparent hover:border-cyan-200 dark:hover:border-cyan-800 bg-gradient-to-br from-white to-cyan-50/30 dark:from-slate-800 dark:to-cyan-950/20" data-testid={`card-roommate-${profile.id}`}>
      {profile.matchPercentage !== undefined && profile.matchPercentage >= 75 && (
        <div className="absolute top-0 right-0 w-32 h-32 -mr-16 -mt-16 bg-gradient-to-br from-green-400 to-emerald-600 opacity-20 rotate-45 transform transition-transform duration-500 group-hover:scale-150"></div>
      )}
      
      <CardHeader className="pb-3 relative">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4 flex-1">
            <div className="relative">
              <Avatar className="h-16 w-16 ring-4 ring-cyan-100 dark:ring-cyan-900/50 transition-transform duration-300 group-hover:scale-110">
                <AvatarFallback className="text-lg font-bold bg-gradient-to-br from-cyan-500 via-teal-500 to-blue-500 text-white">
                  {initials}
                </AvatarFallback>
              </Avatar>
              {profile.matchPercentage !== undefined && profile.matchPercentage >= 90 && (
                <div className="absolute -bottom-1 -right-1 bg-yellow-400 rounded-full p-1 ring-2 ring-white dark:ring-slate-800">
                  <Trophy className="h-3 w-3 text-yellow-900" />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-lg truncate bg-gradient-to-r from-slate-800 to-slate-600 dark:from-white dark:to-slate-300 bg-clip-text text-transparent">
                {profile.name}
              </h3>
              <p className="text-sm text-muted-foreground truncate">{profile.university}</p>
            </div>
          </div>
          {profile.matchPercentage !== undefined && (
            <div className="flex flex-col items-end gap-1">
              <Badge className={`${getMatchBadgeColor(profile.matchPercentage)} text-white text-base font-bold px-3 py-1 shadow-lg`}>
                {profile.matchPercentage}%
              </Badge>
              <span className="text-xs text-muted-foreground">Match</span>
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4 pb-4">
        <div className="flex items-center gap-2 text-sm p-3 bg-gradient-to-r from-cyan-50 to-teal-50 dark:from-cyan-950/30 dark:to-teal-950/30 rounded-lg">
          <Home className="h-4 w-4 text-cyan-600 dark:text-cyan-400" />
          <span className="font-semibold text-foreground">{profile.city}</span>
        </div>
        
        <div className="flex items-baseline gap-2 p-3 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 rounded-lg">
          <Euro className="h-5 w-5 text-green-600 dark:text-green-400" />
          <span className="text-lg font-bold text-foreground">
            €{profile.budgetMin} - €{profile.budgetMax}
          </span>
          <span className="text-xs text-muted-foreground">/month</span>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <div className={`flex items-center justify-between px-3 py-2 rounded-lg ${profile.pets ? 'bg-blue-50 dark:bg-blue-950/30' : 'bg-gray-50 dark:bg-gray-950/30'}`}>
            <div className="flex items-center gap-2">
              <Dog className={`h-4 w-4 ${profile.pets ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">{t('pets')}</span>
            </div>
            <Badge variant={profile.pets ? 'default' : 'outline'} className={profile.pets ? 'bg-blue-500' : ''}>
              {profile.pets ? t('yes') : t('no')}
            </Badge>
          </div>
          
          <div className={`flex items-center justify-between px-3 py-2 rounded-lg ${profile.smoker ? 'bg-orange-50 dark:bg-orange-950/30' : 'bg-green-50 dark:bg-green-950/30'}`}>
            <div className="flex items-center gap-2">
              <Cigarette className={`h-4 w-4 ${profile.smoker ? 'text-orange-600 dark:text-orange-400' : 'text-green-600 dark:text-green-400'}`} />
              <span className="text-xs font-medium">{t('smoker')}</span>
            </div>
            <Badge variant={profile.smoker ? 'destructive' : 'default'} className={!profile.smoker ? 'bg-green-500' : ''}>
              {profile.smoker ? t('yes') : t('no')}
            </Badge>
          </div>
        </div>
        
        <div className="space-y-2 pt-2">
          <div className="flex items-center justify-between p-3 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/30 dark:to-pink-950/30 rounded-lg">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              <span className="text-sm font-medium">{t('cleanliness')}</span>
            </div>
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className={`w-2 h-6 rounded-full transition-all duration-300 ${
                    i < profile.cleanliness
                      ? 'bg-gradient-to-t from-purple-500 to-pink-500'
                      : 'bg-gray-200 dark:bg-gray-700'
                  }`}
                />
              ))}
            </div>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 rounded-lg">
            <div className="flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <span className="text-sm font-medium">{t('noiseTolerance')}</span>
            </div>
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className={`w-2 h-6 rounded-full transition-all duration-300 ${
                    i < profile.noiseTolerance
                      ? 'bg-gradient-to-t from-blue-500 to-cyan-500'
                      : 'bg-gray-200 dark:bg-gray-700'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          variant="outline" 
          className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white border-0 font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" 
          disabled 
          data-testid={`button-contact-${profile.id}`}
        >
          {t('contact')}
        </Button>
      </CardFooter>
    </Card>
  );
}
