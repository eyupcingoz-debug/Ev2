import { Dorm } from './types';

export const milanDorms: Dorm[] = [
  {
    city: "Milan",
    name: {
      en: "Residenza Majorana",
      it: "Residenza Majorana",
      tr: "Majorana Yurdu",
      ar: "سكن ماجورانا"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 380,
    priceMax: 580,
    applicationLink: "https://www.ersuimilano.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Majorana+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Canteen"],
    recommended: true
  },
  {
    city: "Milan",
    name: {
      en: "Residenza Leonardo",
      it: "Residenza Leonardo",
      tr: "Leonardo Yurdu",
      ar: "سكن ليوناردو"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 400,
    priceMax: 600,
    applicationLink: "https://www.ersuimilano.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Leonardo+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Gym"],
    recommended: true
  },
  {
    city: "Milan",
    name: {
      en: "Residenza Newton",
      it: "Residenza Newton",
      tr: "Newton Yurdu",
      ar: "سكن نيوتن"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 390,
    priceMax: 590,
    applicationLink: "https://www.ersuimilano.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Newton+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Cafeteria"]
  },
  {
    city: "Milan",
    name: {
      en: "Residenza Pareto",
      it: "Residenza Pareto",
      tr: "Pareto Yurdu",
      ar: "سكن باريتو"
    },
    university: "Bocconi University",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 450,
    priceMax: 700,
    applicationLink: "https://www.unibocconi.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Pareto+Milano",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry"]
  },
  {
    city: "Milan",
    name: {
      en: "Residenza Einstein",
      it: "Residenza Einstein",
      tr: "Einstein Yurdu",
      ar: "سكن أينشتاين"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 410,
    priceMax: 610,
    applicationLink: "https://www.ersuimilano.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Einstein+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Common kitchen"]
  },
  {
    city: "Milan",
    name: {
      en: "Residenza Marie Curie",
      it: "Residenza Marie Curie",
      tr: "Marie Curie Yurdu",
      ar: "سكن ماري كوري"
    },
    university: "Università degli Studi di Milano",
    gender: "Female",
    roomTypes: ["Single", "Double"],
    priceMin: 420,
    priceMax: 620,
    applicationLink: "https://www.unimi.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Marie+Curie+Milano",
    features: ["Wi-Fi", "Study rooms", "Garden", "Common areas"]
  },
  {
    city: "Milan",
    name: {
      en: "Residenza Galileo Galilei",
      it: "Residenza Galileo Galilei",
      tr: "Galileo Galilei Yurdu",
      ar: "سكن غاليليو غاليلي"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 400,
    priceMax: 600,
    applicationLink: "https://www.ersuimilano.it/",
    mapLink: "https://maps.google.com/?q=Residenza+Galileo+Galilei+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Bike parking"]
  },
  {
    city: "Milan",
    name: {
      en: "UniMi Bassini",
      it: "UniMi Bassini",
      tr: "UniMi Bassini",
      ar: "يونيمي باسيني"
    },
    university: "Università degli Studi di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 380,
    priceMax: 550,
    applicationLink: "https://www.unimi.it/",
    mapLink: "https://maps.google.com/?q=UniMi+Bassini+Milano",
    features: ["Wi-Fi", "Study rooms", "Cafeteria", "Common areas"]
  },
  {
    city: "Milan",
    name: {
      en: "UniMi Ripamonti",
      it: "UniMi Ripamonti",
      tr: "UniMi Ripamonti",
      ar: "يونيمي ريبامونتي"
    },
    university: "Università degli Studi di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 390,
    priceMax: 560,
    applicationLink: "https://www.unimi.it/",
    mapLink: "https://maps.google.com/?q=UniMi+Ripamonti+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Garden"]
  },
  {
    city: "Milan",
    name: {
      en: "UniMi Arcobaleno",
      it: "UniMi Arcobaleno",
      tr: "UniMi Arcobaleno",
      ar: "يونيمي أركوبالينو"
    },
    university: "Università degli Studi di Milano",
    gender: "Female",
    roomTypes: ["Single"],
    priceMin: 450,
    priceMax: 650,
    applicationLink: "https://www.collegio-arcobaleno.it/",
    mapLink: "https://maps.google.com/?q=UniMi+Arcobaleno+Milano",
    features: ["Wi-Fi", "Study rooms", "Common kitchen", "Garden"],
    recommended: true
  },
  {
    city: "Milan",
    name: {
      en: "Camplus Città Studi",
      it: "Camplus Città Studi",
      tr: "Camplus Città Studi",
      ar: "كامبلوس سيتا ستودي"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 650,
    priceMax: 900,
    applicationLink: "https://www.camplus.it/en/residences/milan-citta-studi/",
    mapLink: "https://maps.google.com/?q=Camplus+Citta+Studi+Milano",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cafeteria"],
    recommended: true
  },
  {
    city: "Milan",
    name: {
      en: "Camplus Turro",
      it: "Camplus Turro",
      tr: "Camplus Turro",
      ar: "كامبلوس تورو"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 600,
    priceMax: 850,
    applicationLink: "https://www.camplus.it/en/residences/milan-turro/",
    mapLink: "https://maps.google.com/?q=Camplus+Turro+Milano",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Gym"]
  },
  {
    city: "Milan",
    name: {
      en: "Camplus Gorla",
      it: "Camplus Gorla",
      tr: "Camplus Gorla",
      ar: "كامبلوس غورلا"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 580,
    priceMax: 820,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Gorla+Milano",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Milan",
    name: {
      en: "Camplus Bovisa",
      it: "Camplus Bovisa",
      tr: "Camplus Bovisa",
      ar: "كامبلوس بوفيزا"
    },
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 620,
    priceMax: 880,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Bovisa+Milano",
    features: ["Wi-Fi", "Gym", "Study rooms", "Bike parking"]
  },
  {
    city: "Milan",
    name: {
      en: "Camplus Sesto San Giovanni",
      it: "Camplus Sesto San Giovanni",
      tr: "Camplus Sesto San Giovanni",
      ar: "كامبلوس سيستو سان جيوفاني"
    },
    university: "Milano-Bicocca",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 550,
    priceMax: 800,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Sesto+San+Giovanni",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Cafeteria"]
  },
  {
    city: "Milan",
    name: {
      en: "In-Domus Certosa",
      it: "In-Domus Certosa",
      tr: "In-Domus Certosa",
      ar: "إن-دوموس تشيرتوزا"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 590,
    priceMax: 840,
    applicationLink: "https://www.in-domus.it/",
    mapLink: "https://maps.google.com/?q=In-Domus+Certosa+Milano",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry"]
  },
  {
    city: "Milan",
    name: {
      en: "In-Domus Monneret",
      it: "In-Domus Monneret",
      tr: "In-Domus Monneret",
      ar: "إن-دوموس مونيريت"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 600,
    priceMax: 850,
    applicationLink: "https://www.in-domus.it/",
    mapLink: "https://maps.google.com/?q=In-Domus+Monneret+Milano",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Milan",
    name: {
      en: "Aparto Giovenale",
      it: "Aparto Giovenale",
      tr: "Aparto Giovenale",
      ar: "أبارتو جيوفيناله"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 700,
    priceMax: 1000,
    applicationLink: "https://www.aparto.com/",
    mapLink: "https://maps.google.com/?q=Aparto+Giovenale+Milano",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cafeteria"]
  },
  {
    city: "Milan",
    name: {
      en: "Aparto Ripamonti",
      it: "Aparto Ripamonti",
      tr: "Aparto Ripamonti",
      ar: "أبارتو ريبامونتي"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 720,
    priceMax: 1050,
    applicationLink: "https://www.aparto.com/",
    mapLink: "https://maps.google.com/?q=Aparto+Ripamonti+Milano",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Milan",
    name: {
      en: "Collegiate Milan North",
      it: "Collegiate Milan North",
      tr: "Collegiate Milan North",
      ar: "كوليجيت ميلان نورث"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 750,
    priceMax: 1100,
    applicationLink: "https://www.collegiate-ac.com/",
    mapLink: "https://maps.google.com/?q=Collegiate+Milan+North",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cafeteria", "Cinema room"]
  }
];
