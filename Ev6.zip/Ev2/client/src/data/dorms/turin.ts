import { Dorm } from './types';

export const turinDorms: Dorm[] = [
  {
    city: "Turin",
    name: {
      en: "EDISU Borsellino",
      it: "EDISU Borsellino",
      tr: "EDISU Borsellino",
      ar: "إديسو بورسيلينو"
    },
    university: "Politecnico di Torino",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 320,
    priceMax: 500,
    applicationLink: "https://www.edisu.piemonte.it/",
    mapLink: "https://maps.google.com/?q=EDISU+Borsellino+Torino",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"],
    recommended: true
  },
  {
    city: "Turin",
    name: {
      en: "EDISU Olimpia",
      it: "EDISU Olimpia",
      tr: "EDISU Olimpia",
      ar: "إديسو أوليمبيا"
    },
    university: "Università di Torino",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 300,
    priceMax: 480,
    applicationLink: "https://www.edisu.piemonte.it/",
    mapLink: "https://maps.google.com/?q=EDISU+Olimpia+Torino",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"],
    recommended: true
  },
  {
    city: "Turin",
    name: {
      en: "EDISU Verdi",
      it: "EDISU Verdi",
      tr: "EDISU Verdi",
      ar: "إديسو فيردي"
    },
    university: "Università di Torino",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 310,
    priceMax: 490,
    applicationLink: "https://www.edisu.piemonte.it/",
    mapLink: "https://maps.google.com/?q=EDISU+Verdi+Torino",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Bike parking"]
  },
  {
    city: "Turin",
    name: {
      en: "EDISU Cavour",
      it: "EDISU Cavour",
      tr: "EDISU Cavour",
      ar: "إديسو كافور"
    },
    university: "Politecnico di Torino",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 330,
    priceMax: 510,
    applicationLink: "https://www.edisu.piemonte.it/",
    mapLink: "https://maps.google.com/?q=EDISU+Cavour+Torino",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Garden"]
  },
  {
    city: "Turin",
    name: {
      en: "EDISU Cappel Verde",
      it: "EDISU Cappel Verde",
      tr: "EDISU Cappel Verde",
      ar: "إديسو كابيل فيردي"
    },
    university: "Università di Torino",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 290,
    priceMax: 470,
    applicationLink: "https://www.edisu.piemonte.it/",
    mapLink: "https://maps.google.com/?q=EDISU+Cappel+Verde+Torino",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Turin",
    name: {
      en: "EDISU Torino General List",
      it: "EDISU Torino Lista Generale",
      tr: "EDISU Torino Genel Liste",
      ar: "إديسو تورينو القائمة العامة"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 280,
    priceMax: 500,
    applicationLink: "https://www.edisu.piemonte.it/",
    mapLink: "https://maps.google.com/?q=EDISU+Torino",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Sports facilities"]
  },
  {
    city: "Turin",
    name: {
      en: "Camplus Bernini",
      it: "Camplus Bernini",
      tr: "Camplus Bernini",
      ar: "كامبلوس بيرنيني"
    },
    university: "Politecnico di Torino",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 550,
    priceMax: 800,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Bernini+Torino",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Turin",
    name: {
      en: "Camplus MOI",
      it: "Camplus MOI",
      tr: "Camplus MOI",
      ar: "كامبلوس MOI"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 570,
    priceMax: 820,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+MOI+Torino",
    features: ["Wi-Fi", "Gym", "Study rooms", "Cafeteria"]
  },
  {
    city: "Turin",
    name: {
      en: "CX Turin Vanchiglia",
      it: "CX Turin Vanchiglia",
      tr: "CX Turin Vanchiglia",
      ar: "سي إكس تورينو فانكيليا"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 600,
    priceMax: 850,
    applicationLink: "https://www.cxliving.com/",
    mapLink: "https://maps.google.com/?q=CX+Turin+Vanchiglia",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Turin",
    name: {
      en: "CX Turin Marconi",
      it: "CX Turin Marconi",
      tr: "CX Turin Marconi",
      ar: "سي إكس تورينو ماركوني"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 620,
    priceMax: 880,
    applicationLink: "https://www.cxliving.com/",
    mapLink: "https://maps.google.com/?q=CX+Turin+Marconi",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  }
];
