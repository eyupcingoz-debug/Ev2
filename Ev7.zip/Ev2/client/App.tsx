import * as React from "react";
import IseeCard from "@/bureaucracy/components/IseeCard";

export default function App() {
  return (
    <main style={{ maxWidth: 880, margin: "40px auto", padding: "0 20px" }}>
      <h1>ISEE işlemleri</h1>
      <p style={{ color: "#666" }}>CAF randevuları + local hatırlatıcı</p>
      <div style={{ height: 12 }} />
      <IseeCard />
    </main>
  );
}