import { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Navigation, Info } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icon
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Default center: Milano
const MILANO_CENTER: [number, number] = [45.4642, 9.1900];

interface MapPickerInputProps {
  latitude: string;
  longitude: string;
  onChange: (lat: string, lng: string) => void;
  className?: string;
}

// Component to handle map clicks
function MapClickHandler({ onClick }: { onClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click: (e) => {
      onClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export default function MapPickerInput({ latitude, longitude, onChange, className = '' }: MapPickerInputProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const [markerPosition, setMarkerPosition] = useState<[number, number] | null>(null);
  const [mapCenter, setMapCenter] = useState<[number, number]>(MILANO_CENTER);

  // Initialize marker position from props
  useEffect(() => {
    if (latitude && longitude) {
      const lat = parseFloat(latitude);
      const lng = parseFloat(longitude);
      if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        setMarkerPosition([lat, lng]);
        setMapCenter([lat, lng]);
      }
    }
  }, [latitude, longitude]);

  const handleMapClick = (lat: number, lng: number) => {
    // Format to 6 decimal places (meter-level precision)
    const formattedLat = lat.toFixed(6);
    const formattedLng = lng.toFixed(6);
    
    setMarkerPosition([lat, lng]);
    onChange(formattedLat, formattedLng);
  };

  const handleManualInput = (field: 'lat' | 'lng', value: string) => {
    // Replace comma with dot for European format
    const cleanValue = value.replace(',', '.');
    
    if (field === 'lat') {
      onChange(cleanValue, longitude);
      const numVal = parseFloat(cleanValue);
      if (!isNaN(numVal) && numVal >= -90 && numVal <= 90) {
        if (longitude) {
          const lngNum = parseFloat(longitude);
          if (!isNaN(lngNum)) {
            setMarkerPosition([numVal, lngNum]);
          }
        }
      }
    } else {
      onChange(latitude, cleanValue);
      const numVal = parseFloat(cleanValue);
      if (!isNaN(numVal) && numVal >= -180 && numVal <= 180) {
        if (latitude) {
          const latNum = parseFloat(latitude);
          if (!isNaN(latNum)) {
            setMarkerPosition([latNum, numVal]);
          }
        }
      }
    }
  };

  const handleGetCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert(t('geolocationNotSupported') || 'Geolocation is not supported by your browser');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const formattedLat = lat.toFixed(6);
        const formattedLng = lng.toFixed(6);
        
        setMarkerPosition([lat, lng]);
        setMapCenter([lat, lng]);
        onChange(formattedLat, formattedLng);
      },
      (error) => {
        console.error('Geolocation error:', error);
        alert(t('locationPermissionDenied') || 'Unable to get your location. Please check your browser settings.');
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <MapPin className="h-5 w-5 text-purple-600" />
          {t('selectLocationOnMap') || 'Seleziona Posizione sulla Mappa'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription className="text-sm">
            {t('mapPickerInstructions') || 'Clicca sulla mappa per selezionare la posizione esatta del tuo annuncio. Puoi anche inserire le coordinate manualmente.'}
          </AlertDescription>
        </Alert>

        {/* Map */}
        <div className="w-full h-[400px] rounded-lg overflow-hidden border-2 border-purple-200">
          <MapContainer
            center={mapCenter}
            zoom={13}
            scrollWheelZoom={false}
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapClickHandler onClick={handleMapClick} />
            {markerPosition && (
              <Marker position={markerPosition} />
            )}
          </MapContainer>
        </div>

        {/* Coordinate Inputs */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="latitude">
              {t('latitude') || 'Latitudine'} <span className="text-red-500">*</span>
            </Label>
            <Input
              id="latitude"
              type="text"
              value={latitude}
              onChange={(e) => handleManualInput('lat', e.target.value)}
              placeholder="45.464200"
              className="border-purple-200 focus:border-purple-500"
            />
            <p className="text-xs text-gray-500">
              {t('latRange') || 'Range: -90 a 90 (usa punto)'}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="longitude">
              {t('longitude') || 'Longitudine'} <span className="text-red-500">*</span>
            </Label>
            <Input
              id="longitude"
              type="text"
              value={longitude}
              onChange={(e) => handleManualInput('lng', e.target.value)}
              placeholder="9.190000"
              className="border-purple-200 focus:border-purple-500"
            />
            <p className="text-xs text-gray-500">
              {t('lngRange') || 'Range: -180 a 180 (usa punto)'}
            </p>
          </div>
        </div>

        {/* Get Current Location Button */}
        <Button
          type="button"
          variant="outline"
          className="w-full border-purple-300 text-purple-700 hover:bg-purple-50"
          onClick={handleGetCurrentLocation}
        >
          <Navigation className="h-4 w-4 mr-2" />
          {t('useMyLocation') || 'Usa la Mia Posizione'}
        </Button>

        {markerPosition && (
          <Alert className="bg-green-50 border-green-200">
            <MapPin className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-sm text-green-800">
              <strong>{t('selectedLocation') || 'Posizione selezionata'}:</strong>{' '}
              {latitude}, {longitude}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
