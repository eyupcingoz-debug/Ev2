import { useEffect, useState, useMemo, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Euro, Home } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import type { RoomListing } from './RoomListingCard';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icon issue in Leaflet with webpack
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Italian cities coordinates
const CITY_COORDINATES: Record<string, [number, number]> = {
  'Milano': [45.4642, 9.1900],
  'Milan': [45.4642, 9.1900],
  'Roma': [41.9028, 12.4964],
  'Rome': [41.9028, 12.4964],
  'Torino': [45.0703, 7.6869],
  'Turin': [45.0703, 7.6869],
  'Firenze': [43.7696, 11.2558],
  'Florence': [43.7696, 11.2558],
  'Bologna': [44.4949, 11.3426],
  'Napoli': [40.8518, 14.2681],
  'Naples': [40.8518, 14.2681],
  'Venezia': [45.4408, 12.3155],
  'Venice': [45.4408, 12.3155],
  'Genova': [44.4056, 8.9463],
  'Genoa': [44.4056, 8.9463],
  'Palermo': [38.1157, 13.3615],
  'Bari': [41.1171, 16.8719],
  'Catania': [37.5079, 15.0830],
  'Verona': [45.4384, 10.9916],
  'Padova': [45.4064, 11.8768],
  'Padua': [45.4064, 11.8768],
  'Trieste': [45.6495, 13.7768],
  'Brescia': [45.5416, 10.2118],
  'Parma': [44.8015, 10.3279],
  'Modena': [44.6471, 10.9252],
  'Pisa': [43.7228, 10.4017],
  'Perugia': [43.1107, 12.3908],
  'Ancona': [43.6158, 13.5189],
  'Bergamo': [45.6983, 9.6773],
  'Taranto': [40.4762, 17.2402],
  'Pavia': [45.1847, 9.1582],
  'Piacenza': [45.0526, 9.6924],
  'Reggio Emilia': [44.6989, 10.6297],
  'Salerno': [40.6824, 14.7681],
  'Pescara': [42.4584, 14.2139],
  'Siena': [43.3188, 11.3308],
  'Lucca': [43.8376, 10.4950],
  'Ferrara': [44.8381, 11.6198]
};

// Default Italy center
const ITALY_CENTER: [number, number] = [41.8719, 12.5674];

interface RoomListingsMapProps {
  listings: RoomListing[];
  onListingClick?: (listing: RoomListing) => void;
}

// Component to handle map centering and bounds
function MapCenterController({ center, bounds }: { center: [number, number], bounds?: L.LatLngBoundsExpression }) {
  const map = useMap();
  const prevBoundsRef = useRef<L.LatLngBoundsExpression | undefined>(undefined);
  
  useEffect(() => {
    // Only apply fitBounds when bounds actually change (not on every center change)
    const boundsChanged = bounds !== prevBoundsRef.current;
    
    if (bounds && boundsChanged) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
      prevBoundsRef.current = bounds;
    } else if (!bounds) {
      // When bounds are cleared (e.g., user manually recentering), use the center
      map.setView(center, 12);
      prevBoundsRef.current = undefined;
    }
  }, [center, bounds, map]);
  
  return null;
}

export default function RoomListingsMap({ listings, onListingClick }: RoomListingsMapProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const [mapCenter, setMapCenter] = useState<[number, number]>(ITALY_CENTER);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [locationPermissionAsked, setLocationPermissionAsked] = useState(false);
  const [mapBounds, setMapBounds] = useState<L.LatLngBoundsExpression | undefined>(undefined);

  // Request geolocation on mount
  useEffect(() => {
    if (!locationPermissionAsked && navigator.geolocation) {
      setLocationPermissionAsked(true);
      
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userPos: [number, number] = [
            position.coords.latitude,
            position.coords.longitude
          ];
          setUserLocation(userPos);
          setMapCenter(userPos);
        },
        (error) => {
          console.log('Geolocation error:', error.message);
          // If geolocation fails, stay on Italy center
          setMapCenter(ITALY_CENTER);
        },
        {
          timeout: 10000,
          enableHighAccuracy: false
        }
      );
    }
  }, [locationPermissionAsked]);

  // Process listings and add coordinates
  const listingsWithCoords = useMemo(() => {
    return listings.map((listing, index) => {
      // Priority 1: Use real lat/lng from listing if available
      if (listing.latitude && listing.longitude) {
        const lat = parseFloat(listing.latitude);
        const lng = parseFloat(listing.longitude);
        
        if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
          return {
            ...listing,
            coordinates: [lat, lng] as [number, number]
          };
        }
      }
      
      // Priority 2: Fall back to city coordinates
      const cityKey = listing.city.trim();
      let coords = CITY_COORDINATES[cityKey] || CITY_COORDINATES[cityKey.toLowerCase()];
      
      // If city not found, try to find partial match
      if (!coords) {
        const foundCity = Object.keys(CITY_COORDINATES).find(
          city => city.toLowerCase().includes(cityKey.toLowerCase()) || 
                  cityKey.toLowerCase().includes(city.toLowerCase())
        );
        coords = foundCity ? CITY_COORDINATES[foundCity] : ITALY_CENTER;
      }
      
      // Add small random offset to avoid overlapping markers in same city
      const offset = 0.01;
      const randomLat = coords[0] + (Math.random() - 0.5) * offset;
      const randomLng = coords[1] + (Math.random() - 0.5) * offset;
      
      return {
        ...listing,
        coordinates: [randomLat, randomLng] as [number, number]
      };
    });
  }, [listings]);

  // Calculate bounds to fit all markers
  useEffect(() => {
    if (listingsWithCoords.length > 0) {
      const coords = listingsWithCoords.map(l => l.coordinates);
      const bounds = L.latLngBounds(coords);
      setMapBounds(bounds);
    } else {
      setMapBounds(undefined);
    }
  }, [listingsWithCoords]);

  const handleCenterOnUser = () => {
    if (userLocation) {
      // Clear bounds only after we know we have a valid user location
      setMapBounds(undefined);
      setMapCenter(userLocation);
    } else {
      // Request geolocation again
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const userPos: [number, number] = [
              position.coords.latitude,
              position.coords.longitude
            ];
            setUserLocation(userPos);
            // Clear bounds only on successful geolocation
            setMapBounds(undefined);
            setMapCenter(userPos);
          },
          (error) => {
            // On failure, keep the existing bounds so listings remain visible
            alert(t('locationPermissionDenied') || 'Location permission denied');
          }
        );
      }
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-purple-600" />
            {t('interactiveMap') || 'Mappa Interattiva'}
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={handleCenterOnUser}
            className="flex items-center gap-2"
          >
            <Navigation className="h-4 w-4" />
            {t('centerOnMe') || 'Centra su di me'}
          </Button>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          {t('mapDescription') || 'Clicca sui marker per vedere i dettagli degli annunci. Puoi trascinare e ingrandire la mappa.'}
        </p>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[600px] rounded-lg overflow-hidden border-2 border-purple-200">
          <MapContainer
            center={mapCenter}
            zoom={12}
            scrollWheelZoom={true}
            style={{ height: '100%', width: '100%' }}
          >
            <MapCenterController center={mapCenter} bounds={mapBounds} />
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {/* User location marker */}
            {userLocation && (
              <Marker position={userLocation}>
                <Popup>
                  <div className="text-center">
                    <strong>{t('yourLocation') || 'La tua posizione'}</strong>
                  </div>
                </Popup>
              </Marker>
            )}
            
            {/* Room listing markers */}
            {listingsWithCoords.map((listing) => (
              <Marker key={listing.id} position={listing.coordinates}>
                <Popup maxWidth={300}>
                  <div className="space-y-2 p-2">
                    {listing.photos && listing.photos.length > 0 && (
                      <img
                        src={listing.photos[0]}
                        alt={listing.title}
                        className="w-full h-32 object-cover rounded-md"
                      />
                    )}
                    <h3 className="font-bold text-lg text-purple-700">{listing.title}</h3>
                    <div className="space-y-1 text-sm">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3 w-3" />
                        <span>{listing.city}{listing.district ? `, ${listing.district}` : ''}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Euro className="h-3 w-3" />
                        <span className="font-semibold">€{listing.rentPrice}/mese</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Home className="h-3 w-3" />
                        <Badge variant="secondary" className="text-xs">
                          {listing.roomType === 'private' ? (t('privateRoom') || 'Privata') : (t('sharedRoom') || 'Condivisa')}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-xs text-gray-600 line-clamp-2 mt-2">
                      {listing.description}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      <strong>{t('ownerName') || 'Proprietario'}:</strong> {listing.ownerName}
                    </p>
                    {onListingClick && (
                      <Button
                        size="sm"
                        className="w-full mt-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                        onClick={() => onListingClick(listing)}
                      >
                        {t('viewDetails') || 'Vedi Dettagli'}
                      </Button>
                    )}
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-sm text-blue-800">
            <strong>{t('totalListings') || 'Totale annunci'}:</strong> {listings.length} {t('visibleOnMap') || 'visibili sulla mappa'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
