import { Dorm } from './types';

export const naplesDorms: Dorm[] = [
  {
    city: "Naples",
    name: {
      en: "ADISU L'Orientale Brin",
      it: "ADISU L'Orientale Brin",
      tr: "ADISU L'Orientale Brin",
      ar: "أديسو لورينتالي برين"
    },
    university: "L'Orientale",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 200,
    priceMax: 400,
    applicationLink: "https://www.adisunapoli.it/",
    mapLink: "https://maps.google.com/?q=ADISU+Brin+Napoli",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"],
    recommended: true
  },
  {
    city: "Naples",
    name: {
      en: "ADISU Parthenope Ferraris",
      it: "ADISU Parthenope Ferraris",
      tr: "ADISU Parthenope Ferraris",
      ar: "أديسو بارثينوبي فيراريس"
    },
    university: "Parthenope",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 210,
    priceMax: 410,
    applicationLink: "https://www.adisunapoli.it/",
    mapLink: "https://maps.google.com/?q=ADISU+Ferraris+Napoli",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Sea view"],
    recommended: true
  },
  {
    city: "Naples",
    name: {
      en: "ADISU Flavio Pozzuoli",
      it: "ADISU Flavio Pozzuoli",
      tr: "ADISU Flavio Pozzuoli",
      ar: "أديسو فلافيو بوتسوولي"
    },
    university: "Federico II",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 190,
    priceMax: 390,
    applicationLink: "https://www.adisunapoli.it/",
    mapLink: "https://maps.google.com/?q=ADISU+Flavio+Pozzuoli",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Sports facilities"]
  },
  {
    city: "Naples",
    name: {
      en: "UniNa Student Residences",
      it: "UniNa Residenze",
      tr: "UniNa Yurtları",
      ar: "مساكن UniNa"
    },
    university: "Università di Napoli",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.unina.it/",
    mapLink: "https://maps.google.com/?q=UniNa+Residenze+Napoli",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Naples",
    name: {
      en: "Private Centro Direzionale Houses",
      it: "Case Private Centro Direzionale",
      tr: "Centro Direzionale Özel Evleri",
      ar: "منازل سنترو ديريزيونالي الخاصة"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 300,
    priceMax: 500,
    applicationLink: "https://www.adisunapoli.it/",
    mapLink: "https://maps.google.com/?q=Centro+Direzionale+Student+Housing+Napoli",
    features: ["Wi-Fi", "Common areas", "Laundry", "Metro access"]
  },
  {
    city: "Naples",
    name: {
      en: "Turkish Guest Houses",
      it: "Konukevleri Turchi",
      tr: "Türk Konukevleri",
      ar: "بيوت الضيافة التركية"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double", "Triple"],
    priceMin: 220,
    priceMax: 420,
    applicationLink: "https://www.adisunapoli.it/",
    mapLink: "https://maps.google.com/?q=Turkish+Guest+Houses+Napoli",
    features: ["Wi-Fi", "Common kitchen", "Laundry", "Cultural events"]
  }
];
