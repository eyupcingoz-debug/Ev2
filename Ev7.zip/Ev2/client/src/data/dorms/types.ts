export interface DormNames {
  en: string;
  it: string;
  tr: string;
  ar: string;
}

export interface CityNames {
  en: string;
  it: string;
  tr: string;
  ar: string;
}

export interface Dorm {
  city: string; // English city name for filtering
  name: DormNames;
  university: string;
  gender: 'Male' | 'Female' | 'Mixed';
  roomTypes: ('Single' | 'Double' | 'Triple' | 'Quadruple')[];
  priceMin: number;
  priceMax: number;
  description?: DormNames; // Multilingual description (optional)
  applicationLink: string;
  mapLink?: string;
  features: string[]; // WiFi, Laundry, Gym, StudyRoom, Canteen, etc.
  recommended?: boolean;
}

// City name translations
export const cityNames: Record<string, CityNames> = {
  Milan: {
    en: 'Milan',
    it: 'Milano',
    tr: 'Milan',
    ar: 'ميلانو'
  },
  Rome: {
    en: 'Rome',
    it: 'Roma',
    tr: 'Roma',
    ar: 'روما'
  },
  Bologna: {
    en: 'Bologna',
    it: 'Bologna',
    tr: 'Bologna',
    ar: 'بولونيا'
  },
  Turin: {
    en: 'Turin',
    it: 'Torino',
    tr: 'Torino',
    ar: 'تورينو'
  },
  Naples: {
    en: 'Naples',
    it: 'Napoli',
    tr: 'Napoli',
    ar: 'نابولي'
  },
  Genoa: {
    en: 'Genoa',
    it: 'Genova',
    tr: 'Cenova',
    ar: 'جنوة'
  },
  Pavia: {
    en: 'Pavia',
    it: 'Pavia',
    tr: 'Pavia',
    ar: 'بافيا'
  },
  Piacenza: {
    en: 'Piacenza',
    it: 'Piacenza',
    tr: 'Piacenza',
    ar: 'بياتشنزا'
  },
  Florence: {
    en: 'Florence',
    it: 'Firenze',
    tr: 'Floransa',
    ar: 'فلورنسا'
  },
  Parma: {
    en: 'Parma',
    it: 'Parma',
    tr: 'Parma',
    ar: 'بارما'
  },
  Taranto: {
    en: 'Taranto',
    it: 'Taranto',
    tr: 'Taranto',
    ar: 'تارانتو'
  }
};
