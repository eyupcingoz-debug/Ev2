import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import Calendar from '../../pages/Calendar';

export default function CalendarExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <Calendar />
      </LanguageProvider>
    </ThemeProvider>
  );
}
