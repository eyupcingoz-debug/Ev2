import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface GuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  guideFile: string;
  language: string;
}

const getErrorMessage = (language: string) => {
  switch (language) {
    case 'tr':
      return 'Rehber yüklenemedi. Lütfen daha sonra tekrar deneyin.';
    case 'it':
      return 'Impossibile caricare la guida. Riprova più tardi.';
    case 'en':
      return 'Failed to load guide. Please try again later.';
    case 'ar':
      return 'فشل تحميل الدليل. يرجى المحاولة مرة أخرى لاحقًا.';
    default:
      return 'Failed to load guide. Please try again later.';
  }
};

const getDescription = (language: string) => {
  switch (language) {
    case 'tr':
      return 'Aşağıdaki adımları takip ederek işleminizi tamamlayabilirsiniz.';
    case 'it':
      return 'Segui i passaggi seguenti per completare la procedura.';
    case 'en':
      return 'Follow the steps below to complete the process.';
    case 'ar':
      return 'اتبع الخطوات أدناه لإكمال العملية.';
    default:
      return 'Follow the steps below to complete the process.';
  }
};

export function GuideModal({ isOpen, onClose, title, guideFile, language }: GuideModalProps) {
  const [guideText, setGuideText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const loadGuide = async () => {
      if (!isOpen) return;
      
      setLoading(true);
      setError('');
      
      try {
        const response = await fetch(`/texts/${language}/${guideFile}.txt`);
        
        if (!response.ok) {
          throw new Error('Guide not found');
        }
        
        const text = await response.text();
        setGuideText(text);
      } catch (err) {
        console.error('Error loading guide:', err);
        setError(getErrorMessage(language));
      } finally {
        setLoading(false);
      }
    };

    loadGuide();
  }, [isOpen, guideFile, language]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-cyan-600 dark:text-cyan-400">
            {title}
          </DialogTitle>
          <DialogDescription className="text-base text-gray-600 dark:text-gray-300">
            {getDescription(language)}
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[60vh] pr-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-cyan-600" />
            </div>
          ) : error ? (
            <div className="text-red-600 dark:text-red-400 text-center py-8">
              {error}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="whitespace-pre-wrap text-base font-sans text-gray-800 dark:text-gray-200 leading-relaxed">
                {guideText}
              </div>
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
