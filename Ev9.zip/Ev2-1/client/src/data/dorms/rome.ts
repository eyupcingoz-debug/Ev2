import { Dorm } from './types';

export const romeDorms: Dorm[] = [
  {
    city: "Rome",
    name: {
      en: "DiSCo Antonio Ruberti",
      it: "DiSCo Antonio Ruberti",
      tr: "DiSCo Antonio Ruberti",
      ar: "ديسكو أنتونيو روبيرتي"
    },
    university: "La Sapienza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.laziodisco.it/",
    mapLink: "https://maps.google.com/?q=DiSCo+Antonio+Ruberti+Roma",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Canteen"],
    recommended: true
  },
  {
    city: "Rome",
    name: {
      en: "DiSCo Archeologia",
      it: "DiSCo Archeologia",
      tr: "DiSCo Archeologia",
      ar: "ديسكو أركيولوجيا"
    },
    university: "La Sapienza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 260,
    priceMax: 460,
    applicationLink: "https://www.laziodisco.it/",
    mapLink: "https://maps.google.com/?q=DiSCo+Archeologia+Roma",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Common areas"],
    recommended: true
  },
  {
    city: "Rome",
    name: {
      en: "DiSCo Assisi",
      it: "DiSCo Assisi",
      tr: "DiSCo Assisi",
      ar: "ديسكو أسيزي"
    },
    university: "La Sapienza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 240,
    priceMax: 440,
    applicationLink: "https://www.laziodisco.it/",
    mapLink: "https://maps.google.com/?q=DiSCo+Assisi+Roma",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Garden"]
  },
  {
    city: "Rome",
    name: {
      en: "DiSCo Tarantelli",
      it: "DiSCo Tarantelli",
      tr: "DiSCo Tarantelli",
      ar: "ديسكو تارانتيلي"
    },
    university: "La Sapienza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 270,
    priceMax: 470,
    applicationLink: "https://www.laziodisco.it/",
    mapLink: "https://maps.google.com/?q=DiSCo+Tarantelli+Roma",
    features: ["Wi-Fi", "Study rooms", "Cafeteria", "Bike parking"]
  },
  {
    city: "Rome",
    name: {
      en: "DiSCo Falcone e Borsellino",
      it: "DiSCo Falcone e Borsellino",
      tr: "DiSCo Falcone e Borsellino",
      ar: "ديسكو فالكوني إي بورسيلينو"
    },
    university: "La Sapienza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 280,
    priceMax: 480,
    applicationLink: "https://www.laziodisco.it/",
    mapLink: "https://maps.google.com/?q=DiSCo+Falcone+Borsellino+Roma",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Common kitchen"]
  },
  {
    city: "Rome",
    name: {
      en: "DiSCo Cardarelli",
      it: "DiSCo Cardarelli",
      tr: "DiSCo Cardarelli",
      ar: "ديسكو كارداريلي"
    },
    university: "La Sapienza",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.laziodisco.it/",
    mapLink: "https://maps.google.com/?q=DiSCo+Cardarelli+Roma",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Garden"]
  },
  {
    city: "Rome",
    name: {
      en: "Camplus San Pietro",
      it: "Camplus San Pietro",
      tr: "Camplus San Pietro",
      ar: "كامبلوس سان بيترو"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 650,
    priceMax: 900,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+San+Pietro+Roma",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cafeteria"],
    recommended: true
  },
  {
    city: "Rome",
    name: {
      en: "Camplus Prati",
      it: "Camplus Prati",
      tr: "Camplus Prati",
      ar: "كامبلوس براتي"
    },
    university: "Multiple Universities",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 680,
    priceMax: 950,
    applicationLink: "https://www.camplus.it/",
    mapLink: "https://maps.google.com/?q=Camplus+Prati+Roma",
    features: ["Wi-Fi", "Study rooms", "Gym", "Laundry"]
  },
  {
    city: "Rome",
    name: {
      en: "CX Rome Tor Vergata",
      it: "CX Rome Tor Vergata",
      tr: "CX Rome Tor Vergata",
      ar: "سي إكس روما تور فيرغاتا"
    },
    university: "Tor Vergata",
    gender: "Mixed",
    roomTypes: ["Single", "Double"],
    priceMin: 600,
    priceMax: 850,
    applicationLink: "https://www.cxliving.com/",
    mapLink: "https://maps.google.com/?q=CX+Rome+Tor+Vergata",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Cinema room"]
  },
  {
    city: "Rome",
    name: {
      en: "Fondazione RUI Celimontano",
      it: "Fondazione RUI Celimontano",
      tr: "Fondazione RUI Celimontano",
      ar: "فوندازيوني RUI تشيليمونتانو"
    },
    university: "Multiple Universities",
    gender: "Male",
    roomTypes: ["Single", "Double"],
    priceMin: 450,
    priceMax: 700,
    applicationLink: "https://www.fondazionerui.it/",
    mapLink: "https://maps.google.com/?q=Fondazione+RUI+Celimontano+Roma",
    features: ["Wi-Fi", "Study rooms", "Chapel", "Library", "Garden"]
  }
];
